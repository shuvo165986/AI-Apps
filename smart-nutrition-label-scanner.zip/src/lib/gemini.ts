import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { UserProfile, AnalysisResult, OcrResult, OcrNutrients, DataSource, ProductAnalysisResult, PharmaAnalysisResult, ElectricalAnalysisResult } from "../types";

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  throw new Error("GEMINI_API_KEY is not set in environment variables.");
}

const ai = new GoogleGenAI({ apiKey });

const OCR_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    nutrients: {
      type: Type.OBJECT,
      properties: {
        calories: { type: Type.NUMBER },
        sugar: { type: Type.NUMBER },
        sodium: { type: Type.NUMBER },
        fat: { type: Type.NUMBER },
        protein: { type: Type.NUMBER },
        carbohydrates: { type: Type.NUMBER },
        fiber: { type: Type.NUMBER }
      }
    },
    ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
    confidenceScore: { type: Type.NUMBER, description: "Confidence score from 0 to 100." },
    imageQuality: {
      type: Type.OBJECT,
      properties: {
        isClear: { type: Type.BOOLEAN },
        reason: { type: Type.STRING },
        tips: { type: Type.ARRAY, items: { type: Type.STRING } }
      }
    }
  },
  required: ["nutrients", "ingredients", "confidenceScore", "imageQuality"]
};

const ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    productName: { type: Type.STRING, description: "The name of the food product if found." },
    mode: { type: Type.STRING, enum: ["full", "ingredient-only", "limited"], description: "The analysis mode based on available data." },
    dataSource: { type: Type.STRING, enum: ["ocr", "user-input", "database", "barcode"], description: "The primary source of the data." },
    healthScore: { type: Type.NUMBER, description: "Overall health score from 0 to 100." },
    evaluation: { type: Type.STRING, enum: ["excellent", "good", "average", "poor"], description: "Overall health evaluation." },
    confidence: {
      type: Type.OBJECT,
      properties: {
        score: { type: Type.NUMBER },
        level: { type: Type.STRING, enum: ["high", "medium", "low"] }
      }
    },
    nutrients: {
      type: Type.OBJECT,
      nullable: true,
      properties: {
        calories: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            value: { type: Type.NUMBER },
            unit: { type: Type.STRING },
            status: { type: Type.STRING, enum: ["low", "moderate", "high"] }
          }
        },
        sugar: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            value: { type: Type.NUMBER },
            unit: { type: Type.STRING },
            status: { type: Type.STRING, enum: ["low", "moderate", "high"] }
          }
        },
        sodium: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            value: { type: Type.NUMBER },
            unit: { type: Type.STRING },
            status: { type: Type.STRING, enum: ["low", "moderate", "high"] }
          }
        },
        fat: {
          type: Type.OBJECT,
          properties: {
            total: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                value: { type: Type.NUMBER },
                unit: { type: Type.STRING },
                status: { type: Type.STRING, enum: ["low", "moderate", "high"] }
              }
            },
            saturated: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                value: { type: Type.NUMBER },
                unit: { type: Type.STRING },
                status: { type: Type.STRING, enum: ["low", "moderate", "high"] }
              }
            },
            trans: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                value: { type: Type.NUMBER },
                unit: { type: Type.STRING },
                status: { type: Type.STRING, enum: ["low", "moderate", "high"] }
              }
            }
          }
        },
        protein: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            value: { type: Type.NUMBER },
            unit: { type: Type.STRING },
            status: { type: Type.STRING, enum: ["low", "moderate", "high"] }
          }
        },
        fiber: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            value: { type: Type.NUMBER },
            unit: { type: Type.STRING },
            status: { type: Type.STRING, enum: ["low", "moderate", "high"] }
          }
        },
        carbohydrates: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            value: { type: Type.NUMBER },
            unit: { type: Type.STRING },
            status: { type: Type.STRING, enum: ["low", "moderate", "high"] }
          }
        }
      }
    },
    scoreBreakdown: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          impact: { type: Type.NUMBER },
          reason: { type: Type.STRING }
        }
      }
    },
    micronutrients: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          value: { type: Type.NUMBER },
          unit: { type: Type.STRING },
          dailyValuePercentage: { type: Type.NUMBER }
        }
      }
    },
    ingredientInsights: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          category: { type: Type.STRING, enum: ['allergen', 'additive', 'detrimental'] },
          riskLevel: { type: Type.STRING, enum: ['low', 'moderate', 'high'] },
          description: { type: Type.STRING }
        }
      }
    },
    hiddenIngredients: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          warning: { type: Type.STRING },
          risk: { type: Type.STRING }
        }
      }
    },
    simpleExplanation: { type: Type.STRING, description: "A beginner-friendly explanation of the health impact." },
    healthSuggestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "General health suggestions." },
    localFoodWarnings: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Warnings relevant to local products (Bangladesh focus)." },
    localAlternatives: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Local healthier alternative foods." },
    nutritionalEstimate: {
      type: Type.OBJECT,
      properties: {
        calories: { type: Type.STRING },
        sugarCarbs: { type: Type.STRING, enum: ["Low", "Medium", "High"] },
        oilFatQuality: { type: Type.STRING },
        protein: { type: Type.STRING }
      }
    },
    healthAlerts: { type: Type.ARRAY, items: { type: Type.STRING } },
    desiAlternative: { type: Type.STRING },
    privacyNote: { type: Type.STRING },
    visualBar: { type: Type.STRING, description: "A visual bar using emojis like 🟥🟥🟥🟧🟩🟩🟩🟩 based on the score." },
    componentBreakdown: {
      type: Type.OBJECT,
      properties: {
        carbs: { type: Type.NUMBER, description: "Percentage of carbs (0-100)." },
        carbsType: { type: Type.STRING, description: "Type of carbs (e.g., Refined Rice)." },
        greaseScale: { type: Type.NUMBER, description: "Grease level percentage (0-100)." },
        oilType: { type: Type.STRING, description: "Estimated oil type (e.g., Reclaimed Soybean Oil)." },
        protein: { type: Type.NUMBER, description: "Percentage of protein (0-100)." },
        proteinType: { type: Type.STRING, description: "Type of protein (e.g., Mutton)." },
        fiberVeggies: { type: Type.NUMBER, description: "Percentage of fiber/veggies (0-100)." },
        veggieType: { type: Type.STRING, description: "Type of veggies (e.g., Potato)." }
      }
    },
    desiSafetyAlerts: {
      type: Type.OBJECT,
      properties: {
        purity: { type: Type.STRING, description: "BSTI status or adulteration risks." },
        bloodSugarImpact: { type: Type.STRING, description: "Blood sugar spike risk level." }
      }
    },
    hyperLocalSwap: {
      type: Type.OBJECT,
      properties: {
        insteadOf: { type: Type.STRING },
        tryThis: { type: Type.STRING },
        benefit: { type: Type.STRING }
      }
    },
    nutritionPerTaka: { type: Type.STRING, description: "Value for money assessment." },
    novaClassification: { type: Type.STRING, enum: ["1", "2", "3", "4"], description: "NOVA classification level." },
    additiveRisk: { type: Type.STRING, enum: ["safe", "moderate", "risky"], description: "Additive risk level." },
    purityGrade: { type: Type.STRING, enum: ["A", "B", "C", "D", "F"], description: "Purity grade." },
    halalStatus: { type: Type.STRING, enum: ["halal", "doubtful", "not-halal"], description: "Halal status." },
    glutenFreeStatus: { type: Type.STRING, enum: ["gluten-free", "contains-gluten", "may-contain"], description: "Gluten-free status of the product." },
    diabeticFriendly: { type: Type.BOOLEAN, description: "Whether the food is diabetic friendly." },
    kidSafe: { type: Type.BOOLEAN, description: "Whether the food is kid safe." },
    healthBattery: { type: Type.NUMBER, description: "Health battery level (0-100)." },
    smartPlate: {
      type: Type.OBJECT,
      properties: {
        carbs: { type: Type.NUMBER },
        protein: { type: Type.NUMBER },
        fat: { type: Type.NUMBER },
        fiber: { type: Type.NUMBER }
      }
    },
    whoComparison: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          nutrientName: { type: Type.STRING },
          currentValue: { type: Type.NUMBER },
          whoLimit: { type: Type.NUMBER },
          unit: { type: Type.STRING },
          isExceeded: { type: Type.BOOLEAN },
          explanation: { type: Type.STRING }
        }
      }
    }
  },
  required: ["mode", "dataSource", "healthScore", "evaluation", "nutrients", "hiddenIngredients", "simpleExplanation", "healthSuggestions", "whoComparison", "nutritionalEstimate", "healthAlerts", "desiAlternative", "privacyNote", "visualBar", "componentBreakdown", "desiSafetyAlerts", "hyperLocalSwap", "nutritionPerTaka", "novaClassification", "additiveRisk", "purityGrade", "healthBattery", "smartPlate", "halalStatus", "glutenFreeStatus", "diabeticFriendly", "kidSafe", "scoreBreakdown"]
};

const PRODUCT_ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    productName: { type: Type.STRING },
    productCategory: { type: Type.STRING, description: "e.g., Cosmetic, Household, Medicine" },
    safetyScore: { type: Type.NUMBER, description: "0-100" },
    overallSafety: { type: Type.STRING, enum: ["safe", "caution", "hazardous"] },
    ingredients: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          purpose: { type: Type.STRING },
          safetyRating: { type: Type.STRING, enum: ["safe", "caution", "hazardous"] },
          description: { type: Type.STRING },
          isAllergen: { type: Type.BOOLEAN },
          alternatives: { type: Type.ARRAY, items: { type: Type.STRING } }
        }
      }
    },
    usageAdvice: { type: Type.ARRAY, items: { type: Type.STRING } },
    healthAlerts: { type: Type.ARRAY, items: { type: Type.STRING } },
    environmentalImpact: { type: Type.STRING },
    simpleExplanation: { type: Type.STRING },
    skinSuitability: {
      type: Type.OBJECT,
      properties: {
        oily: { type: Type.STRING },
        dry: { type: Type.STRING },
        sensitive: { type: Type.STRING },
        acneProne: { type: Type.STRING }
      }
    },
    isVegan: { type: Type.BOOLEAN },
    isCrueltyFree: { type: Type.BOOLEAN },
    pregnancySafe: { type: Type.BOOLEAN },
    hazardLevel: { type: Type.NUMBER, description: "0-10 scale" },
    shelfLifeGuidance: { type: Type.STRING },
    confidence: {
      type: Type.OBJECT,
      properties: {
        score: { type: Type.NUMBER },
        level: { type: Type.STRING, enum: ["high", "medium", "low"] }
      }
    }
  },
  required: ["productName", "productCategory", "safetyScore", "overallSafety", "ingredients", "usageAdvice", "healthAlerts", "simpleExplanation", "confidence"]
};

const ELECTRICAL_ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    productName: { type: Type.STRING },
    brand: { type: Type.STRING },
    modelNumber: { type: Type.STRING },
    specifications: {
      type: Type.OBJECT,
      properties: {
        voltage: { type: Type.STRING },
        power: { type: Type.STRING },
        current: { type: Type.STRING },
        frequency: { type: Type.STRING }
      }
    },
    materials: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          purpose: { type: Type.STRING },
          safetyNote: { type: Type.STRING }
        }
      }
    },
    certifications: { type: Type.ARRAY, items: { type: Type.STRING } },
    safetyFeatures: { type: Type.ARRAY, items: { type: Type.STRING } },
    energyEfficiency: { type: Type.STRING },
    hazardWarnings: { type: Type.ARRAY, items: { type: Type.STRING } },
    usageInstructions: { type: Type.ARRAY, items: { type: Type.STRING } },
    environmentalImpact: { type: Type.STRING },
    safetyScore: { type: Type.NUMBER, description: "0-100" },
    simpleExplanation: { type: Type.STRING },
    confidence: {
      type: Type.OBJECT,
      properties: {
        score: { type: Type.NUMBER },
        level: { type: Type.STRING, enum: ["high", "medium", "low"] }
      }
    }
  },
  required: ["productName", "specifications", "materials", "certifications", "safetyFeatures", "hazardWarnings", "usageInstructions", "environmentalImpact", "safetyScore", "simpleExplanation", "confidence"]
};

const PHARMA_ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    productName: { type: Type.STRING },
    manufacturer: { type: Type.STRING },
    activeIngredients: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          strength: { type: Type.STRING },
          purpose: { type: Type.STRING }
        }
      }
    },
    inactiveIngredients: { type: Type.ARRAY, items: { type: Type.STRING } },
    indications: { type: Type.ARRAY, items: { type: Type.STRING } },
    dosageInstructions: { type: Type.STRING },
    warnings: { type: Type.ARRAY, items: { type: Type.STRING } },
    sideEffects: { type: Type.ARRAY, items: { type: Type.STRING } },
    interactions: { type: Type.ARRAY, items: { type: Type.STRING } },
    pregnancyCategory: { type: Type.STRING },
    isOtc: { type: Type.BOOLEAN },
    safetyScore: { type: Type.NUMBER, description: "0-100" },
    simpleExplanation: { type: Type.STRING },
    confidence: {
      type: Type.OBJECT,
      properties: {
        score: { type: Type.NUMBER },
        level: { type: Type.STRING, enum: ["high", "medium", "low"] }
      }
    }
  },
  required: ["productName", "activeIngredients", "inactiveIngredients", "indications", "dosageInstructions", "warnings", "sideEffects", "interactions", "isOtc", "safetyScore", "simpleExplanation", "confidence"]
};

export async function performOcr(imageBase64: string): Promise<OcrResult> {
  const prompt = `
    Extract nutritional values and ingredients from the provided image.
    
    Tasks:
    1. Extract key nutrients: Calories, Sugar, Sodium, Fat, Protein, Carbohydrates, Fiber.
    2. Extract the full ingredient list as an array of strings.
    3. Assess image quality: Check for blur, lighting, and text visibility.
    4. Provide specific, actionable tips for the user to improve their photo if quality is low. 
       - Focus on Lighting (e.g., "Move to a brighter area", "Avoid direct glare on the label").
       - Focus on Focus (e.g., "Hold the camera steady", "Tap the screen to focus on the text").
       - Focus on Framing (e.g., "Flatten the label", "Get closer to the text", "Ensure the entire table is visible").
    5. Assign a confidence score (0-100) based on how clearly the text can be read.
    
    Return the result in JSON format matching the provided schema.
  `;

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: "gemini-3.1-flash-lite-preview",
    contents: [
      {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageBase64.split(",")[1] || imageBase64,
            },
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: OCR_SCHEMA,
      temperature: 0,
      seed: 42,
    },
  });

  return JSON.parse(response.text || "{}") as OcrResult;
}

export async function analyzeNutritionLabel(
  imageBase64: string,
  userProfile: UserProfile,
  verifiedNutrients?: OcrNutrients,
  verifiedIngredients?: string[],
  dataSource: DataSource = 'ocr',
  productName?: string
): Promise<AnalysisResult> {
  const prompt = `
    ACT AS: "NutriScan Digital Nutritionist," a high-precision AI specialized in Bangladeshi food science, safety, and nutrition.
    
    PRODUCT TO ANALYZE: ${productName || "Identify from image"}
    
    CORE MISSION:
    Analyze food (Packaged Labels OR Open Plates/Street Food) for the Bangladeshi context. Provide a 0-100 Health Score and a visual dashboard-ready breakdown.
    
    SCORING CONSISTENCY:
    Your 0-100 Health Score must be consistent. If you identify the same product variant, the score should be identical regardless of whether you read the ingredients from the image or retrieved them from the web.
    
    USER PROFILE & MODE:
    - Language: ${userProfile.language}
    - Mode: ${userProfile.mode} (If 'halal', prioritize additive source check. If 'diabetic', focus on GI and sugar spikes. If 'kid-safe', flag hyperactivity-linked dyes).

    I. ANALYSIS ENGINE:
    1. NUTRITION SCORE (0-100): Based on WHO guidelines for sugar, sodium, and fats (especially palm/soybean oil).
       - 90-100: Natural, whole foods, no added sugar/excess sodium.
       - 70-89: Minimally processed, healthy fats.
       - 40-69: Processed, contains some unhealthy additives or moderate sugar/sodium.
       - 0-39: Ultra-processed, high sugar/sodium, trans fats, or risky additives.
    2. NOVA CLASSIFICATION: 
       - 1: Natural/Unprocessed
       - 2: Processed culinary ingredients
       - 3: Processed foods
       - 4: Ultra-processed (Heavily penalize these).
    3. ADDITIVE RISK: Detect E-numbers. Categorize as Safe/Moderate/Risky.
    4. PURITY GRADE (A-F): Simulate BSTI alerts. Flag formalin, textile dyes, or impure oils common in BD.
    5. ALLERGEN DETECTION: Identify potential allergens (e.g., nuts, dairy, soy, gluten, shellfish). Highlight them in the ingredientInsights section with category 'allergen'.

    II. BANGLADESH-SPECIFIC INTELLIGENCE:
    1. IDENTIFY: Specific local dishes (Kacchi, Tehari, Singara, etc.).
    2. GREASE SCALE: Estimate oil risk (Low/Medium/High) and reused oil oxidation.
    3. PORTION ESTIMATION: Use visual cues (hand/spoon) to estimate volume.

    III. SMART OUTPUT (Visual Dashboard Data):
    1. HEALTH BATTERY: 0-100 impact on energy.
    2. SMART PLATE: Breakdown into Carbs, Protein, Fat, Fiber percentages.
    3. COMPONENT BREAKDOWN: Detailed percentages for visual bars.
    4. NUTRITION PER TAKA: Value for money assessment.

    IV. STRICT ANTI-HALLUCINATION:
    - If nutrition values are not visible, use the 'googleSearch' tool to find the official nutritional information for "${productName || "this product"}".
    - If still not found, estimate based on dish type but mark confidence accordingly.
    - "dataSource" MUST be "${dataSource}".

    V. LANGUAGE: Provide content in ${userProfile.language === 'bn' ? 'Bangla' : 'English'}.
    
    VI. RECOMMENDATION QUALITY:
    - All "Better Desi Alternatives" MUST be scientifically healthier (lower GI, lower sodium, or higher fiber) than the original product.
    - Never recommend deep-fried items as healthy alternatives.
    - Focus on traditional, whole-food Bangladeshi options (e.g., Panta Bhat, Lal Shak, Daal, etc.).

    Return JSON matching the schema.
  `;

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: "gemini-3.1-flash-lite-preview",
    contents: [
      {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageBase64.split(",")[1] || imageBase64,
            },
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: ANALYSIS_SCHEMA,
      tools: [{ googleSearch: {} }],
      temperature: 0,
      seed: 42,
    },
  });

  const result = JSON.parse(response.text || "{}");
  result.dataSource = result.dataSource || dataSource;
  result.mode = result.mode || 'full';
  result.evaluation = result.evaluation || 'average';
  result.halalStatus = result.halalStatus || 'doubtful';
  result.glutenFreeStatus = result.glutenFreeStatus || 'may-contain';
  result.diabeticFriendly = result.diabeticFriendly !== undefined ? result.diabeticFriendly : false;
  result.kidSafe = result.kidSafe !== undefined ? result.kidSafe : false;
  if (result.novaClassification) {
    result.novaClassification = parseInt(result.novaClassification as string, 10);
  }
  return result as AnalysisResult;
}

export async function analyzeProductIngredients(
  imageBase64: string,
  userProfile: UserProfile,
  dataSource: DataSource = 'ocr',
  productName?: string
): Promise<ProductAnalysisResult> {
  const prompt = `
    ACT AS: "ProductSafety AI," an expert in chemical safety, toxicology, and environmental impact for non-food consumer products (cosmetics, cleaners, OTC medicines, etc.).
    
    PRODUCT TO ANALYZE: ${productName || "Identify from image"}
    
    CORE MISSION:
    Analyze the ingredient list of a non-food product. Provide a 0-100 Safety Score and a detailed breakdown of each ingredient's purpose and safety.
    
    TASKS:
    1. Identify the EXACT product name and variant (e.g., "Sunsilk Black Shine" vs "Sunsilk Soft & Smooth"). This is critical for accurate ingredient analysis.
    2. Extract and analyze each ingredient. 
       - If ingredients are visible in the image (back of bottle), use those.
       - If ingredients are NOT visible (front of bottle), use the 'googleSearch' tool to find the OFFICIAL ingredient list for the EXACT variant identified in step 1.
    3. SCORING CONSISTENCY: Your 0-100 Safety Score must be consistent. If you identify the same product variant, the score should be identical regardless of whether you read the ingredients from the image or retrieved them from the web.
    4. Assign a safety rating (Safe/Caution/Hazardous) to each ingredient.
    5. ALLERGEN DETECTION: Identify potential allergens (e.g., fragrance, parabens, sulfates, specific botanical extracts). Flag them clearly in the ingredients list.
    6. Provide usage advice and health alerts (e.g., skin irritation, toxicity).
    7. Assess environmental impact if possible.
    8. Provide a simple explanation of the overall safety.
    9. For cosmetics, assess skin type suitability (oily, dry, sensitive, acne-prone).
    10. Determine if the product is likely Vegan, Cruelty-Free, and Pregnancy-Safe.
    11. Assign a 0-10 Hazard Level (0 is lowest hazard, 10 is highest).
    12. Provide shelf life or storage guidance.
    
    LANGUAGE: Provide content in ${userProfile.language === 'bn' ? 'Bangla' : 'English'}.
    
    Return JSON matching the PRODUCT_ANALYSIS_SCHEMA.
  `;

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: "gemini-3.1-flash-lite-preview",
    contents: [
      {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageBase64.split(",")[1] || imageBase64,
            },
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: PRODUCT_ANALYSIS_SCHEMA,
      tools: [{ googleSearch: {} }],
      temperature: 0,
      seed: 42,
    },
  });

  const result = JSON.parse(response.text || "{}");
  result.overallSafety = result.overallSafety || 'caution';
  result.safetyScore = result.safetyScore !== undefined ? result.safetyScore : 50;
  result.dataSource = result.dataSource || dataSource;
  return result as ProductAnalysisResult;
}

export async function analyzePharmaIngredients(
  imageBase64: string,
  userProfile: UserProfile,
  dataSource: DataSource = 'ocr',
  productName?: string
): Promise<PharmaAnalysisResult> {
  const prompt = `
    ACT AS: "PharmaSafe AI," an expert in pharmacology, clinical pharmacy, and drug safety.
    
    PRODUCT TO ANALYZE: ${productName || "Identify from image"}
    
    CORE MISSION:
    Analyze the label/ingredients of a pharmaceutical product (medicine, supplement, etc.). Provide a detailed breakdown of active/inactive ingredients, indications, warnings, and safety information.
    
    TASKS:
    1. Identify the product name and manufacturer.
    2. Extract active ingredients, their strengths (e.g., 500mg), and their specific purposes. If not visible, use the 'googleSearch' tool to find the official information for "${productName || "this medicine"}".
    3. List inactive ingredients (excipients).
    4. Identify indications (what the medicine is used for).
    5. Provide clear dosage instructions.
    6. List critical warnings and contraindications.
    7. List potential side effects and drug/food interactions.
    8. Identify the pregnancy category if identifiable.
    9. Determine if it is an Over-The-Counter (OTC) or Prescription-only medicine.
    10. Provide a 0-100 Safety Score based on common usage risks.
    11. Provide a simple, beginner-friendly explanation.
    
    LANGUAGE: Provide content in ${userProfile.language === 'bn' ? 'Bangla' : 'English'}.
    
    Return JSON matching the PHARMA_ANALYSIS_SCHEMA.
  `;

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: "gemini-3.1-flash-lite-preview",
    contents: [
      {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageBase64.split(",")[1] || imageBase64,
            },
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: PHARMA_ANALYSIS_SCHEMA,
      tools: [{ googleSearch: {} }],
      temperature: 0,
      seed: 42,
    },
  });

  const result = JSON.parse(response.text || "{}");
  result.type = 'pharma';
  result.safetyScore = result.safetyScore !== undefined ? result.safetyScore : 50;
  result.activeIngredients = result.activeIngredients || [];
  result.isOtc = result.isOtc !== undefined ? result.isOtc : true;
  result.dataSource = result.dataSource || dataSource;
  return result as PharmaAnalysisResult;
}

export async function analyzeElectricalIngredients(
  imageBase64: string,
  userProfile: UserProfile,
  dataSource: DataSource = 'ocr',
  productName?: string
): Promise<ElectricalAnalysisResult> {
  const prompt = `
    ACT AS: "VoltGuard AI," an expert in electrical engineering, product safety, and regulatory compliance.
    
    PRODUCT TO ANALYZE: ${productName || "Identify from image"}
    
    CORE MISSION:
    Analyze the label, specifications, or materials of an electrical product (appliance, gadget, component). Provide a detailed breakdown of technical specs, materials, safety features, and certifications.
    
    TASKS:
    1. Identify the product name, brand, and model number.
    2. Extract technical specifications (Voltage, Power/Wattage, Current, Frequency). If not visible, use the 'googleSearch' tool to find the official specs for "${productName || "this product"}".
    3. Identify key materials used (e.g., Copper, PVC, Aluminum) and their purpose.
    4. List safety certifications (e.g., CE, UL, RoHS, BSTI).
    5. Identify built-in safety features (e.g., Overload protection, Grounding, Insulation).
    6. Identify energy efficiency ratings.
    7. List critical hazard warnings (e.g., High voltage, Water hazard, Fire risk).
    8. Provide clear usage instructions for safety.
    9. Assess environmental impact (recyclability, hazardous materials like Lead or Mercury).
    10. Provide a 0-100 Safety Score based on build quality and safety features.
    11. Provide a simple, beginner-friendly explanation.
    
    LANGUAGE: Provide content in ${userProfile.language === 'bn' ? 'Bangla' : 'English'}.
    
    Return JSON matching the ELECTRICAL_ANALYSIS_SCHEMA.
  `;

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: "gemini-3.1-flash-lite-preview",
    contents: [
      {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageBase64.split(",")[1] || imageBase64,
            },
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: ELECTRICAL_ANALYSIS_SCHEMA,
      tools: [{ googleSearch: {} }],
      temperature: 0,
      seed: 42,
    },
  });

  const result = JSON.parse(response.text || "{}");
  result.type = 'electrical';
  result.safetyScore = result.safetyScore !== undefined ? result.safetyScore : 50;
  result.specifications = result.specifications || {};
  result.materials = result.materials || [];
  result.dataSource = result.dataSource || dataSource;
  return result as ElectricalAnalysisResult;
}

export async function identifyProductByImage(
  imageBase64: string,
  userProfile: UserProfile
): Promise<{ productName: string; productType: 'food' | 'non-food' | 'pharma' | 'electrical' }> {
  const prompt = `
    Identify the product in this image. 
    
    CRITICAL: 
    - Look for the brand name, product name, and any identifying text.
    - If a barcode is visible but blurry, try to read the numbers below it.
    - If you are unsure of the exact product, provide your best guess based on the packaging design and visible keywords.
    - NEVER return an empty productName if there is any text or recognizable packaging in the image.
    
    Tasks:
    1. Extract the product name and brand (e.g., "Maggi 2-Minute Noodles", "Dove Deep Moisture Body Wash").
    2. Determine the category: 
       - 'food': Edible products, snacks, drinks.
       - 'pharma': Medicines, supplements, syrups, tablets.
       - 'electrical': Gadgets, chargers, appliances, batteries.
       - 'non-food': Cosmetics, soaps, detergents, household items.
    
    Return JSON: { "productName": "string", "productType": "food" | "non-food" | "pharma" | "electrical" }
  `;

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageBase64.split(",")[1] || imageBase64,
            },
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          productName: { type: Type.STRING },
          productType: { type: Type.STRING, enum: ["food", "non-food", "pharma", "electrical"] }
        },
        required: ["productName", "productType"]
      },
      tools: [{ googleSearch: {} }],
      temperature: 0,
      seed: 42,
    },
  });

  return JSON.parse(response.text || "{}");
}
