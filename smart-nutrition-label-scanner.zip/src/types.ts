export type AppLanguage = 'bn' | 'en' | 'hi' | 'zh' | 'es' | 'ar';

export type UserMode = 'general' | 'halal' | 'diabetic' | 'kid-safe';

export interface UserProfile {
  language: AppLanguage;
  mode: UserMode;
}

export interface Nutrient {
  name: string;
  value: number;
  unit: string;
  dailyValuePercentage?: number;
  status: 'low' | 'moderate' | 'high';
}

export interface HiddenIngredient {
  name: string;
  warning: string;
  risk: string;
}

export interface WHOComparison {
  nutrientName: string;
  currentValue: number;
  whoLimit: number;
  unit: string;
  isExceeded: boolean;
  explanation: string;
}

export interface ScoreFactor {
  name: string;
  impact: number; // e.g., -25 or +10
  reason: string;
}

export interface Micronutrient {
  name: string;
  value: number;
  unit: string;
  dailyValuePercentage?: number;
}

export interface IngredientInsight {
  name: string;
  category: 'allergen' | 'additive' | 'detrimental';
  riskLevel: 'low' | 'moderate' | 'high';
  description: string;
}

export type ConfidenceLevel = 'high' | 'medium' | 'low';
export type AnalysisMode = 'full' | 'ingredient-only' | 'limited';
export type DataSource = 'ocr' | 'user-input' | 'database' | 'barcode';

export interface OcrNutrients {
  calories?: number;
  sugar?: number;
  sodium?: number;
  fat?: number;
  protein?: number;
  carbohydrates?: number;
  fiber?: number;
}

export interface OcrResult {
  nutrients: OcrNutrients;
  ingredients: string[];
  confidenceScore: number; // 0-100
  imageQuality: {
    isClear: boolean;
    reason?: string;
    tips?: string[];
  };
}

export type EvaluationStatus = 'excellent' | 'good' | 'average' | 'poor';

export interface IngredientSafety {
  name: string;
  purpose: string;
  safetyRating: 'safe' | 'caution' | 'hazardous';
  description: string;
  isAllergen?: boolean;
  alternatives?: string[];
}

export interface ProductAnalysisResult {
  productName?: string;
  productCategory?: string;
  safetyScore: number;
  overallSafety: 'safe' | 'caution' | 'hazardous';
  ingredients: IngredientSafety[];
  usageAdvice: string[];
  healthAlerts: string[];
  environmentalImpact?: string;
  simpleExplanation: string;
  skinSuitability?: {
    oily: string;
    dry: string;
    sensitive: string;
    acneProne: string;
  };
  isVegan?: boolean;
  isCrueltyFree?: boolean;
  pregnancySafe?: boolean;
  hazardLevel?: number; // 0-10 scale
  shelfLifeGuidance?: string;
  dataSource: DataSource;
  confidence: {
    score: number;
    level: ConfidenceLevel;
  };
  timestamp?: any;
}

export interface ElectricalAnalysisResult {
  productName?: string;
  brand?: string;
  modelNumber?: string;
  specifications: {
    voltage?: string;
    power?: string;
    current?: string;
    frequency?: string;
  };
  materials: {
    name: string;
    purpose: string;
    safetyNote?: string;
  }[];
  certifications: string[];
  safetyFeatures: string[];
  energyEfficiency?: string;
  hazardWarnings: string[];
  usageInstructions: string[];
  environmentalImpact: string;
  dataSource: DataSource;
  safetyScore: number; // 0-100
  simpleExplanation: string;
  confidence: {
    score: number;
    level: ConfidenceLevel;
  };
  timestamp?: any;
  type: 'electrical';
}

export interface PharmaAnalysisResult {
  productName?: string;
  manufacturer?: string;
  activeIngredients: {
    name: string;
    strength: string;
    purpose: string;
  }[];
  inactiveIngredients: string[];
  indications: string[];
  dosageInstructions: string;
  warnings: string[];
  sideEffects: string[];
  interactions: string[];
  pregnancyCategory?: string;
  isOtc: boolean;
  dataSource: DataSource;
  safetyScore: number; // 0-100
  simpleExplanation: string;
  confidence: {
    score: number;
    level: ConfidenceLevel;
  };
  timestamp?: any;
  type: 'pharma';
}

export interface AnalysisResult {
  productName?: string;
  mode: AnalysisMode;
  dataSource: DataSource;
  healthScore?: number; // 0-100
  evaluation: EvaluationStatus;
  confidence: {
    score: number;
    level: ConfidenceLevel;
  };
  nutrients?: {
    calories: Nutrient;
    sugar: Nutrient;
    sodium: Nutrient;
    fat: {
      total: Nutrient;
      saturated: Nutrient;
      trans: Nutrient;
    };
    protein: Nutrient;
    carbohydrates: Nutrient;
    fiber: Nutrient;
  };
  micronutrients?: Micronutrient[];
  ingredientInsights: IngredientInsight[];
  hiddenIngredients: HiddenIngredient[];
  whoComparison: WHOComparison[];
  scoreBreakdown: ScoreFactor[];
  simpleExplanation: string;
  healthSuggestions: string[];
  localFoodWarnings?: string[];
  localAlternatives?: string[];
  nutritionalEstimate?: {
    calories: string;
    sugarCarbs: 'Low' | 'Medium' | 'High';
    oilFatQuality: string;
    protein: string;
  };
  healthAlerts: string[];
  desiAlternative: string;
  privacyNote: string;
  visualBar: string;
  componentBreakdown: {
    carbs: number;
    carbsType: string;
    greaseScale: number;
    oilType: string;
    protein: number;
    proteinType: string;
    fiberVeggies: number;
    veggieType: string;
  };
  desiSafetyAlerts: {
    purity: string;
    bloodSugarImpact: string;
  };
  hyperLocalSwap: {
    insteadOf: string;
    tryThis: string;
    benefit: string;
  };
  nutritionPerTaka: string;
  novaClassification: 1 | 2 | 3 | 4;
  additiveRisk: 'safe' | 'moderate' | 'risky';
  purityGrade: 'A' | 'B' | 'C' | 'D' | 'F';
  halalStatus?: 'halal' | 'doubtful' | 'not-halal';
  glutenFreeStatus?: 'gluten-free' | 'contains-gluten' | 'may-contain';
  diabeticFriendly?: boolean;
  kidSafe?: boolean;
  healthBattery: number; // 0-100
  smartPlate: {
    carbs: number;
    protein: number;
    fat: number;
    fiber: number;
  };
  timestamp?: any;
}
