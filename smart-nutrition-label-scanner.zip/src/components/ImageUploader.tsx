import React, { useRef, useState } from 'react';
import { Camera, Upload, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { translations } from '../translations';
import { AppLanguage } from '../types';

interface ImageUploaderProps {
  onImageSelect: (base64: string) => void;
  isAnalyzing: boolean;
  language: AppLanguage;
  productType: 'food' | 'non-food' | 'pharma' | 'electrical';
}

export default function ImageUploader({ onImageSelect, isAnalyzing, language, productType }: ImageUploaderProps) {
  const t = translations[language];
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const labelText = productType === 'food' ? t.scanLabel : productType === 'pharma' ? t.pharmaProduct : t.scanProduct;
  const colorClass = productType === 'food' ? 'emerald' : productType === 'pharma' ? 'purple' : 'blue';

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setPreview(base64);
        onImageSelect(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImage = () => {
    setPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <AnimatePresence mode="wait">
        {!preview ? (
          <motion.div
            key="upload-area"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="relative group space-y-4"
          >
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleFileChange}
              className="hidden"
              ref={fileInputRef}
              aria-label="Upload Nutrition Label Image"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className={cn(
                "w-full h-64 border-2 border-dashed rounded-3xl flex flex-col items-center justify-center gap-4 transition-all",
                productType === 'food' 
                  ? "border-emerald-200 hover:border-emerald-400 hover:bg-emerald-50/50" 
                  : productType === 'pharma'
                  ? "border-purple-200 hover:border-purple-400 hover:bg-purple-50/50"
                  : "border-blue-200 hover:border-blue-400 hover:bg-blue-50/50",
                isAnalyzing && "pointer-events-none opacity-50"
              )}
              aria-label={labelText}
            >
              <div className={cn(
                "w-16 h-16 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform",
                productType === 'food' ? "bg-emerald-100" : productType === 'pharma' ? "bg-purple-100" : "bg-blue-100"
              )}>
                <Camera className={cn("w-8 h-8", productType === 'food' ? "text-emerald-600" : productType === 'pharma' ? "text-purple-600" : "text-blue-600")} />
              </div>
              <div className="text-center px-4">
                <p className="text-xl font-black text-gray-900">{labelText}</p>
                <p className="text-sm font-medium text-gray-500 mt-1">{t.uploadPhoto}</p>
              </div>
              <div className={cn(
                "flex items-center gap-2 px-6 py-2.5 border rounded-full text-sm font-black shadow-sm group-hover:shadow-lg transition-all",
                productType === 'food' 
                  ? "bg-white border-emerald-100 text-emerald-700" 
                  : productType === 'pharma'
                  ? "bg-white border-purple-100 text-purple-700"
                  : "bg-white border-blue-100 text-blue-700"
              )}>
                <Upload className="w-4 h-4" />
                {t.selectImage}
              </div>
            </button>

            {/* Troubleshooting Tip */}
            <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 flex items-start gap-3">
              <div className="p-1.5 bg-white rounded-lg shadow-sm text-amber-600">
                <Camera className="w-4 h-4" />
              </div>
              <div className="space-y-1">
                <p className="text-xs font-black text-amber-900 uppercase tracking-widest">Camera not working?</p>
                <p className="text-[11px] font-bold text-amber-700 leading-relaxed">
                  If the camera doesn't open, ensure you've granted permission. If you're using a shared link inside an app (like WhatsApp or Facebook), try opening the link in your phone's main browser (Chrome or Safari).
                </p>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="preview-area"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative rounded-3xl overflow-hidden shadow-xl border-4 border-white aspect-video bg-gray-100"
          >
            <img
              src={preview}
              alt="Label Preview"
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
            
            <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
              {isAnalyzing && (
                <div className="bg-white/90 backdrop-blur-sm px-8 py-5 rounded-2xl flex items-center gap-4 shadow-2xl">
                  <Loader2 className={cn("w-7 h-7 animate-spin", productType === 'food' ? "text-emerald-600" : productType === 'pharma' ? "text-purple-600" : "text-blue-600")} />
                  <span className={cn("text-lg font-black", productType === 'food' ? "text-emerald-950" : productType === 'pharma' ? "text-purple-950" : "text-blue-950")}>{t.analyzing}</span>
                </div>
              )}
            </div>

            {!isAnalyzing && (
              <button
                onClick={clearImage}
                className="absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center text-gray-600 hover:text-red-500 hover:bg-white transition-all shadow-lg"
                aria-label="Clear Selected Image"
              >
                <X className="w-6 h-6" />
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
