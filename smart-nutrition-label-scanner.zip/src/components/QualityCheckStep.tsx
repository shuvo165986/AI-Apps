import React from 'react';
import { OcrResult, AppLanguage } from '../types';
import { translations } from '../translations';
import { motion } from 'motion/react';
import { AlertCircle, Camera, Lightbulb, Focus, ShieldAlert, RefreshCcw } from 'lucide-react';
import { cn } from '../lib/utils';

interface QualityCheckStepProps {
  ocrResult: OcrResult;
  language: AppLanguage;
  onRetake: () => void;
  onManualInput: () => void;
}

export default function QualityCheckStep({ ocrResult, language, onRetake, onManualInput }: QualityCheckStepProps) {
  const t = translations[language];
  const { imageQuality } = ocrResult;

  return (
    <div className="max-w-2xl mx-auto space-y-8 p-6">
      <div className="text-center space-y-4">
        <div className="w-20 h-20 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto animate-bounce">
          <ShieldAlert className="w-10 h-10" />
        </div>
        <div className="space-y-2">
          <h2 className="text-3xl font-black text-gray-900 tracking-tight">{t.unclearImage}</h2>
          <p className="text-red-600 font-bold">{imageQuality.reason || "Image quality is too low for reliable analysis."}</p>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
        <div className="p-8 space-y-8">
          <div className="space-y-4">
            <h3 className="text-xl font-black text-gray-800 flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-amber-500" />
              {t.improvePhotoTips || "Tips for a Better Photo"}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-100 space-y-2">
                <div className="flex items-center justify-between">
                  <Lightbulb className="w-6 h-6 text-amber-600" />
                  <span className="text-[10px] font-black text-amber-400 uppercase tracking-widest">Lighting</span>
                </div>
                <p className="text-xs font-bold text-amber-900 uppercase tracking-wider">{t.goodLighting || "Good Lighting"}</p>
                <p className="text-[10px] text-amber-700 font-medium">{t.avoidGlare || "Avoid shadows and direct glare on the label ☀️"}</p>
              </div>
              <div className="p-4 rounded-2xl bg-blue-50 border border-blue-100 space-y-2">
                <div className="flex items-center justify-between">
                  <Focus className="w-6 h-6 text-blue-600" />
                  <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Focus</span>
                </div>
                <p className="text-xs font-bold text-blue-900 uppercase tracking-wider">{t.steadyCamera || "Steady Camera"}</p>
                <p className="text-[10px] text-blue-700 font-medium">{t.tapToFocus || "Hold steady and tap the screen to focus 📷"}</p>
              </div>
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-100 space-y-2">
                <div className="flex items-center justify-between">
                  <Camera className="w-6 h-6 text-emerald-600" />
                  <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Framing</span>
                </div>
                <p className="text-xs font-bold text-emerald-900 uppercase tracking-wider">{t.fullLabel || "Full Label"}</p>
                <p className="text-[10px] text-emerald-700 font-medium">{t.flattenLabel || "Flatten the label and capture all edges 📦"}</p>
              </div>
            </div>
          </div>

          {imageQuality.tips && imageQuality.tips.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-black text-gray-400 uppercase tracking-widest ml-1">{t.specificRecs || "Specific Recommendations"}</h4>
              <div className="grid grid-cols-1 gap-2">
                {imageQuality.tips.map((tip, i) => {
                  const isLighting = tip.toLowerCase().includes('light') || tip.toLowerCase().includes('glare') || tip.toLowerCase().includes('shadow');
                  const isFocus = tip.toLowerCase().includes('focus') || tip.toLowerCase().includes('steady') || tip.toLowerCase().includes('blur');
                  const isFraming = tip.toLowerCase().includes('frame') || tip.toLowerCase().includes('edge') || tip.toLowerCase().includes('closer') || tip.toLowerCase().includes('flatten');

                  return (
                    <motion.div 
                      key={i} 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className={cn(
                        "flex items-center gap-3 p-4 rounded-2xl border transition-all",
                        isLighting ? "bg-amber-50/50 border-amber-100" :
                        isFocus ? "bg-blue-50/50 border-blue-100" :
                        isFraming ? "bg-emerald-50/50 border-emerald-100" :
                        "bg-gray-50 border-gray-100"
                      )}
                    >
                      <div className={cn(
                        "w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-sm",
                        isLighting ? "bg-amber-500" :
                        isFocus ? "bg-blue-500" :
                        isFraming ? "bg-emerald-500" :
                        "bg-gray-400"
                      )}>
                        {isLighting ? <Lightbulb className="w-4 h-4" /> :
                         isFocus ? <Focus className="w-4 h-4" /> :
                         isFraming ? <Camera className="w-4 h-4" /> :
                         <AlertCircle className="w-4 h-4" />}
                      </div>
                      <p className="text-sm text-gray-700 font-bold leading-tight">{tip}</p>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="p-4 bg-gray-50 flex gap-3">
          <button
            onClick={onRetake}
            className="flex-1 flex items-center justify-center gap-2 py-4 rounded-2xl bg-emerald-600 text-white font-black shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all"
          >
            <RefreshCcw className="w-5 h-5" />
            {t.retakePhoto}
          </button>
          <button
            onClick={onManualInput}
            className="flex-1 flex items-center justify-center gap-2 py-4 rounded-2xl bg-white border border-gray-200 text-gray-600 font-black hover:bg-gray-50 transition-all"
          >
            {t.manualInput}
          </button>
        </div>
      </div>
    </div>
  );
}
