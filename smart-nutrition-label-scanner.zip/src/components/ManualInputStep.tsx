import React from 'react';
import { OcrNutrients, AppLanguage } from '../types';
import { translations } from '../translations';
import { motion } from 'motion/react';
import { Check, Keyboard, ArrowLeft } from 'lucide-react';
import { cn } from '../lib/utils';

interface ManualInputStepProps {
  language: AppLanguage;
  onConfirm: (nutrients: OcrNutrients, ingredients: string[]) => void;
  onBack: () => void;
  initialNutrients?: OcrNutrients;
  initialIngredients?: string[];
}

export default function ManualInputStep({ language, onConfirm, onBack, initialNutrients, initialIngredients }: ManualInputStepProps) {
  const t = translations[language];
  const [nutrients, setNutrients] = React.useState<OcrNutrients>(initialNutrients || {
    calories: undefined,
    sugar: undefined,
    sodium: undefined,
    fat: undefined,
    protein: undefined,
    carbohydrates: undefined,
    fiber: undefined
  });
  const [ingredientsText, setIngredientsText] = React.useState(initialIngredients?.join(', ') || '');

  const handleNutrientChange = (key: keyof OcrNutrients, value: string) => {
    const numValue = parseFloat(value);
    setNutrients(prev => ({ ...prev, [key]: isNaN(numValue) ? undefined : numValue }));
  };

  const handleSubmit = () => {
    const ingredients = ingredientsText.split(',').map(i => i.trim()).filter(i => i.length > 0);
    onConfirm(nutrients, ingredients);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 p-6">
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-100 text-blue-700 font-bold text-sm">
          <Keyboard className="w-4 h-4" />
          {t.manualInput}
        </div>
        <h2 className="text-3xl font-black text-gray-900 tracking-tight">{t.manualInput}</h2>
        <p className="text-gray-500 font-medium">Type in the values from the nutrition label manually.</p>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
        <div className="p-8 space-y-8">
          <div className="grid grid-cols-2 gap-6">
            {Object.entries({
              calories: 'Calories (kcal)',
              sugar: 'Sugar (g)',
              sodium: 'Sodium (mg)',
              fat: 'Total Fat (g)',
              protein: 'Protein (g)',
              carbohydrates: 'Carbs (g)',
              fiber: 'Fiber (g)'
            }).map(([key, label]) => (
              <div key={key} className="space-y-1.5">
                <label htmlFor={`input-${key}`} className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">{label}</label>
                <input
                  id={`input-${key}`}
                  type="number"
                  placeholder="0"
                  value={nutrients[key as keyof OcrNutrients] ?? ''}
                  onChange={(e) => handleNutrientChange(key as keyof OcrNutrients, e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 font-bold focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 transition-all outline-none"
                  aria-label={label}
                />
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <label htmlFor="input-ingredients" className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Ingredients (comma separated)</label>
            <textarea
              id="input-ingredients"
              placeholder="e.g. Whole wheat, Sugar, Salt, Palm oil..."
              value={ingredientsText}
              onChange={(e) => setIngredientsText(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 font-bold focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 transition-all outline-none min-h-[120px] resize-none"
              aria-label="Ingredients List"
            />
          </div>
        </div>

        <div className="p-4 bg-gray-50 flex gap-3">
          <button
            onClick={onBack}
            className="flex-1 flex items-center justify-center gap-2 py-4 rounded-2xl font-black text-gray-600 hover:bg-gray-100 transition-all"
            aria-label="Go Back to Previous Step"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <button
            onClick={handleSubmit}
            className="flex-[2] flex items-center justify-center gap-2 py-4 rounded-2xl bg-emerald-600 text-white font-black shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all"
            aria-label="Confirm and Analyze Nutrition Data"
          >
            <Check className="w-5 h-5" />
            {t.confirmAnalysis}
          </button>
        </div>
      </div>
    </div>
  );
}
