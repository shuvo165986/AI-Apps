import React from 'react';
import { ProductAnalysisResult, IngredientSafety, AppLanguage } from '../types';
import { motion } from 'motion/react';
import { ShieldCheck, AlertTriangle, CheckCircle2, Info, FlaskConical, Leaf, Activity, ArrowLeft, Heart, Sparkles, Baby, Clock, Droplets, Sun, Wind, Flame, AlertCircle, Globe } from 'lucide-react';
import { cn } from '../lib/utils';
import { translations } from '../translations';

interface ProductAnalysisDashboardProps {
  result: ProductAnalysisResult;
  onBack: () => void;
  language: AppLanguage;
}

export default function ProductAnalysisDashboard({ result, onBack, language }: ProductAnalysisDashboardProps) {
  const t = translations[language];
  const isBn = language === 'bn';

  const getSafetyColor = (rating: 'safe' | 'caution' | 'hazardous') => {
    switch (rating) {
      case 'safe': return 'text-emerald-600 bg-emerald-50 border-emerald-100';
      case 'caution': return 'text-amber-600 bg-amber-50 border-amber-100';
      case 'hazardous': return 'text-red-600 bg-red-50 border-red-100';
    }
  };

  const getSafetyIcon = (rating: 'safe' | 'caution' | 'hazardous') => {
    switch (rating) {
      case 'safe': return <CheckCircle2 className="w-5 h-5" />;
      case 'caution': return <AlertTriangle className="w-5 h-5" />;
      case 'hazardous': return <AlertTriangle className="w-5 h-5" />;
    }
  };

  const getHazardColor = (level: number) => {
    if (level <= 2) return 'text-emerald-500 bg-emerald-50';
    if (level <= 6) return 'text-amber-500 bg-amber-50';
    return 'text-red-500 bg-red-50';
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button 
          onClick={onBack}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="text-center flex-1 pr-10">
          <div className="flex items-center justify-center gap-2 mb-1">
            <h2 className="text-2xl font-black text-gray-900">{result.productName || (isBn ? 'পণ্য বিশ্লেষণ' : 'Product Analysis')}</h2>
            {result.dataSource === 'ocr' ? (
              <div className="flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-black uppercase tracking-tighter">
                <ShieldCheck className="w-3 h-3" />
                {isBn ? 'যাচাইকৃত' : 'Verified'}
              </div>
            ) : (
              <div className="flex items-center gap-1 px-2 py-0.5 bg-blue-100 text-blue-700 rounded-lg text-[10px] font-black uppercase tracking-tighter">
                <Globe className="w-3 h-3" />
                {isBn ? 'ওয়েব সার্চ' : 'Web Search'}
              </div>
            )}
          </div>
          <p className="text-sm font-bold text-emerald-600 uppercase tracking-widest">{result.productCategory}</p>
        </div>
      </div>

      {/* Hero Safety Score & Hazard Level */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl text-center space-y-6"
        >
          <div className="relative inline-block">
            <svg className="w-40 h-40 transform -rotate-90">
              <circle
                cx="80"
                cy="80"
                r="70"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                className="text-gray-100"
              />
              <motion.circle
                cx="80"
                cy="80"
                r="70"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                strokeDasharray={440}
                initial={{ strokeDashoffset: 440 }}
                animate={{ strokeDashoffset: 440 - (440 * result.safetyScore) / 100 }}
                className={cn(
                  "transition-all duration-1000",
                  result.safetyScore > 70 ? "text-emerald-500" : result.safetyScore > 40 ? "text-amber-500" : "text-red-500"
                )}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-black text-gray-900">{result.safetyScore}</span>
              <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.safetyScore}</span>
            </div>
          </div>

          <div className="space-y-4">
            <div className={cn(
              "inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-sm",
              result.safetyScore > 70 ? "bg-emerald-100 text-emerald-700 border border-emerald-200" :
              result.safetyScore > 40 ? "bg-amber-100 text-amber-700 border border-amber-200" :
              "bg-red-100 text-red-700 border border-red-200"
            )}>
              {result.safetyScore > 70 ? (isBn ? 'নিরাপদ' : 'Safe') :
               result.safetyScore > 40 ? (isBn ? 'সতর্কতা' : 'Caution') :
               (isBn ? 'ঝুঁকিপূর্ণ' : 'Hazardous')}
            </div>

            <div className="w-full max-w-[200px] mx-auto space-y-1">
              <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${result.safetyScore}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className={cn(
                    "h-full transition-all duration-500",
                    result.safetyScore > 70 ? "bg-emerald-500" :
                    result.safetyScore > 40 ? "bg-amber-500" :
                    "bg-red-500"
                  )}
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className={cn(
              "inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-black uppercase tracking-widest",
              getSafetyColor(result.overallSafety)
            )}>
              {getSafetyIcon(result.overallSafety)}
              {result.overallSafety === 'safe' ? (isBn ? 'নিরাপদ' : 'Safe') : 
               result.overallSafety === 'caution' ? (isBn ? 'সতর্কতা' : 'Caution') : 
               (isBn ? 'ঝুঁকিপূর্ণ' : 'Hazardous')}
            </div>
            <p className="text-gray-600 font-medium leading-relaxed">
              {result.simpleExplanation}
            </p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl flex flex-col items-center justify-center space-y-6"
        >
          {result.hazardLevel !== undefined && (
            <div className="w-full space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-black uppercase tracking-widest text-xs text-gray-400">{t.hazardLevel}</h3>
                <span className={cn("px-3 py-1 rounded-lg text-lg font-black", getHazardColor(result.hazardLevel))}>
                  {result.hazardLevel}/10
                </span>
              </div>
              <div className="h-3 bg-gray-100 rounded-full overflow-hidden flex">
                <div 
                  className={cn("h-full transition-all duration-1000", result.hazardLevel <= 2 ? "bg-emerald-500" : result.hazardLevel <= 6 ? "bg-amber-500" : "bg-red-500")}
                  style={{ width: `${result.hazardLevel * 10}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] font-bold text-gray-400 uppercase tracking-tighter">
                <span>Low</span>
                <span>Moderate</span>
                <span>High</span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-3 gap-4 w-full">
            <div className={cn("p-3 rounded-2xl flex flex-col items-center gap-1 transition-all", result.isVegan ? "bg-emerald-50 text-emerald-600" : "bg-gray-50 text-gray-300")}>
              <Leaf className="w-5 h-5" />
              <span className="text-[10px] font-black uppercase">{t.vegan}</span>
            </div>
            <div className={cn("p-3 rounded-2xl flex flex-col items-center gap-1 transition-all", result.isCrueltyFree ? "bg-pink-50 text-pink-600" : "bg-gray-50 text-gray-300")}>
              <Heart className="w-5 h-5" />
              <span className="text-[10px] font-black uppercase">{t.crueltyFree}</span>
            </div>
            <div className={cn("p-3 rounded-2xl flex flex-col items-center gap-1 transition-all", result.pregnancySafe ? "bg-blue-50 text-blue-600" : "bg-gray-50 text-gray-300")}>
              <Baby className="w-5 h-5" />
              <span className="text-[10px] font-black uppercase">{t.pregnancySafe}</span>
            </div>
          </div>

          {result.shelfLifeGuidance && (
            <div className="w-full p-4 bg-gray-50 rounded-2xl flex items-center gap-3">
              <Clock className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.shelfLife}</p>
                <p className="text-xs font-bold text-gray-700">{result.shelfLifeGuidance}</p>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Skin Suitability */}
      {result.skinSuitability && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4"
        >
          <div className="flex items-center gap-3 text-emerald-600">
            <Sparkles className="w-6 h-6" />
            <h3 className="font-black uppercase tracking-widest text-sm">{t.skinSuitability}</h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { key: 'oily', label: t.oily, icon: <Droplets className="w-4 h-4" /> },
              { key: 'dry', label: t.dry, icon: <Sun className="w-4 h-4" /> },
              { key: 'sensitive', label: t.sensitive, icon: <Wind className="w-4 h-4" /> },
              { key: 'acneProne', label: t.acneProne, icon: <Flame className="w-4 h-4" /> }
            ].map((skin) => (
              <div key={skin.key} className="p-4 rounded-2xl bg-gray-50 space-y-2">
                <div className="flex items-center gap-2 text-gray-400">
                  {skin.icon}
                  <span className="text-[10px] font-black uppercase tracking-widest">{skin.label}</span>
                </div>
                <p className="text-xs font-bold text-gray-900 leading-tight">
                  {(result.skinSuitability as any)[skin.key]}
                </p>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Health Alerts */}
      {result.healthAlerts.length > 0 && (
        <div className="bg-red-50 border border-red-100 rounded-3xl p-6 space-y-4">
          <div className="flex items-center gap-3 text-red-600">
            <AlertTriangle className="w-6 h-6" />
            <h3 className="font-black uppercase tracking-widest text-sm">{isBn ? 'স্বাস্থ্য সতর্কতা' : 'Health Alerts'}</h3>
          </div>
          <ul className="space-y-2">
            {result.healthAlerts.map((alert, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-red-800 font-medium">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-red-400 shrink-0" />
                {alert}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Ingredient Visualizer */}
      <div className="space-y-4">
        <h3 className="text-lg font-black text-gray-900 px-2">{isBn ? 'উপাদান বিশ্লেষণ' : 'Ingredient Analysis'}</h3>
        <div className="grid gap-4">
          {result.ingredients.map((ing, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all group"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-black text-gray-900">{ing.name}</h4>
                    <span className="text-[10px] font-bold text-gray-400 bg-gray-50 px-2 py-0.5 rounded uppercase tracking-tighter">
                      {ing.purpose}
                    </span>
                    {ing.isAllergen && (
                      <span className="text-[9px] font-black text-red-600 bg-red-50 px-2 py-0.5 rounded-full uppercase tracking-widest flex items-center gap-1 border border-red-100">
                        <AlertCircle className="w-3 h-3" />
                        {t.allergens}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 font-medium leading-relaxed">
                    {ing.description}
                  </p>
                  {ing.alternatives && ing.alternatives.length > 0 && (
                    <div className="pt-2 flex flex-wrap gap-2">
                      <span className="text-[9px] font-black text-emerald-600 uppercase tracking-widest">{isBn ? 'বিকল্প:' : 'Alt:'}</span>
                      {ing.alternatives.map((alt, aidx) => (
                        <span key={aidx} className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                          {alt}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className={cn(
                  "px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border shrink-0",
                  getSafetyColor(ing.safetyRating)
                )}>
                  {ing.safetyRating}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Usage Advice & Environmental Impact */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-emerald-50 border border-emerald-100 rounded-3xl p-6 space-y-4">
          <div className="flex items-center gap-3 text-emerald-600">
            <Activity className="w-6 h-6" />
            <h3 className="font-black uppercase tracking-widest text-sm">{t.usageAdvice}</h3>
          </div>
          <ul className="space-y-2">
            {result.usageAdvice.map((advice, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-emerald-800 font-medium">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                {advice}
              </li>
            ))}
          </ul>
        </div>

        {result.environmentalImpact && (
          <div className="bg-blue-50 border border-blue-100 rounded-3xl p-6 space-y-4">
            <div className="flex items-center gap-3 text-blue-600">
              <Leaf className="w-6 h-6" />
              <h3 className="font-black uppercase tracking-widest text-sm">{t.ecoImpact}</h3>
            </div>
            <p className="text-sm text-blue-800 font-medium leading-relaxed">
              {result.environmentalImpact}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
