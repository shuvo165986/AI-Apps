import React, { useEffect, useState } from 'react';
import { db, collection, query, where, orderBy, onSnapshot, handleFirestoreError, OperationType } from '../lib/firebase';
import { AnalysisResult, ProductAnalysisResult, PharmaAnalysisResult, ElectricalAnalysisResult, AppLanguage } from '../types';
import { translations } from '../translations';
import { History, Calendar, ArrowRight, Trash2, ShieldCheck, FlaskConical, Layers, Check, Utensils, Sparkles, Pill, Zap, Filter, ChevronDown, ChevronUp, Search, X, RefreshCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { deleteDoc, doc } from 'firebase/firestore';
import { cn } from '../lib/utils';

type HistoryItem = (AnalysisResult | ProductAnalysisResult | PharmaAnalysisResult | ElectricalAnalysisResult) & { id: string; type?: 'food' | 'non-food' | 'pharma' | 'electrical' };

interface ScanHistoryProps {
  uid: string;
  language: AppLanguage;
  onSelect: (result: any) => void;
  onCompare: (results: any[]) => void;
}

export default function ScanHistory({ uid, language, onSelect, onCompare }: ScanHistoryProps) {
  const t = translations[language];
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCompareMode, setIsCompareMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    type: 'all',
    startDate: '',
    endDate: '',
    minScore: 0,
    maxScore: 100,
    nutrient: 'all',
    sortBy: 'date-desc'
  });

  useEffect(() => {
    const q = query(
      collection(db, 'scans'),
      where('uid', '==', uid),
      orderBy('timestamp', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const results = snapshot.docs.map(doc => {
        const data = doc.data();
        let timestamp = new Date();
        if (data.timestamp) {
          timestamp = data.timestamp.toDate ? data.timestamp.toDate() : new Date(data.timestamp);
        }
        return {
          id: doc.id,
          ...data,
          timestamp
        };
      }) as HistoryItem[];
      setHistory(results);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'scans');
      setLoading(false);
    });

    return () => unsubscribe();
  }, [uid]);

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    try {
      await deleteDoc(doc(db, 'scans', id));
      if (selectedIds.includes(id)) {
        setSelectedIds(prev => prev.filter(i => i !== id));
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `scans/${id}`);
    }
  };

  const toggleSelection = (id: string) => {
    const item = history.find(i => i.id === id);
    if (!item) return;

    setSelectedIds(prev => {
      if (prev.includes(id)) {
        return prev.filter(i => i !== id);
      }
      
      if (prev.length > 0) {
        const firstItem = history.find(i => i.id === prev[0]);
        const firstType = firstItem?.type || 'food';
        const currentType = item.type || 'food';
        
        if (firstType !== currentType) {
          alert(t.sameTypeComparisonOnly);
          return prev;
        }
      }

      if (prev.length >= 3) {
        alert(t.maxComparisonReached);
        return prev;
      }
      return [...prev, id];
    });
  };

  const handleCompareClick = () => {
    const selectedScans = history.filter(item => selectedIds.includes(item.id));
    onCompare(selectedScans);
  };

  const filteredHistory = history.filter(item => {
    const itemType = item.type || 'food';
    if (filters.type !== 'all' && itemType !== filters.type) return false;

    if (filters.startDate && new Date(item.timestamp) < new Date(filters.startDate)) return false;
    if (filters.endDate) {
      const end = new Date(filters.endDate);
      end.setHours(23, 59, 59, 999);
      if (new Date(item.timestamp) > end) return false;
    }

    let score = 0;
    if (itemType === 'food') score = (item as AnalysisResult).healthScore || 0;
    else if (itemType === 'pharma') score = (item as PharmaAnalysisResult).safetyScore || 0;
    else if (itemType === 'electrical') score = (item as ElectricalAnalysisResult).safetyScore || 0;
    else score = (item as ProductAnalysisResult).safetyScore || 0;

    if (score < filters.minScore || score > filters.maxScore) return false;

    if (filters.nutrient !== 'all' && itemType === 'food') {
      const nutrients = (item as AnalysisResult).nutrients;
      if (!nutrients || !(filters.nutrient in nutrients)) return false;
    }

    return true;
  }).sort((a, b) => {
    const getScore = (item: any) => {
      const type = item.type || 'food';
      if (type === 'food') return item.healthScore || 0;
      return (item as any).safetyScore || 0;
    };

    if (filters.sortBy === 'date-desc') return b.timestamp.getTime() - a.timestamp.getTime();
    if (filters.sortBy === 'date-asc') return a.timestamp.getTime() - b.timestamp.getTime();
    if (filters.sortBy === 'score-desc') return getScore(b) - getScore(a);
    if (filters.sortBy === 'score-asc') return getScore(a) - getScore(b);
    return 0;
  });

  if (loading) return <div className="p-8 text-center text-gray-400 animate-pulse">Loading history...</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600">
            <History className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-gray-900">{t.history}</h3>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={cn(
              "px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all",
              showFilters ? "bg-emerald-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            )}
          >
            <Filter className="w-4 h-4" />
            {t.filters}
          </button>

          {history.length > 1 && (
            <div className="flex items-center gap-2">
              {isCompareMode ? (
                <>
                  <button
                    onClick={() => {
                      setIsCompareMode(false);
                      setSelectedIds([]);
                    }}
                    className="px-4 py-2 text-sm font-bold text-gray-500 hover:text-gray-700 transition-colors"
                  >
                    {t.clearSelection}
                  </button>
                  <button
                    onClick={handleCompareClick}
                    disabled={selectedIds.length < 2}
                    className={cn(
                      "px-6 py-2 rounded-xl text-sm font-black uppercase tracking-widest transition-all",
                      selectedIds.length >= 2
                        ? "bg-emerald-600 text-white shadow-lg shadow-emerald-200"
                        : "bg-gray-100 text-gray-400 cursor-not-allowed"
                    )}
                  >
                    {t.compare} ({selectedIds.length})
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setIsCompareMode(true)}
                  className="px-4 py-2 bg-emerald-50 text-emerald-600 rounded-xl text-sm font-bold hover:bg-emerald-100 transition-all flex items-center gap-2"
                >
                  <Layers className="w-4 h-4" />
                  {t.compareScans}
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Product Type */}
                <div className="space-y-2">
                  <label className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.selectCategory}</label>
                  <select
                    value={filters.type}
                    onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value }))}
                    className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="all">{t.allTypes}</option>
                    <option value="food">{t.foodProduct}</option>
                    <option value="non-food">{t.nonFoodProduct}</option>
                    <option value="pharma">{t.pharmaProduct}</option>
                    <option value="electrical">{t.electricalProduct}</option>
                  </select>
                </div>

                {/* Sort By */}
                <div className="space-y-2">
                  <label className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.sortBy}</label>
                  <select
                    value={filters.sortBy}
                    onChange={(e) => setFilters(prev => ({ ...prev, sortBy: e.target.value }))}
                    className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="date-desc">{t.dateDesc}</option>
                    <option value="date-asc">{t.dateAsc}</option>
                    <option value="score-desc">{t.scoreDesc}</option>
                    <option value="score-asc">{t.scoreAsc}</option>
                  </select>
                </div>

                {/* Date Range */}
                <div className="space-y-2">
                  <label className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.startDate}</label>
                  <input
                    type="date"
                    value={filters.startDate}
                    onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
                    className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.endDate}</label>
                  <input
                    type="date"
                    value={filters.endDate}
                    onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
                    className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Score Range */}
                <div className="space-y-2">
                  <label className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.minScore} ({filters.minScore})</label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={filters.minScore}
                    onChange={(e) => setFilters(prev => ({ ...prev, minScore: parseInt(e.target.value) }))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.maxScore} ({filters.maxScore})</label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={filters.maxScore}
                    onChange={(e) => setFilters(prev => ({ ...prev, maxScore: parseInt(e.target.value) }))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                  />
                </div>

                {/* Nutrient Filter (Food only) */}
                <div className="space-y-2">
                  <label className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.nutrient}</label>
                  <select
                    value={filters.nutrient}
                    onChange={(e) => setFilters(prev => ({ ...prev, nutrient: e.target.value }))}
                    disabled={filters.type !== 'food' && filters.type !== 'all'}
                    className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none disabled:opacity-50"
                  >
                    <option value="all">{t.allTypes}</option>
                    <option value="sugar">Sugar</option>
                    <option value="sodium">Sodium</option>
                    <option value="fat">Fat</option>
                    <option value="protein">Protein</option>
                    <option value="fiber">Fiber</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => setFilters({
                    type: 'all',
                    startDate: '',
                    endDate: '',
                    minScore: 0,
                    maxScore: 100,
                    nutrient: 'all',
                    sortBy: 'date-desc'
                  })}
                  className="text-sm font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
                >
                  <RefreshCcw className="w-4 h-4" />
                  Reset Filters
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {history.length === 0 ? (
        <div className="p-12 text-center bg-gray-50 rounded-3xl border border-dashed border-gray-200">
          <p className="text-gray-400 font-medium">{t.noHistory}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          <AnimatePresence>
            {filteredHistory.map((item, idx) => {
              const isFood = item.type === 'food' || !item.type;
              const isPharma = item.type === 'pharma';
              const isNonFood = item.type === 'non-food';
              const isElectrical = item.type === 'electrical';
              
              let score = 0;
              let evaluation = 'average';

              if (isFood) {
                score = (item as AnalysisResult).healthScore;
                evaluation = (item as AnalysisResult).evaluation;
              } else if (isPharma) {
                score = (item as PharmaAnalysisResult).safetyScore;
                evaluation = score >= 80 ? 'excellent' : score >= 50 ? 'average' : 'poor';
              } else if (isElectrical) {
                score = (item as ElectricalAnalysisResult).safetyScore;
                evaluation = score >= 80 ? 'excellent' : score >= 50 ? 'average' : 'poor';
              } else {
                score = (item as ProductAnalysisResult).safetyScore;
                evaluation = (item as ProductAnalysisResult).overallSafety === 'safe' ? 'excellent' : 
                            (item as ProductAnalysisResult).overallSafety === 'caution' ? 'average' : 'poor';
              }

              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: idx * 0.05 }}
                  onClick={() => isCompareMode ? toggleSelection(item.id) : onSelect(item)}
                  className={cn(
                    "group p-4 bg-white border rounded-2xl shadow-sm transition-all cursor-pointer flex items-center gap-4 relative overflow-hidden",
                    isCompareMode && selectedIds.includes(item.id) 
                      ? "border-emerald-500 bg-emerald-50/30" 
                      : "border-gray-100 hover:shadow-md hover:border-emerald-100"
                  )}
                  role="button"
                  tabIndex={0}
                  aria-label={`${isCompareMode ? 'Select' : 'View analysis'} for ${item.productName || 'Unnamed Product'}, Score: ${score}`}
                  onKeyDown={(e) => e.key === 'Enter' && (isCompareMode ? toggleSelection(item.id) : onSelect(item))}
                >
                  {/* Type Indicator Border */}
                  <div className={cn(
                    "absolute left-0 top-0 bottom-0 w-1",
                    isFood ? "bg-emerald-500" :
                    isPharma ? "bg-purple-500" :
                    isElectrical ? "bg-orange-500" :
                    "bg-blue-500"
                  )} />

                  {isCompareMode && (
                    <div className={cn(
                      "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all",
                      selectedIds.includes(item.id)
                        ? "bg-emerald-600 border-emerald-600 text-white"
                        : "border-gray-200 bg-white"
                    )}>
                      {selectedIds.includes(item.id) && <Check className="w-4 h-4" />}
                    </div>
                  )}

                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg ${
                    evaluation === 'excellent' ? 'bg-emerald-100 text-emerald-700' :
                    evaluation === 'good' ? 'bg-blue-100 text-blue-700' :
                    evaluation === 'average' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`} aria-hidden="true">
                    {score}
                  </div>
                                    <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-gray-900 truncate">{item.productName || 'Unnamed Product'}</h4>
                      {isFood ? (
                        <Utensils className="w-3 h-3 text-emerald-400" />
                      ) : isPharma ? (
                        <Pill className="w-3 h-3 text-purple-400" />
                      ) : isElectrical ? (
                        <Zap className="w-3 h-3 text-orange-400" />
                      ) : (
                        <FlaskConical className="w-3 h-3 text-blue-400" />
                      )}
                    </div>
                    <div className="flex items-center gap-3 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" aria-hidden="true" />
                        {item.timestamp instanceof Date ? item.timestamp.toLocaleDateString() : new Date(item.timestamp).toLocaleDateString()}
                      </span>
                      <span className="flex items-center gap-1">
                        {isFood ? (
                          <Utensils className="w-3 h-3 text-emerald-500" />
                        ) : isPharma ? (
                          <Pill className="w-3 h-3 text-purple-500" />
                        ) : isElectrical ? (
                          <Zap className="w-3 h-3 text-orange-500" />
                        ) : (
                          <FlaskConical className="w-3 h-3 text-blue-500" />
                        )}
                        {isFood ? 'Food' : isPharma ? 'Pharma' : isElectrical ? 'Electrical' : 'Product'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {!isCompareMode && (
                      <button 
                        onClick={(e) => handleDelete(e, item.id)}
                        className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                        aria-label={`Delete scan for ${item.productName || 'Unnamed Product'}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                    <ArrowRight className="w-5 h-5 text-gray-300 group-hover:text-emerald-500 transition-colors" aria-hidden="true" />
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
