import React from 'react';
import { AnalysisResult, AppLanguage } from '../types';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  RadialBarChart, RadialBar, PolarAngleAxis,
  LineChart, Line, AreaChart, Area,
  Radar, RadarChart, PolarGrid, PolarRadiusAxis,
  ComposedChart, Sector, Scatter, ReferenceLine, LabelList
} from 'recharts';
import { 
  AlertTriangle, CheckCircle2, XCircle, Info, 
  Flame, Droplets, Zap, ShieldAlert, MapPin, ArrowRight,
  ChartPie, ChartBar, Layers, Search, AlertCircle, FlaskConical,
  TrendingUp, Calendar, Battery, Activity, ShieldCheck, Baby, HeartPulse,
  Coins, UtensilsCrossed, Sparkles, Globe, PieChart as PieChartIcon
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { translations } from '../translations';

interface AnalysisDashboardProps {
  result: AnalysisResult;
  language: AppLanguage;
  onManualInput?: () => void;
  history?: AnalysisResult[];
}

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white/95 backdrop-blur-md p-4 border border-emerald-100 rounded-2xl shadow-2xl animate-in zoom-in-95 duration-200 ring-1 ring-black/5">
        <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">{label || payload[0].name}</p>
        <div className="space-y-2">
          {payload.map((p: any, i: number) => (
            <div key={i} className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full shadow-sm" style={{ backgroundColor: p.fill || p.color || p.stroke }} />
                <span className="text-xs font-bold text-gray-600">{p.name}</span>
              </div>
              <p className="text-sm font-black text-gray-900">
                {p.value}
                <span className="text-[10px] font-medium text-gray-400 ml-0.5">
                  {p.payload.unit || ''}
                </span>
              </p>
            </div>
          ))}
        </div>
        {payload[0].payload.limit && (
          <div className="mt-3 pt-2 border-t border-gray-50">
            <div className="text-[9px] font-bold text-amber-600 uppercase tracking-wider flex items-center gap-1">
              <Layers className="w-3 h-3" />
              {payload[0].name === 'Fiber' || payload[0].name === 'Protein' ? 'Min Rec.' : 'Max Limit'}: {payload[0].payload.limit}{payload[0].payload.unit}
            </div>
          </div>
        )}
      </div>
    );
  }
  return null;
};

const getEvaluationColor = (evaluation: string) => {
  switch (evaluation) {
    case 'excellent': return '#10b981';
    case 'good': return '#3b82f6';
    case 'average': return '#f59e0b';
    case 'poor': return '#ef4444';
    default: return '#94a3b8';
  }
};

const AnalysisDashboard = ({ result, language, onManualInput, history }: AnalysisDashboardProps) => {
  const t = translations[language];
  const evaluationColor = getEvaluationColor(result.evaluation);
  const [macroChartType, setMacroChartType] = React.useState<'pie' | 'bar'>('pie');
  const [intakeChartType, setIntakeChartType] = React.useState<'bar' | 'radial'>('bar');
  const [smartPlateView, setSmartPlateView] = React.useState<'bar' | 'radar'>('bar');
  const [microView, setMicroView] = React.useState<'grid' | 'radar'>('grid');
  const [activePlateIndex, setActivePlateIndex] = React.useState<number | null>(null);
  const scoreRef = React.useRef<HTMLDivElement>(null);

  const scrollToScore = () => {
    scoreRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const onPlateEnter = (_: any, index: number) => {
    setActivePlateIndex(index);
  };

  const onPlateLeave = () => {
    setActivePlateIndex(null);
  };

  const macroData = [
    { name: 'Carbs', value: result.smartPlate?.carbs || 0, color: '#3b82f6', fill: '#3b82f6' },
    { name: 'Protein', value: result.smartPlate?.protein || 0, color: '#10b981', fill: '#10b981' },
    { name: 'Fat', value: result.smartPlate?.fat || 0, color: '#f59e0b', fill: '#f59e0b' },
    { name: 'Fiber', value: result.smartPlate?.fiber || 0, color: '#8b5cf6', fill: '#8b5cf6' },
  ];

  const intakeData = [
    { name: 'Calories', value: result.nutrients?.calories?.value || 0, limit: 2000, percent: Math.min(((result.nutrients?.calories?.value || 0) / 2000) * 100, 150), fill: '#10b981' },
    { name: 'Sugar', value: result.nutrients?.sugar?.value || 0, limit: 50, percent: Math.min(((result.nutrients?.sugar?.value || 0) / 50) * 100, 150), fill: '#ef4444' },
    { name: 'Sodium', value: result.nutrients?.sodium?.value || 0, limit: 2300, percent: Math.min(((result.nutrients?.sodium?.value || 0) / 2300) * 100, 150), fill: '#f59e0b' },
    { name: 'Protein', value: result.nutrients?.protein?.value || 0, limit: 50, percent: Math.min(((result.nutrients?.protein?.value || 0) / 50) * 100, 150), fill: '#3b82f6' },
    { name: 'Fiber', value: result.nutrients?.fiber?.value || 0, limit: 25, percent: Math.min(((result.nutrients?.fiber?.value || 0) / 25) * 100, 150), fill: '#8b5cf6' },
  ];

  const radarData = result.micronutrients?.map(m => ({
    subject: m.name,
    A: m.dailyValuePercentage || 0,
    fullMark: 100,
  })) || [];

  const whoComparisonData = result.whoComparison?.map(comp => ({
    name: comp.nutrientName,
    value: Math.min((comp.currentValue / comp.whoLimit) * 100, 150),
    limit: 100,
    unit: comp.unit,
    current: comp.currentValue,
    max: comp.whoLimit
  })) || [];

  const trendData = history?.map(h => {
    const data: any = { date: h.timestamp ? new Date(h.timestamp).toLocaleDateString() : 'N/A' };
    h.micronutrients?.forEach(m => {
      data[m.name] = m.dailyValuePercentage;
    });
    return data;
  }) || [];

  const commonMicros = Array.from(new Set(history?.flatMap(h => h.micronutrients?.map(m => m.name) || []) || [])).slice(0, 5);

  const getPurityColor = (grade: string) => {
    switch (grade) {
      case 'A': return 'text-emerald-600 bg-emerald-50 border-emerald-100';
      case 'B': return 'text-blue-600 bg-blue-50 border-blue-100';
      case 'C': return 'text-amber-600 bg-amber-50 border-amber-100';
      case 'D': return 'text-orange-600 bg-orange-50 border-orange-100';
      case 'F': return 'text-red-600 bg-red-50 border-red-100';
      default: return 'text-gray-600 bg-gray-50 border-gray-100';
    }
  };

  const getNovaColor = (level: number) => {
    switch (level) {
      case 1: return 'bg-emerald-500';
      case 2: return 'bg-blue-500';
      case 3: return 'bg-amber-500';
      case 4: return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getAdditiveRiskColor = (risk: string) => {
    switch (risk) {
      case 'safe': return 'text-emerald-600 bg-emerald-50';
      case 'moderate': return 'text-amber-600 bg-amber-50';
      case 'risky': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const smartPlateData = [
    { name: t.carbs, value: result.smartPlate?.carbs || 0, fill: '#3b82f6', icon: <Battery className="w-4 h-4" />, color: 'from-blue-400 to-blue-600' },
    { name: t.protein, value: result.smartPlate?.protein || 0, fill: '#10b981', icon: <Activity className="w-4 h-4" />, color: 'from-emerald-400 to-emerald-600' },
    { name: t.totalFat, value: result.smartPlate?.fat || 0, fill: '#f59e0b', icon: <Droplets className="w-4 h-4" />, color: 'from-amber-400 to-amber-600' },
    { name: t.fiberVeggies, value: result.smartPlate?.fiber || 0, fill: '#8b5cf6', icon: <Layers className="w-4 h-4" />, color: 'from-purple-400 to-purple-600' },
  ].filter(d => d.value > 0);

  const smartPlateComparisonData = [
    { name: t.carbs, actual: result.smartPlate?.carbs || 0, target: 25, fill: '#3b82f6', fullMark: 100 },
    { name: t.protein, actual: result.smartPlate?.protein || 0, target: 25, fill: '#10b981', fullMark: 100 },
    { name: t.fiberVeggies, actual: result.smartPlate?.fiber || 0, target: 50, fill: '#8b5cf6', fullMark: 100 },
  ];

  const plateScore = Math.max(0, 100 - (
    Math.abs((result.smartPlate?.carbs || 0) - 25) +
    Math.abs((result.smartPlate?.protein || 0) - 25) +
    Math.abs((result.smartPlate?.fiber || 0) - 50)
  ) / 2);

  // SVG Gradients for charts
  const ChartGradients = () => (
    <svg style={{ height: 0, width: 0, position: 'absolute' }}>
      <defs>
        <linearGradient id="scoreGradient" x1="0" y1="0" x2="0" y2="1">
          <stop offset="5%" stopColor={evaluationColor} stopOpacity={0.8}/>
          <stop offset="95%" stopColor={evaluationColor} stopOpacity={0.2}/>
        </linearGradient>
        <linearGradient id="emeraldGradient" x1="0" y1="0" x2="0" y2="1">
          <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
          <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
        </linearGradient>
        <linearGradient id="blueGradient" x1="0" y1="0" x2="0" y2="1">
          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
        </linearGradient>
        <linearGradient id="amberGradient" x1="0" y1="0" x2="0" y2="1">
          <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8}/>
          <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
        </linearGradient>
      </defs>
    </svg>
  );

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'excellent': return <CheckCircle2 className="w-8 h-8 text-emerald-500" />;
      case 'good': return <CheckCircle2 className="w-8 h-8 text-blue-500" />;
      case 'average': return <AlertTriangle className="w-8 h-8 text-amber-500" />;
      case 'poor': return <XCircle className="w-8 h-8 text-red-500" />;
      default: return <Info className="w-8 h-8 text-blue-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'bg-emerald-50 text-emerald-900 border-emerald-200 shadow-emerald-50';
      case 'good': return 'bg-blue-50 text-blue-900 border-blue-200 shadow-blue-50';
      case 'average': return 'bg-amber-50 text-amber-900 border-amber-200 shadow-amber-50';
      case 'poor': return 'bg-red-50 text-red-900 border-red-200 shadow-red-50';
      default: return 'bg-gray-50 text-gray-900 border-gray-200';
    }
  };

  const getChoiceBadgeColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'bg-emerald-600 text-white shadow-lg shadow-emerald-200';
      case 'good': return 'bg-blue-600 text-white shadow-lg shadow-blue-200';
      case 'average': return 'bg-amber-500 text-white shadow-lg shadow-amber-200';
      case 'poor': return 'bg-red-600 text-white shadow-lg shadow-red-200';
      default: return 'bg-gray-600 text-white';
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <ChartGradients />
      
      {/* Digital Nutritionist Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-16 h-16 bg-emerald-600 rounded-3xl flex items-center justify-center text-white shadow-xl shadow-emerald-200 rotate-3">
              <Activity className="w-8 h-8" />
            </div>
            <div className="absolute -top-2 -right-2 w-6 h-6 bg-amber-400 rounded-full flex items-center justify-center text-white shadow-md animate-bounce">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-3xl font-black text-gray-900 tracking-tight">{t.appName}</h1>
              {result.dataSource === 'ocr' || result.dataSource === 'barcode' ? (
                <div className="flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-black uppercase tracking-tighter">
                  <ShieldCheck className="w-3 h-3" />
                  {language === 'bn' ? 'যাচাইকৃত' : 'Verified'}
                </div>
              ) : (
                <div className="flex items-center gap-1 px-2 py-0.5 bg-blue-100 text-blue-700 rounded-lg text-[10px] font-black uppercase tracking-tighter">
                  <Globe className="w-3 h-3" />
                  {language === 'bn' ? 'ওয়েব সার্চ' : 'Web Search'}
                </div>
              )}
            </div>
            <p className="text-emerald-600 font-bold text-sm">{t.tagline}</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          {result.purityGrade && (
            <div className={cn(
              "px-4 py-2 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 border-2 shadow-md transition-all hover:scale-105",
              getPurityColor(result.purityGrade)
            )}>
              <ShieldCheck className="w-4 h-4" />
              {t.purityGrade}: {result.purityGrade}
            </div>
          )}
          {result.halalStatus && (
            <div className={cn(
              "px-4 py-2 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 border-2 shadow-md transition-all hover:scale-105",
              result.halalStatus === 'halal' ? "bg-emerald-50 text-emerald-700 border-emerald-200" :
              result.halalStatus === 'doubtful' ? "bg-amber-50 text-amber-700 border-amber-200" :
              "bg-red-50 text-red-700 border-red-200"
            )}>
              {result.halalStatus === 'halal' ? <CheckCircle2 className="w-4 h-4" /> : 
               result.halalStatus === 'doubtful' ? <AlertTriangle className="w-4 h-4" /> : 
               <XCircle className="w-4 h-4" />}
              {t[result.halalStatus === 'halal' ? 'halal' : result.halalStatus === 'doubtful' ? 'doubtful' : 'notHalal']}
            </div>
          )}
          {result.diabeticFriendly !== undefined && (
            <div className={cn(
              "px-4 py-2 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 border-2 shadow-md transition-all hover:scale-105",
              result.diabeticFriendly ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-red-50 text-red-700 border-red-200"
            )}>
              {result.diabeticFriendly ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
              {t.diabeticFriendly}
            </div>
          )}
          {result.kidSafe !== undefined && (
            <div className={cn(
              "px-4 py-2 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 border-2 shadow-md transition-all hover:scale-105",
              result.kidSafe ? "bg-purple-50 text-purple-700 border-purple-200" : "bg-red-50 text-red-700 border-red-200"
            )}>
              {result.kidSafe ? <Baby className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
              {t.kidSafe}
            </div>
          )}
          {result.glutenFreeStatus && (
            <div className={cn(
              "px-4 py-2 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 border-2 shadow-md transition-all hover:scale-105",
              result.glutenFreeStatus === 'gluten-free' ? "bg-emerald-50 text-emerald-700 border-emerald-200" :
              result.glutenFreeStatus === 'may-contain' ? "bg-amber-50 text-amber-700 border-amber-200" :
              "bg-red-50 text-red-700 border-red-200"
            )}>
              {result.glutenFreeStatus === 'gluten-free' ? <CheckCircle2 className="w-4 h-4" /> : 
               result.glutenFreeStatus === 'may-contain' ? <AlertTriangle className="w-4 h-4" /> : 
               <XCircle className="w-4 h-4" />}
              {t[result.glutenFreeStatus === 'gluten-free' ? 'glutenFree' : 
                  result.glutenFreeStatus === 'may-contain' ? 'mayContainGluten' : 
                  'containsGluten']}
            </div>
          )}
        </div>
      </div>

      {/* Health Score & Core Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Health Battery */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl flex flex-col items-center justify-center text-center space-y-6"
        >
          <div className="relative w-48 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={[
                    { value: result.healthScore, fill: 'url(#scoreGradient)' },
                    { value: 100 - result.healthScore, fill: '#f1f5f9' }
                  ]}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={90}
                  startAngle={90}
                  endAngle={450}
                  dataKey="value"
                  stroke="none"
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="flex items-center gap-1 text-5xl font-black text-gray-900">
                {result.healthScore}
                <span className="text-xl text-gray-400">/100</span>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={scrollToScore}
                className="mt-2 text-[10px] font-black text-emerald-600 uppercase tracking-widest flex items-center gap-1 hover:text-emerald-700 transition-colors"
              >
                {t.whyThisScore}
                <ArrowRight className="w-3 h-3" />
              </motion.button>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">{t.healthScore}</p>
            </div>
          </div>

          <div className="w-full space-y-4">
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center gap-2">
                <Battery className="w-5 h-5 text-emerald-500" />
                <span className="text-sm font-black text-gray-700 uppercase tracking-widest">{t.healthBattery}</span>
              </div>
              <span className="text-sm font-black text-emerald-600">{result.healthBattery}%</span>
            </div>
            <div className="h-4 bg-gray-100 rounded-full overflow-hidden p-1 border border-gray-50 shadow-inner">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${result.healthBattery}%` }}
                className={cn(
                  "h-full rounded-full shadow-sm",
                  result.healthBattery > 70 ? "bg-emerald-500" : result.healthBattery > 40 ? "bg-amber-500" : "bg-red-500"
                )}
              />
            </div>
          </div>
        </motion.div>

        {/* Smart Plate Visualization */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl space-y-6"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-black text-gray-800 flex items-center gap-2">
              <UtensilsCrossed className="w-5 h-5 text-blue-500" />
              {t.smartPlate}
            </h3>
            <div className="flex items-center gap-2">
              <div className="flex bg-gray-100 p-1 rounded-xl mr-2">
                <button 
                  onClick={() => setSmartPlateView('bar')}
                  className={cn(
                    "px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
                    smartPlateView === 'bar' ? "bg-white text-blue-600 shadow-sm" : "text-gray-400 hover:text-gray-600"
                  )}
                >
                  Bar
                </button>
                <button 
                  onClick={() => setSmartPlateView('radar')}
                  className={cn(
                    "px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
                    smartPlateView === 'radar' ? "bg-white text-blue-600 shadow-sm" : "text-gray-400 hover:text-gray-600"
                  )}
                >
                  Radar
                </button>
              </div>
              <div className="px-3 py-1 bg-blue-50 rounded-full text-[10px] font-black text-blue-600 uppercase tracking-widest border border-blue-100">
                {t.smartThaliScore}: {Math.round(plateScore)}%
              </div>
              <div className="w-8 h-8 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
                <ChartPie className="w-4 h-4" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <motion.div 
              whileHover={{ rotateX: 5, rotateY: -5, scale: 1.02 }}
              className="h-56 relative perspective-1000"
            >
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center z-10">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Your</p>
                  <p className="text-sm font-black text-gray-900">Plate</p>
                </div>
              </div>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={smartPlateData}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={85}
                    paddingAngle={8}
                    dataKey="value"
                    stroke="none"
                    animationBegin={0}
                    animationDuration={1500}
                    onMouseEnter={onPlateEnter}
                    onMouseLeave={onPlateLeave}
                  >
                    {smartPlateData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.fill} 
                        opacity={activePlateIndex === null || activePlateIndex === index ? 1 : 0.6}
                        scale={activePlateIndex === index ? 1.1 : 1}
                        style={{ outline: 'none', transition: 'all 0.3s ease' }}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </motion.div>

            <div className="space-y-4">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                <TrendingUp className="w-3 h-3" /> Comparison with Ideal Plate
              </p>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  {smartPlateView === 'bar' ? (
                    <ComposedChart data={smartPlateComparisonData} layout="vertical" barSize={12} margin={{ left: -20 }}>
                      <XAxis type="number" hide domain={[0, 100]} />
                      <YAxis 
                        dataKey="name" 
                        type="category" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fontSize: 9, fontWeight: 800, fill: '#64748b' }}
                        width={70}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="actual" name="Product" radius={[0, 10, 10, 0]}>
                        {smartPlateComparisonData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={entry.fill} 
                            fillOpacity={activePlateIndex === index ? 1 : 0.8}
                          />
                        ))}
                        <LabelList dataKey="actual" position="right" style={{ fontSize: '9px', fontWeight: 900, fill: '#64748b' }} formatter={(v: number) => `${v}%`} />
                      </Bar>
                      <Bar dataKey="target" name="Ideal" fill="#f1f5f9" radius={[0, 10, 10, 0]} />
                      <Scatter dataKey="target" fill="#94a3b8" shape="diamond" />
                      <ReferenceLine x={100} stroke="#e2e8f0" strokeDasharray="3 3" />
                    </ComposedChart>
                  ) : (
                    <RadarChart cx="50%" cy="50%" outerRadius="70%" data={smartPlateComparisonData}>
                      <PolarGrid stroke="#e2e8f0" />
                      <PolarAngleAxis 
                        dataKey="name" 
                        tick={{ fontSize: 8, fontWeight: 800, fill: '#64748b' }}
                      />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                      <Radar
                        name="Product"
                        dataKey="actual"
                        stroke="#3b82f6"
                        fill="#3b82f6"
                        fillOpacity={activePlateIndex !== null ? 0.7 : 0.5}
                        animationDuration={1500}
                      />
                      <Radar
                        name="Ideal"
                        dataKey="target"
                        stroke="#94a3b8"
                        fill="#94a3b8"
                        fillOpacity={0.1}
                        animationDuration={1500}
                      />
                      <Tooltip content={<CustomTooltip />} />
                    </RadarChart>
                  )}
                </ResponsiveContainer>
              </div>
              <div className="flex gap-4 text-[9px] font-black uppercase tracking-widest">
                <div className="flex items-center gap-1.5 text-gray-600">
                  <div className="w-2 h-2 rounded-full bg-blue-500" /> Product
                </div>
                <div className="flex items-center gap-1.5 text-gray-400">
                  <div className="w-2 h-2 rounded-full bg-gray-200" /> Ideal (WHO)
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {smartPlateData.map((item, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ 
                  scale: 1.05, 
                  rotateX: 12, 
                  rotateY: 12,
                  translateZ: 50,
                  boxShadow: `0 25px 30px -5px ${item.fill}33, 0 12px 15px -6px ${item.fill}22`
                }}
                animate={{ 
                  y: [0, -6, 0],
                  transition: { 
                    duration: 4, 
                    repeat: Infinity, 
                    ease: "easeInOut",
                    delay: i * 0.2
                  }
                }}
                className="flex flex-col p-5 bg-white/40 backdrop-blur-md rounded-[2rem] border border-white/50 transition-all hover:bg-white perspective-1000 group relative overflow-hidden"
              >
                <motion.div 
                  initial={{ x: '-100%', skewX: -45 }}
                  whileHover={{ x: '200%' }}
                  transition={{ duration: 0.8, ease: "easeInOut" }}
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent pointer-events-none z-20"
                />
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                <div className="flex items-center gap-3 mb-4 relative z-10">
                  <motion.div 
                    whileHover={{ translateZ: 20, rotate: 15 }}
                    className={cn(
                      "p-3 rounded-2xl bg-gradient-to-br text-white shadow-lg transition-transform group-hover:scale-125",
                      item.color
                    )}
                  >
                    {item.icon}
                  </motion.div>
                  <span className="text-[11px] font-black text-gray-500 uppercase tracking-widest">{item.name}</span>
                </div>
                <div className="flex items-baseline gap-1 relative z-10">
                  <span className="text-2xl font-black text-gray-900">{item.value}</span>
                  <span className="text-xs font-bold text-gray-400 uppercase">%</span>
                </div>
                <div className="mt-3 h-2 w-full bg-gray-100/50 rounded-full overflow-hidden relative z-10">
                  <motion.div 
                    initial={{ width: 0 }}
                    whileInView={{ width: `${item.value}%` }}
                    transition={{ duration: 1.5, delay: 0.5 + (i * 0.1), ease: "easeOut" }}
                    className={cn("h-full rounded-full shadow-sm", item.fill && `bg-[${item.fill}]`)}
                    style={{ backgroundColor: item.fill }}
                  />
                </div>
                <div className="mt-2 flex justify-between items-center relative z-10">
                  <span className="text-[9px] font-black text-gray-400 uppercase tracking-tighter">Current Balance</span>
                  <div className={cn(
                    "w-1.5 h-1.5 rounded-full animate-pulse",
                    item.value > 0 ? "bg-emerald-500" : "bg-gray-300"
                  )} />
                </div>
              </motion.div>
            ))}
          </div>

          {/* New Metrics with 3D Animations */}
          <div className="pt-6 border-t border-gray-50 grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: t.totalCalories, value: result.nutrients?.calories?.value, unit: result.nutrients?.calories?.unit || 'kcal', color: 'from-emerald-400 to-emerald-600', icon: <Flame className="w-4 h-4" /> },
              { label: t.totalSugar, value: result.nutrients?.sugar?.value, unit: result.nutrients?.sugar?.unit || 'g', color: 'from-blue-400 to-blue-600', icon: <Droplets className="w-4 h-4" /> },
              { label: t.totalSodium, value: result.nutrients?.sodium?.value, unit: result.nutrients?.sodium?.unit || 'mg', color: 'from-amber-400 to-amber-600', icon: <Zap className="w-4 h-4" /> }
            ].map((metric, i) => (
              <motion.div
                key={i}
                whileHover={{ scale: 1.02, rotateX: 5, translateZ: 20 }}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-gray-100 shadow-sm perspective-1000 transition-all hover:shadow-md group"
              >
                <div className="flex items-center gap-3">
                  <div className={cn("p-2.5 rounded-xl bg-gradient-to-br text-white shadow-sm transition-transform group-hover:scale-110", metric.color)}>
                    {metric.icon}
                  </div>
                  <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest leading-tight">{metric.label}</span>
                </div>
                <div className="text-right">
                  <span className="text-base font-black text-gray-900">{metric.value || 0}</span>
                  <p className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter">{metric.unit}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Processing & Safety Indicators */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          {/* Additive Risk Meter */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl space-y-6 group hover:shadow-2xl transition-all relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-gray-50 to-transparent rounded-full -mr-16 -mt-16 blur-2xl opacity-50" />
            
            <div className="flex items-center justify-between relative z-10">
              <div className="flex items-center gap-4">
                <motion.div 
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                  className={cn("p-4 rounded-2xl shadow-lg", getAdditiveRiskColor(result.additiveRisk || 'safe'))}
                >
                  <FlaskConical className="w-6 h-6" />
                </motion.div>
                <div>
                  <h4 className="text-sm font-black text-gray-800 uppercase tracking-widest">{t.additiveRisk}</h4>
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">Safety Assessment</p>
                </div>
              </div>
              <motion.div 
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                className={cn("px-4 py-2 rounded-2xl text-xs font-black uppercase tracking-widest shadow-lg border-2", 
                  result.additiveRisk === 'risky' ? "bg-red-50 text-red-600 border-red-100" :
                  result.additiveRisk === 'moderate' ? "bg-amber-50 text-amber-600 border-amber-100" :
                  "bg-emerald-50 text-emerald-600 border-emerald-100"
                )}
              >
                {t[result.additiveRisk || 'safe']}
              </motion.div>
            </div>

            <div className="relative h-6 bg-gray-100 rounded-full overflow-hidden p-1.5 shadow-inner border border-gray-200/50">
              <div className="absolute inset-1.5 flex gap-1.5">
                <div className="flex-1 bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-l-full opacity-40" />
                <div className="flex-1 bg-gradient-to-r from-amber-400 to-amber-500 opacity-40" />
                <div className="flex-1 bg-gradient-to-r from-red-400 to-red-500 rounded-r-full opacity-40" />
              </div>
              <motion.div 
                initial={{ left: '10%' }}
                animate={{ 
                  left: result.additiveRisk === 'risky' ? '85%' : result.additiveRisk === 'moderate' ? '50%' : '15%',
                  scale: [1, 1.2, 1]
                }}
                transition={{ 
                  left: { type: "spring", stiffness: 100, damping: 15 },
                  scale: { repeat: Infinity, duration: 2 }
                }}
                className="absolute top-1/2 -translate-y-1/2 w-5 h-5 bg-white border-4 border-gray-900 rounded-full shadow-2xl z-10 flex items-center justify-center"
              >
                <div className={cn("w-1.5 h-1.5 rounded-full animate-pulse", 
                  result.additiveRisk === 'risky' ? "bg-red-500" :
                  result.additiveRisk === 'moderate' ? "bg-amber-500" :
                  "bg-emerald-500"
                )} />
              </motion.div>
            </div>

            <div className="flex justify-between text-[10px] font-black uppercase tracking-widest px-2">
              <span className="text-emerald-600 drop-shadow-sm">{t.safe}</span>
              <span className="text-amber-600 drop-shadow-sm">{t.moderate}</span>
              <span className="text-red-600 drop-shadow-sm">{t.risky}</span>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn("p-4 rounded-2xl border text-xs font-bold leading-relaxed shadow-sm",
                result.additiveRisk === 'risky' ? "bg-red-50/50 border-red-100 text-red-700" :
                result.additiveRisk === 'moderate' ? "bg-amber-50/50 border-amber-100 text-amber-700" :
                "bg-emerald-50/50 border-emerald-100 text-emerald-700"
              )}
            >
              {t[`${result.additiveRisk || 'safe'}Desc`]}
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
      {/* Desi Lens Analysis Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl space-y-8 mb-12"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Component Breakdown */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-6 bg-gradient-to-br from-blue-50/50 to-indigo-50/50 p-8 rounded-[2.5rem] border border-blue-100/50 shadow-xl perspective-1000"
          >
            <h3 className="text-xl font-black text-gray-800 flex items-center gap-3">
              <span className="p-3 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-200 rotate-3">
                <ChartPie className="w-6 h-6" />
              </span>
              {t.componentBreakdown}
            </h3>
            <div className="space-y-6">
              {[
                { label: t.carbs, value: result.componentBreakdown?.carbs, type: result.componentBreakdown?.carbsType, color: 'from-blue-400 to-blue-600', icon: '🍚' },
                { label: t.greaseScale, value: result.componentBreakdown?.greaseScale, type: result.componentBreakdown?.oilType, color: 'from-amber-400 to-amber-600', icon: '🛢️' },
                { label: t.protein, value: result.componentBreakdown?.protein, type: result.componentBreakdown?.proteinType, color: 'from-emerald-400 to-emerald-600', icon: '🍗' },
                { label: t.fiberVeggies, value: result.componentBreakdown?.fiberVeggies, type: result.componentBreakdown?.veggieType, color: 'from-green-400 to-green-600', icon: '🥗' },
              ].map((comp, i) => (
                <motion.div 
                  key={i} 
                  whileHover={{ scale: 1.02, rotateX: 2, rotateY: -2, translateZ: 10 }}
                  className="space-y-3 p-4 bg-white/60 rounded-2xl border border-white/50 shadow-sm backdrop-blur-sm transition-all hover:shadow-xl hover:bg-white/80"
                >
                  <div className="flex justify-between text-xs font-black text-gray-700">
                    <span className="flex items-center gap-2">
                      <span className="text-xl drop-shadow-sm">{comp.icon}</span>
                      <span className="uppercase tracking-widest text-gray-900">{comp.label}</span>
                      <span className="text-[10px] text-blue-600 font-black bg-blue-100/50 px-2 py-0.5 rounded-full">
                        {comp.type}
                      </span>
                    </span>
                    <span className="text-sm font-black text-blue-700">{comp.value}%</span>
                  </div>
                  <div className="h-4 bg-gray-100/50 rounded-full overflow-hidden shadow-inner p-1 border border-gray-200/50">
                    <motion.div 
                      initial={{ width: 0 }}
                      whileInView={{ width: `${comp.value}%` }}
                      transition={{ duration: 1.2, delay: i * 0.1, ease: "easeOut" }}
                      className={cn("h-full rounded-full shadow-md bg-gradient-to-r", comp.color)}
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Safety Alerts */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-6 bg-gradient-to-br from-amber-50/50 to-orange-50/50 p-8 rounded-[2.5rem] border border-amber-100/50 shadow-xl perspective-1000"
          >
            <h3 className="text-xl font-black text-gray-800 flex items-center gap-3">
              <span className="p-3 bg-amber-500 rounded-2xl text-white shadow-lg shadow-amber-200 -rotate-3">
                <AlertTriangle className="w-6 h-6" />
              </span>
              {t.desiSafetyAlerts}
            </h3>
            <div className="grid grid-cols-1 gap-5">
              <motion.div 
                whileHover={{ scale: 1.03, rotateY: 5, translateZ: 20 }}
                className="p-5 bg-white rounded-3xl border-2 border-amber-100 shadow-lg shadow-amber-100/20 transition-all hover:shadow-2xl hover:border-amber-200"
              >
                <div className="text-[10px] font-black text-amber-600 uppercase tracking-[0.2em] mb-2 flex items-center gap-2">
                  <div className="p-1.5 bg-amber-100 rounded-lg">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  {t.purity}
                </div>
                <p className="text-base font-bold text-gray-800 leading-relaxed">{result.desiSafetyAlerts?.purity}</p>
              </motion.div>

              <motion.div 
                whileHover={{ scale: 1.03, rotateY: -5, translateZ: 20 }}
                className="p-5 bg-white rounded-3xl border-2 border-red-100 shadow-lg shadow-red-100/20 transition-all hover:shadow-2xl hover:border-red-200"
              >
                <div className="text-[10px] font-black text-red-600 uppercase tracking-[0.2em] mb-2 flex items-center gap-2">
                  <div className="p-1.5 bg-red-100 rounded-lg">
                    <Activity className="w-4 h-4" />
                  </div>
                  {t.bloodSugarImpact}
                </div>
                <p className="text-base font-bold text-gray-800 leading-relaxed">{result.desiSafetyAlerts?.bloodSugarImpact}</p>
              </motion.div>

              <div className="space-y-4 mt-2">
                {result.healthAlerts.map((alert, idx) => (
                  <motion.div 
                    key={idx}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    whileHover={{ x: 10, backgroundColor: 'rgba(255, 255, 255, 0.9)' }}
                    className="flex items-start gap-4 p-4 bg-white/60 rounded-2xl border border-white/80 text-sm font-bold text-gray-700 shadow-sm backdrop-blur-sm transition-all"
                  >
                    <div className="w-3 h-3 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 mt-1 shrink-0 shadow-md animate-pulse" />
                    {alert}
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>


      </motion.div>

      {/* Score Breakdown Section */}
      <div ref={scoreRef} className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-black text-gray-800 flex items-center gap-2 tracking-tight">
            <Layers className="w-5 h-5 text-emerald-500" />
            {t.whyThisScore}
          </h3>
          <div className="px-4 py-1 bg-emerald-50 rounded-full text-[10px] font-black text-emerald-600 uppercase tracking-widest">
            {result.scoreBreakdown?.length || 0} Factors Analyzed
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {result.scoreBreakdown?.map((factor, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              whileHover={{ 
                scale: 1.02, 
                translateY: -5,
                boxShadow: factor.impact > 0 
                  ? "0 20px 25px -5px rgba(16, 185, 129, 0.1), 0 8px 10px -6px rgba(16, 185, 129, 0.1)"
                  : "0 20px 25px -5px rgba(239, 68, 68, 0.1), 0 8px 10px -6px rgba(239, 68, 68, 0.1)"
              }}
              className={cn(
                "group relative p-6 rounded-[2rem] border-2 transition-all overflow-hidden",
                factor.impact > 0 
                  ? "bg-emerald-50/40 border-emerald-100/50 hover:bg-white hover:border-emerald-200" 
                  : "bg-red-50/40 border-red-100/50 hover:bg-white hover:border-red-200"
              )}
            >
              <div className={cn(
                "absolute top-0 right-0 w-32 h-32 -mr-16 -mt-16 rounded-full blur-3xl opacity-20 transition-opacity group-hover:opacity-40",
                factor.impact > 0 ? "bg-emerald-400" : "bg-red-400"
              )} />
              
              <div className="flex items-start gap-5 relative z-10">
                <div className={cn(
                  "w-16 h-16 shrink-0 rounded-2xl flex flex-col items-center justify-center font-black shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-transform border-2",
                  factor.impact > 0 
                    ? "bg-emerald-500 text-white border-emerald-400" 
                    : "bg-red-500 text-white border-red-400"
                )}>
                  <span className="text-[10px] opacity-80 leading-none mb-1 uppercase tracking-widest">{factor.impact > 0 ? 'Gain' : 'Loss'}</span>
                  <span className="text-2xl leading-none">{factor.impact > 0 ? '+' : '-'}{Math.abs(factor.impact)}</span>
                </div>
                <div className="flex-1 space-y-2">
                  <h4 className="font-black text-gray-900 tracking-tight text-lg">{factor.name}</h4>
                  <p className="text-xs text-gray-600 font-bold leading-relaxed">{factor.reason}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Hidden Ingredients */}
      <div className="grid grid-cols-1 gap-8">

        <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-black text-gray-800 flex items-center gap-2 tracking-tight">
              <ShieldAlert className="w-5 h-5 text-red-500" />
              {t.hiddenIngredients}
            </h3>
            <div className="px-3 py-1 bg-red-50 rounded-full text-[10px] font-black text-red-600 uppercase tracking-widest">
              {result.hiddenIngredients?.length || 0} Alerts
            </div>
          </div>
          <div className="space-y-4">
            {result.hiddenIngredients && result.hiddenIngredients.length > 0 ? (
              result.hiddenIngredients.map((hidden, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex items-start gap-4 p-4 bg-red-50/30 rounded-2xl border border-red-100/50 group hover:bg-red-50 transition-colors"
                >
                  <div className="w-10 h-10 shrink-0 rounded-xl bg-white flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                    <AlertCircle className="w-5 h-5 text-red-500" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-black text-red-900 uppercase tracking-tight">{hidden.name}</p>
                    <p className="text-xs font-bold text-red-700/80 leading-relaxed">{hidden.warning}</p>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center">
                  <ShieldCheck className="w-8 h-8 text-emerald-500" />
                </div>
                <p className="text-sm font-black text-gray-400 uppercase tracking-widest">No Hidden Risks Found</p>
              </div>
            )}
          </div>
        </div>
      </div>



      {/* Allergens & Ingredient Insights */}
      <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-black text-gray-800 flex items-center gap-2 tracking-tight">
            <ShieldAlert className="w-5 h-5 text-amber-500" />
            {t.ingredientAnalysis}
          </h3>
          <div className="px-4 py-1 bg-amber-50 rounded-full text-[10px] font-black text-amber-600 uppercase tracking-widest">
            {result.ingredientInsights?.length || 0} Insights
          </div>
        </div>

        {/* Allergens Highlight */}
        {result.ingredientInsights?.some(i => i.category === 'allergen') && (
          <div className="space-y-4">
            <h4 className="text-xs font-black text-red-600 uppercase tracking-widest flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              {t.allergens}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {result.ingredientInsights
                .filter(i => i.category === 'allergen')
                .map((allergen, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    whileHover={{ scale: 1.02 }}
                    className="p-5 bg-red-50 border-2 border-red-100 rounded-3xl flex items-start gap-4 shadow-sm"
                  >
                    <div className="w-10 h-10 shrink-0 rounded-2xl bg-white flex items-center justify-center shadow-md">
                      <AlertTriangle className="w-5 h-5 text-red-500" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-black text-red-900 uppercase tracking-tight">{allergen.name}</p>
                      <p className="text-xs font-bold text-red-700/80 leading-relaxed">{allergen.description}</p>
                    </div>
                  </motion.div>
                ))}
            </div>
          </div>
        )}

        {/* Other Insights (Additives, etc.) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {result.ingredientInsights
            ?.filter(i => i.category !== 'allergen')
            .map((insight, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.05 }}
                whileHover={{ y: -5 }}
                className={cn(
                  "p-6 rounded-[2rem] border transition-all",
                  insight.riskLevel === 'high' ? "bg-red-50/50 border-red-100" :
                  insight.riskLevel === 'moderate' ? "bg-amber-50/50 border-amber-100" :
                  "bg-emerald-50/50 border-emerald-100"
                )}
              >
                <div className="flex items-center justify-between mb-4">
                  <span className={cn(
                    "px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest",
                    insight.category === 'additive' ? "bg-blue-100 text-blue-600" : "bg-purple-100 text-purple-600"
                  )}>
                    {t[insight.category] || insight.category}
                  </span>
                  <div className={cn(
                    "w-2 h-2 rounded-full",
                    insight.riskLevel === 'high' ? "bg-red-500" :
                    insight.riskLevel === 'moderate' ? "bg-amber-500" :
                    "bg-emerald-500"
                  )} />
                </div>
                <h4 className="text-sm font-black text-gray-900 mb-2 uppercase tracking-tight">{insight.name}</h4>
                <p className="text-xs font-bold text-gray-600 leading-relaxed">{insight.description}</p>
              </motion.div>
            ))}
        </div>

        {(!result.ingredientInsights || result.ingredientInsights.length === 0) && (
          <div className="flex flex-col items-center justify-center py-12 text-center space-y-4">
            <div className="w-20 h-20 rounded-full bg-emerald-50 flex items-center justify-center">
              <ShieldCheck className="w-10 h-10 text-emerald-500" />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-black text-gray-400 uppercase tracking-widest">No Significant Ingredient Risks</p>
              <p className="text-xs font-bold text-gray-400">All identified ingredients appear safe for consumption.</p>
            </div>
          </div>
        )}
      </div>

      {/* Recommendations */}
      <div className="bg-emerald-600 p-10 rounded-[3rem] shadow-2xl shadow-emerald-200/50 space-y-10 text-white relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -mr-48 -mt-48 blur-3xl transition-transform group-hover:scale-110" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-400/20 rounded-full -ml-48 -mb-48 blur-3xl transition-transform group-hover:scale-110" />
        
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <h3 className="text-3xl font-black flex items-center gap-4 tracking-tight">
              <span className="p-3 bg-white/20 rounded-2xl backdrop-blur-xl shadow-inner">
                <Sparkles className="w-8 h-8" />
              </span>
              {t.healthSuggestions}
            </h3>
            <p className="text-emerald-100 font-bold text-sm ml-14">Tailored insights based on your profile</p>
          </div>
          <div className="px-6 py-2 bg-white/20 rounded-full text-xs font-black uppercase tracking-[0.2em] backdrop-blur-xl border border-white/10 shadow-lg">
            Personalized for you
          </div>
        </div>

        <div className="relative grid grid-cols-1 md:grid-cols-2 gap-6">
          {result.healthSuggestions?.map((suggestion, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="flex items-start gap-5 p-6 bg-white/10 rounded-[2rem] border border-white/20 backdrop-blur-xl group hover:bg-white/20 transition-all hover:-translate-y-1 shadow-lg"
            >
              <div className="w-12 h-12 shrink-0 rounded-2xl bg-emerald-500 flex items-center justify-center shadow-xl group-hover:scale-110 group-hover:rotate-6 transition-transform border border-emerald-400/50">
                <CheckCircle2 className="w-6 h-6 text-white" />
              </div>
              <p className="text-base font-black leading-relaxed tracking-tight">{suggestion}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Detailed Nutrient Breakdown */}
      {result.mode === 'full' && result.nutrients && (
        <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-black text-gray-800 flex items-center gap-2 tracking-tight">
              <FlaskConical className="w-5 h-5 text-emerald-500" />
              {t.detailedBreakdown}
            </h3>
            <div className="px-4 py-1 bg-gray-50 rounded-full text-[10px] font-black text-gray-400 uppercase tracking-widest">
              Per 100g/Serving
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Fat Breakdown */}
            <div className="p-6 rounded-[2rem] bg-amber-50/50 border border-amber-100 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-amber-100 rounded-xl text-amber-600">
                    <Droplets className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-black text-amber-900 uppercase tracking-widest">{t.fatBreakdown}</span>
                </div>
              </div>
              <div className="space-y-4">
                {[
                  { label: t.totalFat, value: result.nutrients.fat?.total?.value || 0, unit: result.nutrients.fat?.total?.unit || 'g', color: 'bg-amber-500' },
                  { label: t.saturatedFat, value: result.nutrients.fat?.saturated?.value || 0, unit: result.nutrients.fat?.saturated?.unit || 'g', color: 'bg-orange-500' },
                  { label: t.transFat, value: result.nutrients.fat?.trans?.value || 0, unit: result.nutrients.fat?.trans?.unit || 'g', color: 'bg-red-500' },
                  { 
                    label: t.unsaturatedFat, 
                    value: Math.max(0, (result.nutrients.fat?.total?.value || 0) - ((result.nutrients.fat?.saturated?.value || 0) + (result.nutrients.fat?.trans?.value || 0))), 
                    unit: result.nutrients.fat?.total?.unit || 'g', 
                    color: 'bg-emerald-500' 
                  },
                ].map((fat, i) => (
                  <div key={i} className="space-y-2">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
                      <span className="text-gray-500">{fat.label}</span>
                      <span className="text-gray-900">{fat.value}{fat.unit}</span>
                    </div>
                    <div className="h-2 bg-gray-200/50 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min((fat.value / (result.nutrients?.fat?.total?.value || 1)) * 100, 100)}%` }}
                        transition={{ duration: 1, delay: 0.2 + (i * 0.1) }}
                        className={cn("h-full rounded-full", fat.color)}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Carbs & Protein */}
            <div className="p-6 rounded-[2rem] bg-blue-50/50 border border-blue-100 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-blue-100 rounded-xl text-blue-600">
                    <Zap className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-black text-blue-900 uppercase tracking-widest">{t.energyMacros}</span>
                </div>
              </div>
              <div className="space-y-4">
                {[
                  { label: 'Carbohydrates', value: result.nutrients.carbohydrates?.value || 0, unit: result.nutrients.carbohydrates?.unit || 'g', icon: <ChartBar className="w-4 h-4" />, color: 'text-blue-600', bg: 'bg-blue-50' },
                  { label: 'Protein', value: result.nutrients.protein?.value || 0, unit: result.nutrients.protein?.unit || 'g', icon: <Layers className="w-4 h-4" />, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                  { label: 'Fiber', value: result.nutrients.fiber?.value || 0, unit: result.nutrients.fiber?.unit || 'g', icon: <TrendingUp className="w-4 h-4" />, color: 'text-purple-600', bg: 'bg-purple-50' },
                ].map((macro, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + (i * 0.1) }}
                    className={cn("flex items-center justify-between p-4 rounded-2xl border border-white shadow-sm", macro.bg)}
                  >
                    <div className="flex items-center gap-3">
                      <div className={cn("p-2 rounded-xl bg-white shadow-sm", macro.color)}>
                        {macro.icon}
                      </div>
                      <span className="text-xs font-black text-gray-700 uppercase tracking-tight">{macro.label}</span>
                    </div>
                    <span className="text-lg font-black text-gray-900">{macro.value}<span className="text-xs font-bold text-gray-400 ml-0.5">{macro.unit}</span></span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Daily Value Summary */}
            <div className="p-6 rounded-[2rem] bg-emerald-50/50 border border-emerald-100 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-emerald-100 rounded-xl text-emerald-600">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-black text-emerald-900 uppercase tracking-widest">{t.dailyValueSummary}</span>
                </div>
              </div>
              <div className="space-y-5">
                {[
                  { label: 'Sugar', value: result.nutrients.sugar?.value || 0, limit: 50, unit: 'g', color: 'bg-red-500' },
                  { label: 'Sodium', value: result.nutrients.sodium?.value || 0, limit: 2300, unit: 'mg', color: 'bg-amber-500' },
                  { label: 'Calories', value: result.nutrients.calories?.value || 0, limit: 2000, unit: 'kcal', color: 'bg-emerald-500' },
                ].map((dv, i) => (
                  <div key={i} className="space-y-2">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
                      <span className="text-gray-500">{dv.label}</span>
                      <span className={cn("font-black", (dv.value / dv.limit) > 0.8 ? "text-red-500" : "text-emerald-600")}>
                        {Math.round((dv.value / dv.limit) * 100)}%
                      </span>
                    </div>
                    <div className="h-2 bg-gray-200/50 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min((dv.value / dv.limit) * 100, 100)}%` }}
                        transition={{ duration: 1, delay: 0.4 + (i * 0.1) }}
                        className={cn("h-full rounded-full", dv.color)}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Micronutrients Section */}
      {result.micronutrients && result.micronutrients.length > 0 && (
        <div className="space-y-8">
          <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <h3 className="text-xl font-black text-gray-800 flex items-center gap-2 tracking-tight">
                  <Zap className="w-5 h-5 text-blue-500" />
                  {t.micronutrients}
                </h3>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Vitamins & Minerals Analysis</p>
              </div>
              <div className="flex bg-gray-100 p-1 rounded-2xl" role="group" aria-label="Micro View Toggle">
                <button 
                  onClick={() => setMicroView('grid')}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                    microView === 'grid' ? "bg-white shadow-sm text-blue-600" : "text-gray-400 hover:text-gray-600"
                  )}
                >
                  <ChartBar className="w-4 h-4" />
                  Grid
                </button>
                <button 
                  onClick={() => setMicroView('radar')}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                    microView === 'radar' ? "bg-white shadow-sm text-blue-600" : "text-gray-400 hover:text-gray-600"
                  )}
                >
                  <Layers className="w-4 h-4" />
                  Radar
                </button>
              </div>
            </div>

            {microView === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {result.micronutrients.map((micro, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.05 }}
                    className="p-6 rounded-3xl bg-blue-50/50 border border-blue-100 flex flex-col gap-2 group hover:bg-blue-50 transition-all hover:shadow-md"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">{micro.name}</span>
                      <div className="w-6 h-6 rounded-lg bg-white flex items-center justify-center shadow-sm">
                        <Zap className="w-3 h-3 text-blue-400" />
                      </div>
                    </div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-2xl font-black text-gray-900">{micro.value}</span>
                      <span className="text-xs font-bold text-gray-400">{micro.unit}</span>
                    </div>
                    {micro.dailyValuePercentage !== undefined && (
                      <div className="mt-4 space-y-2">
                        <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
                          <span className="text-gray-400">{t.dailyValue}</span>
                          <span className="text-blue-600">{micro.dailyValuePercentage}%</span>
                        </div>
                        <div className="h-1.5 bg-blue-100 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            whileInView={{ width: `${Math.min(micro.dailyValuePercentage, 100)}%` }}
                            transition={{ duration: 1, delay: 0.5 }}
                            className="h-full bg-blue-500 rounded-full shadow-[0_0_8px_rgba(59,130,246,0.5)]"
                          />
                        </div>
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="h-[400px] w-full bg-blue-50/30 rounded-[2rem] border border-blue-100/50 p-4">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                    <PolarGrid stroke="#cbd5e1" strokeDasharray="4 4" />
                    <PolarAngleAxis 
                      dataKey="subject" 
                      tick={{ fill: '#475569', fontSize: 11, fontWeight: 800 }}
                    />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                    <Radar
                      name="Daily Value"
                      dataKey="A"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.4}
                      strokeWidth={3}
                      animationDuration={1500}
                    />
                    <Tooltip content={<CustomTooltip />} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          {/* Micronutrient Trends */}
          {trendData.length > 1 && commonMicros.length > 0 && (
            <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <h3 className="text-xl font-black text-gray-800 flex items-center gap-2 tracking-tight">
                    <TrendingUp className="w-5 h-5 text-blue-500" />
                    Micronutrient Trends
                  </h3>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Tracking your intake over time</p>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-2xl text-[10px] font-black text-gray-500 uppercase tracking-widest">
                  <Calendar className="w-4 h-4 text-blue-400" />
                  Last {trendData.length} Scans
                </div>
              </div>
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="date" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 10, fontWeight: 800, fill: '#94a3b8' }} 
                      dy={10}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 10, fontWeight: 800, fill: '#94a3b8' }}
                      dx={-10}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend 
                      verticalAlign="top" 
                      align="right" 
                      iconType="circle"
                      wrapperStyle={{ paddingBottom: '20px', fontSize: '10px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em' }}
                    />
                    {commonMicros.map((micro, idx) => (
                      <Line
                        key={micro}
                        type="monotone"
                        dataKey={micro}
                        stroke={['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444'][idx % 5]}
                        strokeWidth={4}
                        dot={{ r: 6, strokeWidth: 2, fill: '#fff' }}
                        activeDot={{ r: 8, strokeWidth: 0 }}
                        animationDuration={2000}
                        animationEasing="ease-in-out"
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </div>
      )}

      {/* WHO Comparison Section */}
      {result.mode === 'full' && result.nutrients && (
        <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="text-xl font-black text-gray-800 flex items-center gap-2 tracking-tight">
                <ShieldCheck className="w-5 h-5 text-emerald-500" />
                WHO Comparison
              </h3>
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Global Health Standards Alignment</p>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 rounded-2xl text-[10px] font-black text-emerald-600 uppercase tracking-widest">
              <Globe className="w-4 h-4" />
              World Health Organization
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={whoComparisonData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                  <XAxis type="number" domain={[0, 150]} hide />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fontSize: 11, fontWeight: 800, fill: '#475569' }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="value" radius={[0, 10, 10, 0]} barSize={24}>
                    {whoComparisonData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.value > 100 ? '#ef4444' : '#10b981'} />
                    ))}
                  </Bar>
                  <Line type="monotone" dataKey="limit" stroke="#94a3b8" strokeDasharray="5 5" dot={false} strokeWidth={2} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-col justify-center space-y-6">
              <div className="p-6 bg-gray-50 rounded-[2rem] border border-gray-100 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm">
                    <HeartPulse className="w-5 h-5 text-emerald-500" />
                  </div>
                  <span className="text-sm font-black text-gray-800 uppercase tracking-tight">Health Impact Analysis</span>
                </div>
                <p className="text-sm font-bold text-gray-600 leading-relaxed">
                  Comparing this food item against WHO recommended daily limits for an average adult (2000 kcal diet). 
                  Values over 100% indicate this single item exceeds the recommended daily intake for that nutrient.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100 text-center">
                  <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">Status</p>
                  <p className="text-sm font-black text-emerald-900">
                    {whoComparisonData.every(d => d.value <= 100) ? 'Compliant' : 'Exceeds Limits'}
                  </p>
                </div>
                <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 text-center">
                  <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-1">Risk Level</p>
                  <p className="text-sm font-black text-blue-900">
                    {whoComparisonData.some(d => d.value > 120) ? 'High' : whoComparisonData.some(d => d.value > 100) ? 'Moderate' : 'Low'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Fat Quality Analysis Sub-section */}
          <div className="pt-8 border-t border-gray-100 space-y-4">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-amber-50 rounded-xl text-amber-600">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-black text-gray-800 uppercase tracking-widest">Fat Quality Analysis (WHO Standards)</h4>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {whoComparisonData
                .filter(d => d.name.toLowerCase().includes('saturated fat') || d.name.toLowerCase().includes('trans fat'))
                .map((fat, idx) => (
                  <div key={idx} className={cn(
                    "p-5 rounded-3xl border transition-all",
                    fat.value > 100 
                      ? "bg-red-50 border-red-100 shadow-sm shadow-red-100/50" 
                      : "bg-gray-50 border-gray-100"
                  )}>
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <p className={cn(
                          "text-[10px] font-black uppercase tracking-widest mb-1",
                          fat.value > 100 ? "text-red-600" : "text-gray-400"
                        )}>{fat.name}</p>
                        <p className="text-lg font-black text-gray-900">{fat.current}{fat.unit}</p>
                      </div>
                      <div className={cn(
                        "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                        fat.value > 100 ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"
                      )}>
                        {fat.value > 100 ? 'Exceeds' : 'Safe'}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] font-bold text-gray-500">
                        <span>WHO Daily Limit</span>
                        <span>{fat.max}{fat.unit}</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className={cn(
                            "h-full rounded-full transition-all duration-1000",
                            fat.value > 100 ? "bg-red-500" : "bg-emerald-500"
                          )}
                          style={{ width: `${Math.min(fat.value, 100)}%` }}
                        />
                      </div>
                      {fat.value > 100 && (
                        <p className="text-[10px] font-bold text-red-600 mt-2">
                          Warning: This item contains {Math.round(fat.value)}% of your recommended daily {fat.name.toLowerCase()}.
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              {whoComparisonData.filter(d => d.name.toLowerCase().includes('saturated fat') || d.name.toLowerCase().includes('trans fat')).length === 0 && (
                <div className="col-span-full p-6 bg-gray-50 rounded-3xl border border-gray-100 text-center">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Detailed fat quality data unavailable for this item</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Footer Disclaimer */}
      <div className="pt-8 border-t border-gray-100">
        <div className="bg-gray-900 p-10 rounded-[3rem] space-y-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:scale-110 transition-transform">
            <ShieldAlert className="w-40 h-40 text-white" />
          </div>
          <div className="flex items-center gap-4 relative z-10">
            <div className="w-12 h-12 rounded-2xl bg-red-500 flex items-center justify-center shadow-lg shadow-red-500/20">
              <AlertCircle className="w-6 h-6 text-white" />
            </div>
            <span className="text-lg font-black text-white uppercase tracking-[0.2em]">{t.medicalDisclaimer}</span>
          </div>
          <p className="text-sm font-bold text-gray-400 leading-relaxed max-w-4xl relative z-10">
            {t.medicalDisclaimerText}
          </p>
          <div className="pt-6 border-t border-gray-800 flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
            <div className="flex items-center gap-3 text-[10px] font-black text-gray-500 uppercase tracking-widest">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              NutriScan AI Core v2.5.0
            </div>
            <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest">
              © 2026 NutriScan Bangladesh • All Rights Reserved
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisDashboard;
