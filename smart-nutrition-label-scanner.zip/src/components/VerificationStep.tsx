import React from 'react';
import { OcrResult, OcrNutrients, AppLanguage } from '../types';
import { translations } from '../translations';
import { motion } from 'motion/react';
import { Check, Edit3, AlertCircle, RefreshCcw } from 'lucide-react';
import { cn } from '../lib/utils';

interface VerificationStepProps {
  ocrResult: OcrResult;
  language: AppLanguage;
  onConfirm: (nutrients: OcrNutrients, ingredients: string[]) => void;
  onRetake: () => void;
}

export default function VerificationStep({ ocrResult, language, onConfirm, onRetake }: VerificationStepProps) {
  const t = translations[language];
  const [nutrients, setNutrients] = React.useState<OcrNutrients>(ocrResult.nutrients);
  const [ingredients, setIngredients] = React.useState<string[]>(ocrResult.ingredients);
  const [isEditing, setIsEditing] = React.useState(false);

  const handleNutrientChange = (key: keyof OcrNutrients, value: string) => {
    const numValue = parseFloat(value);
    setNutrients(prev => ({ ...prev, [key]: isNaN(numValue) ? undefined : numValue }));
  };

  const handleIngredientChange = (index: number, value: string) => {
    const newIngredients = [...ingredients];
    newIngredients[index] = value;
    setIngredients(newIngredients);
  };

  const addIngredient = () => setIngredients([...ingredients, '']);
  const removeIngredient = (index: number) => setIngredients(ingredients.filter((_, i) => i !== index));

  // Cross-validation logic
  const warnings: string[] = [];
  const totalMacros = (nutrients.sugar || 0) + (nutrients.fat || 0) + (nutrients.protein || 0) + (nutrients.carbohydrates || 0);
  
  if (totalMacros > 100) warnings.push("Total nutrients (Sugar + Fat + Protein + Carbs) exceed 100g per 100g.");
  if ((nutrients.sugar || 0) > (nutrients.carbohydrates || 0)) warnings.push("Sugar cannot be greater than total Carbohydrates.");
  if ((nutrients.fiber || 0) > (nutrients.carbohydrates || 0)) warnings.push("Fiber cannot be greater than total Carbohydrates.");
  if ((nutrients.sodium || 0) > 10000) warnings.push("Sodium value seems extremely high (>10,000mg).");
  if ((nutrients.calories || 0) > 900) warnings.push("Calories seem unusually high (>900 kcal per 100g).");

  return (
    <div className="max-w-2xl mx-auto space-y-8 p-6">
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-100 text-amber-700 font-bold text-sm">
          <AlertCircle className="w-4 h-4" />
          Analysis Confidence: {ocrResult.confidenceScore}% (Moderate)
        </div>
        <h2 className="text-3xl font-black text-gray-900 tracking-tight">{t.verifyData}</h2>
        <p className="text-gray-500 font-medium">Please verify the nutritional values before we proceed with the full health analysis.</p>
      </div>

      {warnings.length > 0 && (
        <div className="p-4 bg-red-50 border border-red-100 rounded-2xl space-y-2">
          {warnings.map((w, i) => (
            <div key={i} className="flex items-center gap-2 text-red-700 text-sm font-bold">
              <AlertCircle className="w-4 h-4" />
              {w}
            </div>
          ))}
        </div>
      )}

      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
        <div className="p-8 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-black text-gray-800">Nutritional Values (per 100g)</h3>
            <button 
              onClick={() => setIsEditing(!isEditing)}
              className="flex items-center gap-2 text-sm font-bold text-emerald-600 hover:text-emerald-700 transition-colors"
            >
              <Edit3 className="w-4 h-4" />
              {isEditing ? 'Done Editing' : 'Quick Edit'}
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {Object.entries({
              calories: 'Calories (kcal)',
              sugar: 'Sugar (g)',
              sodium: 'Sodium (mg)',
              fat: 'Total Fat (g)',
              protein: 'Protein (g)',
              carbohydrates: 'Carbs (g)',
              fiber: 'Fiber (g)'
            }).map(([key, label]) => (
              <div key={key} className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">{label}</label>
                <input
                  type="number"
                  disabled={!isEditing}
                  value={nutrients[key as keyof OcrNutrients] ?? ''}
                  onChange={(e) => handleNutrientChange(key as keyof OcrNutrients, e.target.value)}
                  className={cn(
                    "w-full px-4 py-3 rounded-xl border font-bold transition-all outline-none",
                    isEditing ? "border-emerald-200 bg-emerald-50/30 focus:border-emerald-500" : "border-gray-100 bg-gray-50 text-gray-500"
                  )}
                />
              </div>
            ))}
          </div>

          <div className="space-y-4 pt-4 border-t border-gray-50">
            <h3 className="text-xl font-black text-gray-800">Ingredients</h3>
            <div className="flex flex-wrap gap-2">
              {ingredients.map((ing, idx) => (
                <div key={idx} className="group relative">
                  <input
                    disabled={!isEditing}
                    value={ing}
                    onChange={(e) => handleIngredientChange(idx, e.target.value)}
                    className={cn(
                      "px-3 py-1.5 rounded-full text-xs font-bold border transition-all outline-none",
                      isEditing ? "border-emerald-200 bg-emerald-50 pr-8" : "border-gray-100 bg-gray-50 text-gray-600"
                    )}
                  />
                  {isEditing && (
                    <button 
                      onClick={() => removeIngredient(idx)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-emerald-400 hover:text-red-500 transition-colors"
                    >
                      ×
                    </button>
                  )}
                </div>
              ))}
              {isEditing && (
                <button 
                  onClick={addIngredient}
                  className="px-3 py-1.5 rounded-full text-xs font-bold border border-dashed border-emerald-300 text-emerald-600 hover:bg-emerald-50 transition-all"
                >
                  + Add
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="p-4 bg-gray-50 flex gap-3">
          <button
            onClick={onRetake}
            className="flex-1 flex items-center justify-center gap-2 py-4 rounded-2xl font-black text-gray-600 hover:bg-gray-100 transition-all"
          >
            <RefreshCcw className="w-5 h-5" />
            {t.retakePhoto}
          </button>
          <button
            onClick={() => onConfirm(nutrients, ingredients)}
            className="flex-[2] flex items-center justify-center gap-2 py-4 rounded-2xl bg-emerald-600 text-white font-black shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all"
          >
            <Check className="w-5 h-5" />
            {t.confirmAnalysis}
          </button>
        </div>
      </div>
    </div>
  );
}
