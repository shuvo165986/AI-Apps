import React from 'react';
import { AnalysisResult, ProductAnalysisResult, PharmaAnalysisResult, ElectricalAnalysisResult, AppLanguage } from '../types';
import { translations } from '../translations';
import { motion } from 'motion/react';
import { ArrowLeft, Check, X, Info, TrendingDown, TrendingUp, Minus, Utensils, Pill, Zap, FlaskConical } from 'lucide-react';
import { cn } from '../lib/utils';

type ComparisonItem = (AnalysisResult | ProductAnalysisResult | PharmaAnalysisResult | ElectricalAnalysisResult) & { type?: 'food' | 'non-food' | 'pharma' | 'electrical' };

interface ComparisonViewProps {
  results: ComparisonItem[];
  language: AppLanguage;
  onBack: () => void;
}

export default function ComparisonView({ results, language, onBack }: ComparisonViewProps) {
  const t = translations[language];

  const nutrientRows = [
    { key: 'calories', label: t.totalCalories, unit: 'kcal', better: 'lower' },
    { key: 'sugar', label: t.totalSugar, unit: 'g', better: 'lower' },
    { key: 'sodium', label: t.totalSodium, unit: 'mg', better: 'lower' },
    { key: 'fat', label: t.totalFat, unit: 'g', subKey: 'total', better: 'lower' },
    { key: 'protein', label: 'Protein', unit: 'g', better: 'higher' },
    { key: 'carbohydrates', label: 'Carbs', unit: 'g', better: 'higher' },
    { key: 'fiber', label: 'Fiber', unit: 'g', better: 'higher' },
  ];

  const pharmaRows = [
    { key: 'activeIngredients', label: t.activeIngredients || 'Active Ingredients', count: true },
    { key: 'sideEffects', label: t.sideEffects || 'Side Effects', count: true },
    { key: 'warnings', label: t.warnings || 'Warnings', count: true },
    { key: 'pregnancyCategory', label: t.pregnancyCategory || 'Pregnancy Category' },
  ];

  const electricalRows = [
    { key: 'energyEfficiency', label: t.energyEfficiency || 'Energy Efficiency' },
    { key: 'safetyFeatures', label: t.safetyFeatures || 'Safety Features', count: true },
  ];

  const productRows = [
    { key: 'hazardLevel', label: t.hazardLevel || 'Hazard Level', better: 'lower' },
    { key: 'isVegan', label: t.vegan || 'Vegan', boolean: true },
    { key: 'isCrueltyFree', label: t.crueltyFree || 'Cruelty Free', boolean: true },
    { key: 'pregnancySafe', label: t.pregnancySafe || 'Pregnancy Safe', boolean: true },
  ];

  const getNutrientValue = (result: any, key: string, subKey?: string) => {
    if (!result.nutrients) return null;
    const nutrient = (result.nutrients as any)[key];
    if (!nutrient) return null;
    if (subKey) return nutrient[subKey]?.value;
    return nutrient.value;
  };

  const getEvaluationColor = (evaluation: string) => {
    switch (evaluation) {
      case 'excellent': return 'text-emerald-600 bg-emerald-50';
      case 'good': return 'text-blue-600 bg-blue-50';
      case 'average': return 'text-amber-600 bg-amber-50';
      case 'poor': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-500 hover:text-emerald-600 transition-colors font-bold"
          aria-label={t.backToHistory}
        >
          <ArrowLeft className="w-5 h-5" />
          {t.backToHistory}
        </button>
        <h2 className="text-2xl font-black text-gray-900 tracking-tight">{t.comparison}</h2>
      </div>

      <div className="overflow-x-auto pb-4 -mx-4 px-4 sm:mx-0 sm:px-0">
        <div className="min-w-[600px]">
          <div className="grid grid-cols-[200px_repeat(auto-fit,minmax(150px,1fr))] gap-4">
            {/* Header Row */}
            <div className="flex items-end pb-4">
              <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Nutrient</span>
            </div>
            {results.map((result, idx) => {
              const itemType = result.type || 'food';
              const isFood = itemType === 'food';
              const isPharma = itemType === 'pharma';
              const isElectrical = itemType === 'electrical';
              
              let score = 0;
              let evaluation = 'average';

              if (isFood) {
                score = (result as AnalysisResult).healthScore;
                evaluation = (result as AnalysisResult).evaluation;
              } else if (isPharma) {
                score = (result as PharmaAnalysisResult).safetyScore;
                evaluation = score >= 80 ? 'excellent' : score >= 50 ? 'average' : 'poor';
              } else if (isElectrical) {
                score = (result as ElectricalAnalysisResult).safetyScore;
                evaluation = score >= 80 ? 'excellent' : score >= 50 ? 'average' : 'poor';
              } else {
                score = (result as ProductAnalysisResult).safetyScore;
                evaluation = (result as ProductAnalysisResult).overallSafety === 'safe' ? 'excellent' : 
                            (result as ProductAnalysisResult).overallSafety === 'caution' ? 'average' : 'poor';
              }

              return (
                <div key={idx} className="space-y-3 text-center">
                  <div className="h-16 flex flex-col items-center justify-center gap-1">
                    {isFood ? (
                      <Utensils className="w-4 h-4 text-emerald-500" />
                    ) : isPharma ? (
                      <Pill className="w-4 h-4 text-purple-500" />
                    ) : isElectrical ? (
                      <Zap className="w-4 h-4 text-orange-500" />
                    ) : (
                      <FlaskConical className="w-4 h-4 text-blue-500" />
                    )}
                    <h4 className="font-black text-gray-900 text-xs line-clamp-1 px-2">
                      {result.productName || `Product ${idx + 1}`}
                    </h4>
                  </div>
                  <div className={cn(
                    "inline-flex items-center justify-center w-16 h-16 rounded-2xl font-black text-2xl shadow-sm",
                    evaluation === 'excellent' ? "bg-emerald-100 text-emerald-700" :
                    evaluation === 'good' ? "bg-blue-100 text-blue-700" :
                    evaluation === 'average' ? "bg-amber-100 text-amber-700" :
                    "bg-red-100 text-red-700"
                  )}>
                    {score}
                  </div>
                  <div className={cn(
                    "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mx-auto w-fit",
                    getEvaluationColor(evaluation)
                  )}>
                    {evaluation}
                  </div>
                </div>
              );
            })}

            {/* Nutrient Rows (Only for Food) */}
            {results.some(r => !r.type || r.type === 'food') && nutrientRows.map((row) => {
              const values = results.map(r => {
                if (r.type && r.type !== 'food') return null;
                return getNutrientValue(r as AnalysisResult, row.key, row.subKey);
              }).filter(v => v !== null) as number[];
              const bestValue = values.length > 0 ? (row.better === 'lower' ? Math.min(...values) : Math.max(...values)) : null;
              const worstValue = values.length > 0 ? (row.better === 'lower' ? Math.max(...values) : Math.min(...values)) : null;

              return (
                <React.Fragment key={row.key}>
                  <div className="flex items-center py-4 border-t border-gray-50">
                    <span className="text-sm font-bold text-gray-600">{row.label}</span>
                  </div>
                  {results.map((result, idx) => {
                    const val = getNutrientValue(result, row.key, row.subKey);
                    const isBest = val !== null && val === bestValue && values.length > 1 && bestValue !== worstValue;
                    const isWorst = val !== null && val === worstValue && values.length > 1 && bestValue !== worstValue;

                    return (
                      <div key={idx} className="flex flex-col items-center justify-center py-4 border-t border-gray-50 relative group">
                        <div className="flex items-center gap-1">
                          <span className={cn(
                            "font-black transition-colors",
                            isBest ? "text-emerald-600" : isWorst ? "text-red-500" : "text-gray-900"
                          )}>
                            {val !== null ? `${val}${row.unit}` : '-'}
                          </span>
                          {isBest && (
                            <div className="flex items-center text-emerald-500" title="Better choice">
                              {row.better === 'lower' ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
                            </div>
                          )}
                          {isWorst && (
                            <div className="flex items-center text-red-400" title="Less healthy choice">
                              {row.better === 'lower' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </React.Fragment>
              );
            })}

            {/* Ingredients Summary (Food/Product/Pharma) */}
            <div className="flex items-center py-4 border-t border-gray-50">
              <span className="text-sm font-bold text-gray-600">Safety Alerts</span>
            </div>
            {results.map((result, idx) => {
              const alerts = (result as any).healthAlerts || [];
              return (
                <div key={idx} className="flex flex-col items-center justify-center py-4 border-t border-gray-50">
                  {alerts.length > 0 ? (
                    <span className="font-black text-red-500">{alerts.length}</span>
                  ) : (
                    <Check className="w-4 h-4 text-emerald-500" />
                  )}
                </div>
              );
            })}

            {/* Additives */}
            <div className="flex items-center py-4 border-t border-gray-50">
              <span className="text-sm font-bold text-gray-600">Additives</span>
            </div>
            {results.map((result, idx) => {
              const additives = (result as any).ingredientInsights?.filter((i: any) => i.category === 'additive') || [];
              return (
                <div key={idx} className="flex flex-col items-center justify-center py-4 border-t border-gray-50">
                  <span className="font-black text-gray-900">{additives.length}</span>
                </div>
              );
            })}

            {/* Pharma Specific Rows */}
            {results.some(r => r.type === 'pharma') && pharmaRows.map((row) => (
              <React.Fragment key={row.key}>
                <div className="flex items-center py-4 border-t border-gray-50">
                  <span className="text-sm font-bold text-gray-600">{row.label}</span>
                </div>
                {results.map((result, idx) => {
                  const val = (result as any)[row.key];
                  const displayVal = Array.isArray(val) ? val.length : val;
                  return (
                    <div key={idx} className="flex flex-col items-center justify-center py-4 border-t border-gray-50">
                      <span className="font-black text-gray-900">{displayVal || '-'}</span>
                    </div>
                  );
                })}
              </React.Fragment>
            ))}

            {/* Electrical Specific Rows */}
            {results.some(r => r.type === 'electrical') && electricalRows.map((row) => (
              <React.Fragment key={row.key}>
                <div className="flex items-center py-4 border-t border-gray-50">
                  <span className="text-sm font-bold text-gray-600">{row.label}</span>
                </div>
                {results.map((result, idx) => {
                  const val = (result as any)[row.key];
                  const displayVal = Array.isArray(val) ? val.length : val;
                  return (
                    <div key={idx} className="flex flex-col items-center justify-center py-4 border-t border-gray-50">
                      <span className="font-black text-gray-900 text-xs text-center">{displayVal || '-'}</span>
                    </div>
                  );
                })}
              </React.Fragment>
            ))}

            {/* Product Specific Rows */}
            {results.some(r => r.type === 'non-food') && productRows.map((row) => (
              <React.Fragment key={row.key}>
                <div className="flex items-center py-4 border-t border-gray-50">
                  <span className="text-sm font-bold text-gray-600">{row.label}</span>
                </div>
                {results.map((result, idx) => {
                  const val = (result as any)[row.key];
                  return (
                    <div key={idx} className="flex flex-col items-center justify-center py-4 border-t border-gray-50">
                      {row.boolean ? (
                        val ? <Check className="w-4 h-4 text-emerald-500" /> : <X className="w-4 h-4 text-red-400" />
                      ) : (
                        <span className="font-black text-gray-900">{val || '-'}</span>
                      )}
                    </div>
                  );
                })}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {/* Comparison Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 bg-emerald-50 rounded-3xl border border-emerald-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-emerald-600 shadow-sm">
              <TrendingUp className="w-6 h-6" />
            </div>
            <h4 className="font-black text-gray-900 uppercase tracking-widest text-sm">Best Choice</h4>
          </div>
          {(() => {
            const best = [...results].sort((a, b) => {
              const getScore = (item: any) => {
                const type = item.type || 'food';
                if (type === 'food') return item.healthScore || 0;
                return item.safetyScore || 0;
              };
              return getScore(b) - getScore(a);
            })[0];
            const bestScore = (best as any).healthScore || (best as any).safetyScore;
            return (
              <div className="space-y-2">
                <p className="text-emerald-800 font-bold">{best.productName || 'Unnamed Product'}</p>
                <p className="text-emerald-600 text-sm font-medium">
                  This product has the highest safety/health score of {bestScore} among your selection.
                </p>
              </div>
            );
          })()}
        </div>

        <div className="p-6 bg-blue-50 rounded-3xl border border-blue-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-blue-600 shadow-sm">
              <Info className="w-6 h-6" />
            </div>
            <h4 className="font-black text-gray-900 uppercase tracking-widest text-sm">Quick Insight</h4>
          </div>
          <p className="text-blue-800 text-sm font-medium leading-relaxed">
            {results.every(r => r.type === 'food' || !r.type) ? (
              "Comparing products side-by-side helps you identify which one is nutritionally superior. Look for lower sugar and sodium values for better long-term health."
            ) : results.every(r => r.type === 'pharma') ? (
              "Compare active ingredients and potential side effects. Always consult a healthcare professional before switching medications."
            ) : results.every(r => r.type === 'electrical') ? (
              "Look for energy efficiency ratings and safety certifications. A higher safety score indicates better protection features."
            ) : (
              "Side-by-side comparison highlights differences in safety ratings, ingredients, and overall quality across different product categories."
            )}
          </p>
        </div>
      </div>
    </div>
  );
}
