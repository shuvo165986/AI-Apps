import React from 'react';
import { PharmaAnalysisResult, AppLanguage } from '../types';
import { motion } from 'motion/react';
import { ShieldCheck, AlertTriangle, CheckCircle2, Info, FlaskConical, Activity, ArrowLeft, Heart, Sparkles, Baby, Clock, Pill, Stethoscope, ClipboardList, Zap, Ban, Globe } from 'lucide-react';
import { cn } from '../lib/utils';
import { translations } from '../translations';

interface PharmaAnalysisDashboardProps {
  result: PharmaAnalysisResult;
  onBack: () => void;
  language: AppLanguage;
}

export default function PharmaAnalysisDashboard({ result, onBack, language }: PharmaAnalysisDashboardProps) {
  const t = translations[language];
  const isBn = language === 'bn';

  const getSafetyColor = (score: number) => {
    if (score >= 80) return 'text-emerald-600 bg-emerald-50 border-emerald-100';
    if (score >= 50) return 'text-amber-600 bg-amber-50 border-amber-100';
    return 'text-red-600 bg-red-50 border-red-100';
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button 
          onClick={onBack}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="text-center flex-1 pr-10">
          <div className="flex items-center justify-center gap-2 mb-1">
            <h2 className="text-2xl font-black text-gray-900">{result.productName || (isBn ? 'ঔষধ বিশ্লেষণ' : 'Pharma Analysis')}</h2>
            {result.dataSource === 'ocr' ? (
              <div className="flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-black uppercase tracking-tighter">
                <ShieldCheck className="w-3 h-3" />
                {isBn ? 'যাচাইকৃত' : 'Verified'}
              </div>
            ) : (
              <div className="flex items-center gap-1 px-2 py-0.5 bg-blue-100 text-blue-700 rounded-lg text-[10px] font-black uppercase tracking-tighter">
                <Globe className="w-3 h-3" />
                {isBn ? 'ওয়েব সার্চ' : 'Web Search'}
              </div>
            )}
          </div>
          <p className="text-sm font-bold text-blue-600 uppercase tracking-widest">{result.manufacturer || (isBn ? 'প্রস্তুতকারক অজানা' : 'Unknown Manufacturer')}</p>
        </div>
      </div>

      {/* Hero Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl text-center space-y-6"
        >
          <div className="relative inline-block">
            <svg className="w-40 h-40 transform -rotate-90">
              <circle
                cx="80"
                cy="80"
                r="70"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                className="text-gray-100"
              />
              <motion.circle
                cx="80"
                cy="80"
                r="70"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                strokeDasharray={440}
                initial={{ strokeDashoffset: 440 }}
                animate={{ strokeDashoffset: 440 - (440 * result.safetyScore) / 100 }}
                className={cn(
                  "transition-all duration-1000",
                  result.safetyScore >= 80 ? "text-emerald-500" : result.safetyScore >= 50 ? "text-amber-500" : "text-red-500"
                )}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-black text-gray-900">{result.safetyScore}</span>
              <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.safetyScore}</span>
            </div>
          </div>

          <div className="space-y-4">
            <div className={cn(
              "inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-sm",
              result.safetyScore >= 80 ? "bg-emerald-100 text-emerald-700 border border-emerald-200" :
              result.safetyScore >= 50 ? "bg-amber-100 text-amber-700 border border-amber-200" :
              "bg-red-100 text-red-700 border border-red-200"
            )}>
              {result.safetyScore >= 80 ? (isBn ? 'উচ্চ নিরাপত্তা' : 'High Safety') :
               result.safetyScore >= 50 ? (isBn ? 'মাঝারি নিরাপত্তা' : 'Moderate Safety') :
               (isBn ? 'নিম্ন নিরাপত্তা' : 'Low Safety')}
            </div>

            <div className="w-full max-w-[200px] mx-auto space-y-1">
              <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${result.safetyScore}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className={cn(
                    "h-full transition-all duration-500",
                    result.safetyScore >= 80 ? "bg-emerald-500" :
                    result.safetyScore >= 50 ? "bg-amber-500" :
                    "bg-red-500"
                  )}
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className={cn(
              "inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-black uppercase tracking-widest",
              result.isOtc ? "text-emerald-600 bg-emerald-50" : "text-blue-600 bg-blue-50"
            )}>
              {result.isOtc ? <CheckCircle2 className="w-4 h-4" /> : <Stethoscope className="w-4 h-4" />}
              {result.isOtc ? t.otc : t.prescriptionOnly}
            </div>
            <p className="text-gray-600 font-medium leading-relaxed">
              {result.simpleExplanation}
            </p>
          </div>
        </motion.div>

        <div className="space-y-6">
          {/* Indications */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-blue-50 p-6 rounded-3xl border border-blue-100 space-y-3"
          >
            <div className="flex items-center gap-2 text-blue-600">
              <Zap className="w-5 h-5" />
              <h3 className="font-black uppercase tracking-widest text-xs">{t.indications}</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {result.indications.map((ind, idx) => (
                <span key={idx} className="px-3 py-1 bg-white text-blue-700 text-xs font-bold rounded-full shadow-sm">
                  {ind}
                </span>
              ))}
            </div>
          </motion.div>

          {/* Dosage */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100 space-y-3"
          >
            <div className="flex items-center gap-2 text-emerald-600">
              <Clock className="w-5 h-5" />
              <h3 className="font-black uppercase tracking-widest text-xs">{t.dosage}</h3>
            </div>
            <p className="text-sm font-bold text-emerald-800 leading-relaxed">
              {result.dosageInstructions}
            </p>
          </motion.div>
        </div>
      </div>

      {/* Active Ingredients */}
      <div className="space-y-4">
        <div className="flex items-center gap-3 px-2">
          <Pill className="w-6 h-6 text-blue-600" />
          <h3 className="text-lg font-black text-gray-900">{t.activeIngredients}</h3>
        </div>
        <div className="grid gap-4">
          {result.activeIngredients.map((ing, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-black text-gray-900">{ing.name}</h4>
                  <span className="px-2 py-0.5 bg-blue-50 text-blue-600 text-[10px] font-black rounded uppercase">
                    {ing.strength}
                  </span>
                </div>
                <p className="text-xs text-gray-500 font-medium">{ing.purpose}</p>
              </div>
              <Activity className="w-5 h-5 text-gray-200" />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Warnings & Side Effects */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-red-50 border border-red-100 rounded-3xl p-6 space-y-4">
          <div className="flex items-center gap-3 text-red-600">
            <AlertTriangle className="w-6 h-6" />
            <h3 className="font-black uppercase tracking-widest text-sm">{t.warnings}</h3>
          </div>
          <ul className="space-y-2">
            {result.warnings.map((warning, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-red-800 font-medium">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-red-400 shrink-0" />
                {warning}
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-amber-50 border border-amber-100 rounded-3xl p-6 space-y-4">
          <div className="flex items-center gap-3 text-amber-600">
            <Ban className="w-6 h-6" />
            <h3 className="font-black uppercase tracking-widest text-sm">{t.sideEffects}</h3>
          </div>
          <ul className="space-y-2">
            {result.sideEffects.map((effect, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-amber-800 font-medium">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                {effect}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Interactions & Pregnancy */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-purple-50 border border-purple-100 rounded-3xl p-6 space-y-4">
          <div className="flex items-center gap-3 text-purple-600">
            <FlaskConical className="w-6 h-6" />
            <h3 className="font-black uppercase tracking-widest text-sm">{t.interactions}</h3>
          </div>
          <ul className="space-y-2">
            {result.interactions.map((interaction, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-purple-800 font-medium">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-purple-400 shrink-0" />
                {interaction}
              </li>
            ))}
          </ul>
        </div>

        {result.pregnancyCategory && (
          <div className="bg-pink-50 border border-pink-100 rounded-3xl p-6 space-y-4">
            <div className="flex items-center gap-3 text-pink-600">
              <Baby className="w-6 h-6" />
              <h3 className="font-black uppercase tracking-widest text-sm">{t.pregnancyCategory}</h3>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-xl font-black text-pink-600 shadow-sm">
                {result.pregnancyCategory}
              </div>
              <p className="text-sm text-pink-800 font-medium">
                {isBn ? `গর্ভাবস্থায় এই ঔষধটি '${result.pregnancyCategory}' ক্যাটাগরির অন্তর্ভুক্ত।` : `This medication is classified as Pregnancy Category '${result.pregnancyCategory}'.`}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Inactive Ingredients */}
      <div className="bg-gray-50 rounded-3xl p-6 space-y-4">
        <div className="flex items-center gap-3 text-gray-600">
          <ClipboardList className="w-6 h-6" />
          <h3 className="font-black uppercase tracking-widest text-sm">{t.inactiveIngredients}</h3>
        </div>
        <p className="text-xs text-gray-500 font-medium leading-relaxed">
          {result.inactiveIngredients.join(', ')}
        </p>
      </div>
    </div>
  );
}
