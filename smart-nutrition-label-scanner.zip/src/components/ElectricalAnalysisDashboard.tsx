import React from 'react';
import { ElectricalAnalysisResult, AppLanguage } from '../types';
import { motion } from 'motion/react';
import { ShieldCheck, AlertTriangle, CheckCircle2, Info, Zap, Activity, ArrowLeft, Cpu, Sparkles, Battery, Gauge, Settings, FileCheck, Recycle, Ban, Globe } from 'lucide-react';
import { cn } from '../lib/utils';
import { translations } from '../translations';

interface ElectricalAnalysisDashboardProps {
  result: ElectricalAnalysisResult;
  onBack: () => void;
  language: AppLanguage;
}

export default function ElectricalAnalysisDashboard({ result, onBack, language }: ElectricalAnalysisDashboardProps) {
  const t = translations[language];
  const isBn = language === 'bn';

  return (
    <div className="space-y-8 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button 
          onClick={onBack}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-gray-600" />
        </button>
        <div className="text-center flex-1 pr-10">
          <div className="flex items-center justify-center gap-2 mb-1">
            <h2 className="text-2xl font-black text-gray-900">{result.productName || (isBn ? 'বৈদ্যুতিক পণ্য বিশ্লেষণ' : 'Electrical Analysis')}</h2>
            {result.dataSource === 'ocr' ? (
              <div className="flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-black uppercase tracking-tighter">
                <ShieldCheck className="w-3 h-3" />
                {isBn ? 'যাচাইকৃত' : 'Verified'}
              </div>
            ) : (
              <div className="flex items-center gap-1 px-2 py-0.5 bg-blue-100 text-blue-700 rounded-lg text-[10px] font-black uppercase tracking-tighter">
                <Globe className="w-3 h-3" />
                {isBn ? 'ওয়েব সার্চ' : 'Web Search'}
              </div>
            )}
          </div>
          <p className="text-sm font-bold text-orange-600 uppercase tracking-widest">{result.brand} {result.modelNumber && `• ${result.modelNumber}`}</p>
        </div>
      </div>

      {/* Hero Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl text-center space-y-6"
        >
          <div className="relative inline-block">
            <svg className="w-40 h-40 transform -rotate-90">
              <circle
                cx="80"
                cy="80"
                r="70"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                className="text-gray-100"
              />
              <motion.circle
                cx="80"
                cy="80"
                r="70"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                strokeDasharray={440}
                initial={{ strokeDashoffset: 440 }}
                animate={{ strokeDashoffset: 440 - (440 * result.safetyScore) / 100 }}
                className={cn(
                  "transition-all duration-1000",
                  result.safetyScore >= 80 ? "text-emerald-500" : result.safetyScore >= 50 ? "text-orange-500" : "text-red-500"
                )}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-black text-gray-900">{result.safetyScore}</span>
              <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.safetyScore}</span>
            </div>
          </div>

          <div className="space-y-4">
            <div className={cn(
              "inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-sm",
              result.safetyScore >= 80 ? "bg-emerald-100 text-emerald-700 border border-emerald-200" :
              result.safetyScore >= 50 ? "bg-orange-100 text-orange-700 border border-orange-200" :
              "bg-red-100 text-red-700 border border-red-200"
            )}>
              {result.safetyScore >= 80 ? (isBn ? 'উচ্চ নিরাপত্তা' : 'High Safety') :
               result.safetyScore >= 50 ? (isBn ? 'মাঝারি নিরাপত্তা' : 'Moderate Safety') :
               (isBn ? 'নিম্ন নিরাপত্তা' : 'Low Safety')}
            </div>

            <div className="w-full max-w-[200px] mx-auto space-y-1">
              <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${result.safetyScore}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className={cn(
                    "h-full transition-all duration-500",
                    result.safetyScore >= 80 ? "bg-emerald-500" :
                    result.safetyScore >= 50 ? "bg-orange-500" :
                    "bg-red-500"
                  )}
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-black uppercase tracking-widest text-orange-600 bg-orange-50">
              <Zap className="w-4 h-4" />
              {result.energyEfficiency || (isBn ? 'শক্তি দক্ষতা' : 'Energy Efficiency')}
            </div>
            <p className="text-gray-600 font-medium leading-relaxed">
              {result.simpleExplanation}
            </p>
          </div>
        </motion.div>

        <div className="space-y-6">
          {/* Specifications */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-orange-50 p-6 rounded-3xl border border-orange-100 space-y-4"
          >
            <div className="flex items-center gap-2 text-orange-600">
              <Gauge className="w-5 h-5" />
              <h3 className="font-black uppercase tracking-widest text-xs">{t.specifications}</h3>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {result.specifications.voltage && (
                <div className="bg-white p-3 rounded-xl shadow-sm">
                  <p className="text-[10px] font-black text-gray-400 uppercase">{t.voltage}</p>
                  <p className="text-sm font-black text-gray-900">{result.specifications.voltage}</p>
                </div>
              )}
              {result.specifications.power && (
                <div className="bg-white p-3 rounded-xl shadow-sm">
                  <p className="text-[10px] font-black text-gray-400 uppercase">{t.power}</p>
                  <p className="text-sm font-black text-gray-900">{result.specifications.power}</p>
                </div>
              )}
              {result.specifications.current && (
                <div className="bg-white p-3 rounded-xl shadow-sm">
                  <p className="text-[10px] font-black text-gray-400 uppercase">{t.current}</p>
                  <p className="text-sm font-black text-gray-900">{result.specifications.current}</p>
                </div>
              )}
              {result.specifications.frequency && (
                <div className="bg-white p-3 rounded-xl shadow-sm">
                  <p className="text-[10px] font-black text-gray-400 uppercase">{t.frequency}</p>
                  <p className="text-sm font-black text-gray-900">{result.specifications.frequency}</p>
                </div>
              )}
            </div>
          </motion.div>

          {/* Certifications */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100 space-y-3"
          >
            <div className="flex items-center gap-2 text-emerald-600">
              <FileCheck className="w-5 h-5" />
              <h3 className="font-black uppercase tracking-widest text-xs">{t.certifications}</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {result.certifications.map((cert, idx) => (
                <span key={idx} className="px-3 py-1 bg-white text-emerald-700 text-xs font-bold rounded-full shadow-sm">
                  {cert}
                </span>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Materials & Components */}
      <div className="space-y-4">
        <div className="flex items-center gap-3 px-2">
          <Settings className="w-6 h-6 text-orange-600" />
          <h3 className="text-lg font-black text-gray-900">{t.materials}</h3>
        </div>
        <div className="grid gap-4">
          {result.materials.map((mat, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <h4 className="font-black text-gray-900">{mat.name}</h4>
                <p className="text-xs text-gray-500 font-medium">{mat.purpose}</p>
                {mat.safetyNote && (
                  <p className="text-[10px] text-orange-600 font-bold italic">Note: {mat.safetyNote}</p>
                )}
              </div>
              <Cpu className="w-5 h-5 text-gray-200" />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Safety Features & Warnings */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-emerald-50 border border-emerald-100 rounded-3xl p-6 space-y-4">
          <div className="flex items-center gap-3 text-emerald-600">
            <ShieldCheck className="w-6 h-6" />
            <h3 className="font-black uppercase tracking-widest text-sm">{t.safetyFeatures}</h3>
          </div>
          <ul className="space-y-2">
            {result.safetyFeatures.map((feature, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-emerald-800 font-medium">
                <CheckCircle2 className="w-4 h-4 mt-0.5 text-emerald-500 shrink-0" />
                {feature}
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-red-50 border border-red-100 rounded-3xl p-6 space-y-4">
          <div className="flex items-center gap-3 text-red-600">
            <AlertTriangle className="w-6 h-6" />
            <h3 className="font-black uppercase tracking-widest text-sm">{t.hazardWarnings}</h3>
          </div>
          <ul className="space-y-2">
            {result.hazardWarnings.map((warning, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-red-800 font-medium">
                <Ban className="w-4 h-4 mt-0.5 text-red-500 shrink-0" />
                {warning}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Usage Instructions */}
      <div className="bg-blue-50 border border-blue-100 rounded-3xl p-6 space-y-4">
        <div className="flex items-center gap-3 text-blue-600">
          <Info className="w-6 h-6" />
          <h3 className="font-black uppercase tracking-widest text-sm">{t.usageInstructions}</h3>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {result.usageInstructions.map((inst, idx) => (
            <div key={idx} className="flex items-start gap-3 p-3 bg-white rounded-xl shadow-sm">
              <div className="w-6 h-6 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 text-xs font-black shrink-0">
                {idx + 1}
              </div>
              <p className="text-sm text-gray-700 font-medium">{inst}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Environmental Impact */}
      <div className="bg-emerald-900 text-white rounded-3xl p-8 space-y-4 shadow-xl">
        <div className="flex items-center gap-3">
          <Recycle className="w-8 h-8 text-emerald-400" />
          <h3 className="text-xl font-black">{isBn ? 'পরিবেশগত প্রভাব' : 'Environmental Impact'}</h3>
        </div>
        <p className="text-emerald-50 font-medium leading-relaxed">
          {result.environmentalImpact}
        </p>
      </div>
    </div>
  );
}
