import React, { useState, useEffect, useCallback } from 'react';
import { UserProfile, AnalysisResult, OcrResult, OcrNutrients, DataSource, ProductAnalysisResult, PharmaAnalysisResult, ElectricalAnalysisResult } from './types';
import ImageUploader from './components/ImageUploader';
import AnalysisDashboard from './components/AnalysisDashboard';
import ProductAnalysisDashboard from './components/ProductAnalysisDashboard';
import PharmaAnalysisDashboard from './components/PharmaAnalysisDashboard';
import ElectricalAnalysisDashboard from './components/ElectricalAnalysisDashboard';
import VerificationStep from './components/VerificationStep';
import QualityCheckStep from './components/QualityCheckStep';
import ManualInputStep from './components/ManualInputStep';
import ScanHistory from './components/ScanHistory';
import ComparisonView from './components/ComparisonView';
import { analyzeNutritionLabel, performOcr, analyzeProductIngredients, analyzePharmaIngredients, analyzeElectricalIngredients, identifyProductByImage } from './lib/gemini';
import { auth, db, googleProvider, signInWithPopup, onAuthStateChanged, User, doc, setDoc, getDoc, addDoc, Timestamp, handleFirestoreError, OperationType, collection, getDocs, deleteDoc, query, where, onSnapshot, updateDoc, orderBy, signInAnonymously } from './lib/firebase';
import { Scan, Info, ShieldCheck, RefreshCcw, Keyboard, LogIn, LogOut, User as UserIcon, History, Wifi, WifiOff, CloudOff, Loader2, AlertCircle, ArrowRight, Globe, FlaskConical, Utensils, Pill, Zap, Sparkles, Share2, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { translations } from './translations';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { cn } from './lib/utils';

type AppStep = 'input' | 'quality-check' | 'verification' | 'manual-input' | 'analysis' | 'history' | 'comparison' | 'product-analysis' | 'pharma-analysis' | 'electrical-analysis';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [showShareToast, setShowShareToast] = useState(false);
  const [profile, setProfile] = useState<UserProfile>({
    language: 'bn',
    mode: 'general',
  });

  const t = translations[profile.language];

  const handleShare = async () => {
    // Determine the best share URL. 
    // If we are already on ais-pre, use current location.
    // Otherwise, use the known preview URL.
    const currentUrl = window.location.href;
    const shareUrl = currentUrl.includes('ais-pre') 
      ? currentUrl.split('?')[0].split('#')[0]
      : 'https://ais-pre-nl7ulhwzxvcawskqu7ojtg-106067889081.asia-east1.run.app';

    console.log('Sharing URL:', shareUrl);

    try {
      if (navigator.share && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) {
        await navigator.share({
          title: 'NutriScan - Smart Nutrition Label Scanner',
          text: 'Analyze food labels using AI to understand nutritional value and detect hidden ingredients.',
          url: shareUrl,
        });
        return;
      }
      
      await navigator.clipboard.writeText(shareUrl);
      setShowShareToast(true);
      setTimeout(() => setShowShareToast(false), 3000);
    } catch (error) {
      console.error('Share failed:', error);
      window.prompt("Copy this link to share the app (opens directly in preview):", shareUrl);
    }
  };

  const trackEvent = (eventName: string, params?: any) => {
    console.log(`[Analytics] ${eventName}`, params);
    // Placeholder for real analytics like Firebase Analytics or Mixpanel
  };

  const [step, setStep] = useState<AppStep>('input');
  const [productType, setProductType] = useState<'food' | 'non-food' | 'pharma' | 'electrical'>('food');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [ocrResult, setOcrResult] = useState<OcrResult | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [productResult, setProductResult] = useState<ProductAnalysisResult | null>(null);
  const [pharmaResult, setPharmaResult] = useState<PharmaAnalysisResult | null>(null);
  const [electricalResult, setElectricalResult] = useState<ElectricalAnalysisResult | null>(null);
  const [comparisonResults, setComparisonResults] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [currentImage, setCurrentImage] = useState<string | null>(null);
  const [history, setHistory] = useState<any[]>([]);

  const isOnline = useOnlineStatus();
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState({ current: 0, total: 0 });
  const [scanCache, setScanCache] = useState<Record<string, { ocr?: OcrResult, analysis?: AnalysisResult, productAnalysis?: ProductAnalysisResult, pharmaAnalysis?: PharmaAnalysisResult, electricalAnalysis?: ElectricalAnalysisResult }>>({});
  const [pendingCount, setPendingCount] = useState(0);
  const [syncErrors, setSyncErrors] = useState<{id: string, error: string, type: string}[]>([]);
  const [showSyncErrorDetails, setShowSyncErrorDetails] = useState(false);
  const [expandedErrorId, setExpandedErrorId] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'pending_scans'), where('uid', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setPendingCount(snapshot.size);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'pending_scans');
    });
    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (isOnline && user) {
      syncPendingScans();
    }
  }, [isOnline, user]);

  const syncPendingScans = async () => {
    if (!user) return;
    setIsSyncing(true);
    setSyncErrors([]);
    setSyncProgress({ current: 0, total: 0 });
    const successfulIds: string[] = [];
    try {
      // Prioritize by timestamp (oldest first - FIFO)
      const q = query(
        collection(db, 'pending_scans'), 
        where('uid', '==', user.uid),
        orderBy('timestamp', 'asc')
      );
      const snapshot = await getDocs(q);
      setSyncProgress({ current: 0, total: snapshot.size });
      
      // Prioritize 'image' scans, then 'barcode' and 'manual'
      // Maintain FIFO (timestamp) within each type (query already ordered by timestamp)
      const sortedDocs = [...snapshot.docs].sort((a, b) => {
        const typeA = a.data().type;
        const typeB = b.data().type;
        
        if (typeA === 'image' && typeB !== 'image') return -1;
        if (typeA !== 'image' && typeB === 'image') return 1;
        
        // Same priority: maintain query order (FIFO)
        return 0;
      });

      const MAX_RETRIES = 3;

      let count = 0;
      for (const docSnap of sortedDocs) {
        count++;
        setSyncProgress(prev => ({ ...prev, current: count }));
        const data = docSnap.data();
        const currentRetryCount = data.retryCount || 0;

        if (currentRetryCount >= MAX_RETRIES) {
          console.warn(`Scan ${docSnap.id} reached max retries. Skipping.`);
          continue;
        }

        try {
          let analysis: AnalysisResult;
          if (data.type === 'image') {
            analysis = await analyzeNutritionLabel(data.imageBase64, profile, undefined, undefined, 'ocr');
          } else {
            analysis = await analyzeNutritionLabel('', profile, data.nutrients, data.ingredients, 'user-input');
          }
          await saveScanToHistory(analysis);
          // Success! We'll delete these in a batch after the loop
          successfulIds.push(docSnap.id);
        } catch (err) {
          const errorMessage = err instanceof Error ? err.message : "Unknown error during sync";
          console.error(`Failed to sync scan ${docSnap.id}:`, err);
          
          // Granular error reporting
          setSyncErrors(prev => [...prev, { id: docSnap.id, error: errorMessage, type: data.type }]);

          // Retry logic: increment retry count
          await updateDoc(doc(db, 'pending_scans', docSnap.id), {
            retryCount: currentRetryCount + 1,
            lastError: errorMessage
          });
        }
      }

      // After a successful sync loop, remove successfully processed items from Firestore
      if (successfulIds.length > 0) {
        const { writeBatch } = await import('firebase/firestore');
        const batch = writeBatch(db);
        successfulIds.forEach(id => {
          batch.delete(doc(db, 'pending_scans', id));
        });
        await batch.commit();
        console.log(`Successfully synced and removed ${successfulIds.length} items.`);
      }
    } catch (err) {
      console.error("Sync batch failed:", err);
    } finally {
      setIsSyncing(false);
    }
  };
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        try {
          await signInAnonymously(auth);
        } catch (error) {
          console.error("Anonymous sign-in failed:", error);
          setIsAuthReady(true);
        }
        return;
      }
      
      setUser(user);
      try {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (userDoc.exists()) {
          setProfile(userDoc.data() as UserProfile);
        } else {
          // Initialize profile in Firestore
          const initialProfile = { ...profile, uid: user.uid, updatedAt: Timestamp.now() };
          await setDoc(doc(db, 'users', user.uid), initialProfile);
        }

        // Fetch history for trends
        const q = query(
          collection(db, 'scans'),
          where('uid', '==', user.uid),
          orderBy('timestamp', 'desc')
        );
        onSnapshot(q, (snapshot) => {
          const results = snapshot.docs.map(doc => {
            const data = doc.data();
            const ts = data.timestamp;
            const timestamp = ts?.toDate ? ts.toDate() : (ts ? new Date(ts) : new Date());
            return {
              ...data,
              timestamp
            };
          }) as AnalysisResult[];
          setHistory(results);
        }, (error) => {
          // Don't throw here to avoid breaking the UI, just log it
          console.warn('History fetch failed:', error);
        });

      } catch (error) {
        console.warn('Profile fetch failed:', error);
      }
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  const saveScanToFirestore = async (analysis: any, type: 'food' | 'non-food' | 'pharma' | 'electrical') => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'scans'), {
        ...analysis,
        type,
        uid: user.uid,
        timestamp: Timestamp.now()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'scans');
      throw error;
    }
  };

  const saveScanToHistory = (analysis: AnalysisResult) => saveScanToFirestore(analysis, 'food');
  const saveProductScanToHistory = (analysis: ProductAnalysisResult) => saveScanToFirestore(analysis, 'non-food');
  const savePharmaScanToHistory = (analysis: PharmaAnalysisResult) => saveScanToFirestore(analysis, 'pharma');
  const saveElectricalScanToHistory = (analysis: ElectricalAnalysisResult) => saveScanToFirestore(analysis, 'electrical');

  const handleLanguageChange = async (newProfile: UserProfile) => {
    setProfile(newProfile);
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.uid), {
          ...newProfile,
          uid: user.uid,
          updatedAt: Timestamp.now()
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
      }
    }
  };

  const handleImageSelect = async (base64: string) => {
    setCurrentImage(base64);
    if (!isOnline) {
      if (user) {
        await addDoc(collection(db, 'pending_scans'), {
          uid: user.uid,
          type: 'image',
          imageBase64: base64,
          timestamp: Timestamp.now(),
          retryCount: 0
        });
        setError("You are offline. Image saved and will be analyzed when you are back online.");
      } else {
        setError("You are offline. Please connect to the internet to analyze images.");
      }
      return;
    }
    setIsAnalyzing(true);
    setError(null);
    try {
      const cacheKey = `${base64}_${profile.language}_${profile.mode}_${productType}`;
      // Check cache first
      if (scanCache[cacheKey]) {
        const cached = scanCache[cacheKey];
        if (productType === 'food') {
          setOcrResult(cached.ocr!);
          setResult(cached.analysis!);
          setStep('analysis');
        } else if (productType === 'non-food') {
          setProductResult(cached.productAnalysis!);
          setStep('product-analysis');
        } else if (productType === 'pharma') {
          setPharmaResult(cached.pharmaAnalysis!);
          setStep('pharma-analysis');
        } else {
          setElectricalResult(cached.electricalAnalysis!);
          setStep('electrical-analysis');
        }
        setIsAnalyzing(false);
        return;
      }

      // Step 1: Identify the product (Smart Scan Integration)
      const identification = await identifyProductByImage(base64, profile);
      const identifiedName = identification.productName;
      const identifiedType = identification.productType;
      
      const finalType = identifiedType || productType;

      if (finalType === 'food') {
        const ocr = await performOcr(base64);
        setOcrResult(ocr);
        
        const analysis = await analyzeNutritionLabel(
          base64, 
          profile, 
          ocr.nutrients, 
          ocr.ingredients, 
          'ocr', 
          identifiedName
        );
        setResult(analysis);
        setStep('analysis');
        trackEvent('scan_success', { type: 'image', category: 'food', method: 'smart_scan' });
        
        setScanCache(prev => ({
          ...prev,
          [cacheKey]: { ocr, analysis }
        }));

        await saveScanToHistory(analysis);
      } else if (finalType === 'non-food') {
        const analysis = await analyzeProductIngredients(base64, profile, 'ocr', identifiedName);
        setProductResult(analysis);
        setStep('product-analysis');
        trackEvent('scan_success', { type: 'image', category: 'non-food', method: 'smart_scan' });
        
        setScanCache(prev => ({
          ...prev,
          [cacheKey]: { productAnalysis: analysis }
        }));

        await saveProductScanToHistory(analysis);
      } else if (finalType === 'pharma') {
        const analysis = await analyzePharmaIngredients(base64, profile, 'ocr', identifiedName);
        setPharmaResult(analysis);
        setStep('pharma-analysis');
        trackEvent('scan_success', { type: 'image', category: 'pharma', method: 'smart_scan' });
        
        setScanCache(prev => ({
          ...prev,
          [cacheKey]: { pharmaAnalysis: analysis }
        }));

        await savePharmaScanToHistory(analysis);
      } else {
        const analysis = await analyzeElectricalIngredients(base64, profile, 'ocr', identifiedName);
        setElectricalResult(analysis);
        setStep('electrical-analysis');
        trackEvent('scan_success', { type: 'image', category: 'electrical', method: 'smart_scan' });
        
        setScanCache(prev => ({
          ...prev,
          [cacheKey]: { electricalAnalysis: analysis }
        }));

        await saveElectricalScanToHistory(analysis);
      }
    } catch (err) {
      console.error(err);
      setError(profile.language === 'bn' ? "বিশ্লেষণ ব্যর্থ হয়েছে। আবার চেষ্টা করুন।" : "Analysis failed. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleVerifiedAnalysis = async (nutrients: OcrNutrients, ingredients: string[]) => {
    setIsAnalyzing(true);
    setError(null);
    try {
      if (!isOnline) {
        if (user) {
          await addDoc(collection(db, 'pending_scans'), {
            uid: user.uid,
            type: 'manual',
            nutrients,
            ingredients,
            timestamp: Timestamp.now(),
            retryCount: 0
          });
          setError("You are offline. Data saved and will be analyzed when you are back online.");
          setStep('input');
        } else {
          setError("You are offline. Please connect to the internet to analyze data.");
        }
        return;
      }
      const analysis = await analyzeNutritionLabel(currentImage || '', profile, nutrients, ingredients, 'user-input');
      setResult(analysis);
      setStep('analysis');
      trackEvent('scan_success', { type: 'manual' });
      await saveScanToHistory(analysis);
    } catch (err) {
      console.error(err);
      setError("Analysis failed. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const [showCategories, setShowCategories] = useState(false);

  const reset = useCallback(() => {
    setResult(null);
    setProductResult(null);
    setPharmaResult(null);
    setElectricalResult(null);
    setOcrResult(null);
    setCurrentImage(null);
    setStep('input');
    setError(null);
  }, []);

  if (!isAuthReady) return <div className="min-h-screen flex items-center justify-center bg-white">
    <div className="w-12 h-12 border-4 border-emerald-100 border-t-emerald-600 rounded-full animate-spin" />
  </div>;

  return (
    <div className="min-h-screen bg-[#fcfdfc] text-gray-900 font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-emerald-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div 
            className="flex items-center gap-3 group cursor-pointer" 
            onClick={reset}
            role="button"
            tabIndex={0}
            aria-label="NutriScan Home"
            onKeyDown={(e) => e.key === 'Enter' && reset()}
          >
            <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-200 group-hover:rotate-12 transition-transform duration-300">
              <Scan className="w-7 h-7 text-white" />
            </div>
            <div className="flex flex-col leading-tight">
              <h1 className="text-xl font-black tracking-tight text-gray-900">{t.appName}</h1>
              <span className="text-xs font-bold text-emerald-600 uppercase tracking-widest">Bangladeshi Nutrition & Food Safety Expert</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-50 border border-gray-100 rounded-lg">
              <Globe className="w-3 h-3 text-gray-400" />
              <select
                value={profile.language}
                onChange={(e) => handleLanguageChange({ ...profile, language: e.target.value as any })}
                className="bg-transparent text-[10px] font-black uppercase tracking-widest outline-none cursor-pointer"
                aria-label="Select Language"
              >
                <option value="bn">BN</option>
                <option value="en">EN</option>
                <option value="hi">HI</option>
                <option value="zh">ZH</option>
                <option value="es">ES</option>
                <option value="ar">AR</option>
              </select>
            </div>
            {pendingCount > 0 && (
              <div 
                className="flex items-center gap-2 px-3 py-1.5 bg-orange-50 text-orange-600 rounded-lg text-xs font-bold"
                role="status"
                aria-live="polite"
              >
                <CloudOff className="w-3 h-3" />
                {pendingCount} Pending
              </div>
            )}
            {isSyncing && (
              <div 
                className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-xs font-bold"
                role="status"
                aria-live="polite"
              >
                <Loader2 className="w-3 h-3 animate-spin" />
                Syncing {syncProgress.current}/{syncProgress.total}...
              </div>
            )}
            <div 
              className={cn(
                "flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all",
                isOnline ? "bg-emerald-50 text-emerald-600" : "bg-red-50 text-red-600"
              )}
              role="status"
              aria-live="polite"
            >
              {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
              {isOnline ? "Online" : "Offline"}
            </div>
            
            <button 
              onClick={handleShare}
              className={cn(
                "p-2 rounded-xl transition-all flex items-center gap-2",
                showShareToast ? "bg-blue-600 text-white" : "text-gray-500 hover:text-blue-600 hover:bg-blue-50"
              )}
              aria-label="Share App"
            >
              {showShareToast ? <Check className="w-6 h-6" /> : <Share2 className="w-6 h-6" />}
              {showShareToast && <span className="text-xs font-bold pr-1">Copied!</span>}
            </button>

            <button 
              onClick={() => setStep('history')}
              className="p-2 text-gray-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-all"
              aria-label="View Scan History"
            >
              <History className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        {syncErrors.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="bg-red-50 border border-red-100 rounded-2xl p-4 flex flex-col gap-3"
          >
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div className="space-y-1 flex-1">
                <p className="text-sm font-black text-red-900 uppercase tracking-widest">Sync Issues Detected</p>
                <p className="text-xs text-red-700 font-medium">
                  {syncErrors.length} item(s) failed to sync. We'll try again automatically.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setShowSyncErrorDetails(!showSyncErrorDetails)}
                  className="text-[10px] font-black text-red-600 uppercase tracking-widest hover:underline"
                  aria-expanded={showSyncErrorDetails}
                  aria-controls="sync-error-details"
                >
                  {showSyncErrorDetails ? 'Hide Details' : 'View Details'}
                </button>
                <button 
                  onClick={() => {
                    setSyncErrors([]);
                    setExpandedErrorId(null);
                  }}
                  className="text-[10px] font-black text-red-600 uppercase tracking-widest hover:underline"
                  aria-label="Clear All Sync Errors"
                >
                  Clear All Errors
                </button>
              </div>
            </div>
            
            {showSyncErrorDetails && (
              <div id="sync-error-details" className="mt-2 space-y-2 max-h-60 overflow-y-auto pr-2" role="region" aria-label="Sync Error Details">
                {syncErrors.map((err, idx) => (
                  <div 
                    key={idx} 
                    onClick={() => setExpandedErrorId(expandedErrorId === err.id ? null : err.id)}
                    className={cn(
                      "p-3 rounded-xl border transition-all cursor-pointer",
                      expandedErrorId === err.id 
                        ? "bg-white border-red-200 shadow-sm" 
                        : "bg-white/50 border-red-100 hover:bg-white/80"
                    )}
                    role="button"
                    tabIndex={0}
                    aria-expanded={expandedErrorId === err.id}
                    onKeyDown={(e) => e.key === 'Enter' && setExpandedErrorId(expandedErrorId === err.id ? null : err.id)}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded text-[9px] font-black uppercase tracking-wider">
                          {err.type}
                        </span>
                        <span className="text-[10px] font-mono text-red-900 font-bold truncate max-w-[150px]">
                          ID: {err.id}
                        </span>
                      </div>
                      <ArrowRight className={cn(
                        "w-3 h-3 text-red-400 transition-transform",
                        expandedErrorId === err.id ? "rotate-90" : ""
                      )} />
                    </div>
                    
                    {expandedErrorId === err.id && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="mt-2 pt-2 border-t border-red-50"
                      >
                        <p className="text-[11px] font-medium text-red-800 leading-relaxed">
                          {err.error}
                        </p>
                      </motion.div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {step === 'input' && (
          <section className="text-center space-y-6 max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-full text-sm font-bold border border-emerald-100 shadow-sm"
            >
              <ShieldCheck className="w-4 h-4" />
              Bangladeshi Nutrition & Food Safety Expert
            </motion.div>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-5xl md:text-6xl font-black tracking-tight text-gray-900 leading-[1.1]"
              dangerouslySetInnerHTML={{ __html: t.heroTitle }}
            />
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl text-gray-700 leading-relaxed font-medium"
            >
              {t.heroDesc}
            </motion.p>

            <div className="py-8 flex flex-col items-center gap-6">
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-center"
              >
                <h3 className="text-2xl font-black text-gray-900 tracking-tight">
                  {t.scanPrompt}
                </h3>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.25, type: 'spring' }}
                className="flex flex-col items-center gap-8 w-full"
              >
                <div 
                  className="relative group cursor-pointer"
                  onClick={() => {
                    setShowCategories(true);
                    setTimeout(() => {
                      const el = document.getElementById('category-grid');
                      if (el) {
                        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        el.classList.add('animate-pulse');
                        setTimeout(() => el.classList.remove('animate-pulse'), 1000);
                      }
                    }, 100);
                  }}
                >
                  {/* 3D Animated Model */}
                  <div className="w-24 h-24 relative perspective-1000">
                    <motion.div
                      animate={{ 
                        rotateY: [0, 360],
                        rotateX: [15, 25, 15],
                        y: [0, -10, 0]
                      }}
                      transition={{ 
                        rotateY: { duration: 10, repeat: Infinity, ease: "linear" },
                        rotateX: { duration: 4, repeat: Infinity, ease: "easeInOut" },
                        y: { duration: 3, repeat: Infinity, ease: "easeInOut" }
                      }}
                      style={{ transformStyle: 'preserve-3d' }}
                      className="w-full h-full"
                    >
                      <div className="absolute inset-0 bg-emerald-500/90 rounded-2xl flex items-center justify-center border-2 border-white/50 shadow-xl" style={{ transform: 'translateZ(48px)' }}>
                        <Utensils className="w-10 h-10 text-white" />
                      </div>
                      <div className="absolute inset-0 bg-blue-500/90 rounded-2xl flex items-center justify-center border-2 border-white/50 shadow-xl" style={{ transform: 'rotateY(90deg) translateZ(48px)' }}>
                        <FlaskConical className="w-10 h-10 text-white" />
                      </div>
                      <div className="absolute inset-0 bg-purple-500/90 rounded-2xl flex items-center justify-center border-2 border-white/50 shadow-xl" style={{ transform: 'rotateY(180deg) translateZ(48px)' }}>
                        <Pill className="w-10 h-10 text-white" />
                      </div>
                      <div className="absolute inset-0 bg-orange-500/90 rounded-2xl flex items-center justify-center border-2 border-white/50 shadow-xl" style={{ transform: 'rotateY(-90deg) translateZ(48px)' }}>
                        <Zap className="w-10 h-10 text-white" />
                      </div>
                      <div className="absolute inset-0 bg-gray-800/90 rounded-2xl flex items-center justify-center border-2 border-white/50 shadow-xl" style={{ transform: 'rotateX(90deg) translateZ(48px)' }}>
                        <Scan className="w-10 h-10 text-white" />
                      </div>
                      <div className="absolute inset-0 bg-gray-800/90 rounded-2xl flex items-center justify-center border-2 border-white/50 shadow-xl" style={{ transform: 'rotateX(-90deg) translateZ(48px)' }}>
                        <Sparkles className="w-10 h-10 text-white" />
                      </div>
                    </motion.div>
                    <div className="absolute inset-0 bg-emerald-400/20 blur-3xl rounded-full -z-10 animate-pulse" />
                  </div>
                </div>

                {/* Primary Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md px-4">
                  <button
                    onClick={() => setShowCategories(true)}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-4 rounded-2xl font-black flex items-center justify-center gap-3 shadow-lg shadow-emerald-200 transition-all active:scale-95 group"
                  >
                    <Scan className="w-6 h-6 group-hover:rotate-12 transition-transform" />
                    {t.scanLabel}
                  </button>
                </div>

                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  className="text-center"
                >
                  <p className="text-sm font-black text-emerald-600 uppercase tracking-[0.2em]">
                    {showCategories ? t.selectCategory : t.selectCategory}
                  </p>
                </motion.div>
              </motion.div>

              <AnimatePresence>
                {showCategories && (
                  <motion.div
                    id="category-grid"
                    initial={{ opacity: 0, height: 0, scale: 0.9 }}
                    animate={{ opacity: 1, height: 'auto', scale: 1 }}
                    exit={{ opacity: 0, height: 0, scale: 0.9 }}
                    transition={{ type: 'spring', damping: 20, stiffness: 100 }}
                    className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-4xl overflow-hidden"
                  >
                    {[
                      { id: 'food', icon: Utensils, color: 'emerald', label: t.foodProduct },
                      { id: 'non-food', icon: FlaskConical, color: 'blue', label: t.nonFoodProduct },
                      { id: 'pharma', icon: Pill, color: 'purple', label: t.pharmaProduct },
                      { id: 'electrical', icon: Zap, color: 'orange', label: t.electricalProduct }
                    ].map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setProductType(cat.id as any)}
                        className={cn(
                          "relative group overflow-hidden p-6 rounded-3xl border-2 transition-all duration-500 flex flex-col items-center gap-4",
                          productType === cat.id 
                            ? `border-${cat.color}-500 bg-${cat.color}-50/50 shadow-lg shadow-${cat.color}-100` 
                            : "border-gray-100 bg-white hover:border-gray-200 hover:shadow-md"
                        )}
                      >
                        <div className={cn(
                          "w-16 h-16 rounded-2xl flex items-center justify-center transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6",
                          productType === cat.id ? `bg-${cat.color}-500 text-white` : `bg-${cat.color}-50 text-${cat.color}-500`
                        )}>
                          <cat.icon className="w-8 h-8" />
                        </div>
                        <span className={cn(
                          "text-sm font-black text-center leading-tight",
                          productType === cat.id ? `text-${cat.color}-700` : "text-gray-600"
                        )}>
                          {cat.label}
                        </span>
                        {productType === cat.id && (
                          <motion.div 
                            layoutId="active-indicator"
                            className={`absolute top-2 right-2 w-2 h-2 rounded-full bg-${cat.color}-500`}
                          />
                        )}
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4"
            >
              <button 
                onClick={() => document.getElementById('uploader-section')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-lg font-black shadow-xl shadow-emerald-200 transition-all hover:scale-105 active:scale-95 flex items-center gap-3"
                aria-label="Start Analysis by Uploading Image"
              >
                <Scan className="w-6 h-6" />
                {profile.language === 'bn' ? 'বিশ্লেষণ শুরু করুন' : 'Start Analysis'}
              </button>
              <button 
                onClick={() => setStep('manual-input')}
                className="px-8 py-4 bg-white border border-gray-200 text-gray-600 rounded-2xl text-lg font-black transition-all hover:bg-gray-50 flex items-center gap-3"
                aria-label="Enter Nutrition Data Manually"
              >
                <Keyboard className="w-6 h-6" />
                {t.manualEntry}
              </button>
            </motion.div>
          </section>
        )}

        <div className="grid grid-cols-1 gap-12 items-start">
          {/* Main Interaction Area */}
          <div className="w-full">
            <AnimatePresence mode="wait">
              {step === 'input' && (
                <motion.div
                  key="input-section"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="space-y-12"
                >
                  <div id="uploader-section" className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm space-y-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600">
                        <Scan className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">{t.step1}</h3>
                        <p className="text-sm text-gray-500">{t.step1Desc}</p>
                      </div>
                    </div>
                    <ImageUploader 
                      onImageSelect={handleImageSelect} 
                      isAnalyzing={isAnalyzing} 
                      language={profile.language} 
                      productType={productType}
                    />
                  </div>
                </motion.div>
              )}

              {step === 'history' && user && (
                <motion.div
                  key="history-section"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.05 }}
                >
                  <ScanHistory 
                    uid={user.uid} 
                    language={profile.language} 
                    onSelect={(res) => {
                      if (res.type === 'non-food') {
                        setProductResult(res);
                        setStep('product-analysis');
                      } else if (res.type === 'pharma') {
                        setPharmaResult(res);
                        setStep('pharma-analysis');
                      } else if (res.type === 'electrical') {
                        setElectricalResult(res);
                        setStep('electrical-analysis');
                      } else {
                        setResult(res);
                        setStep('analysis');
                      }
                    }} 
                    onCompare={(results) => {
                      // Comparison is currently only for food products
                      setComparisonResults(results);
                      setStep('comparison');
                    }}
                  />
                  <div className="mt-8 flex justify-center">
                    <button 
                      onClick={reset}
                      className="px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-2xl text-sm font-black uppercase tracking-widest transition-all"
                    >
                      Back to Scanner
                    </button>
                  </div>
                </motion.div>
              )}

              {step === 'comparison' && (
                <motion.div
                  key="comparison-section"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.05 }}
                >
                  <ComparisonView 
                    results={comparisonResults}
                    language={profile.language}
                    onBack={() => setStep('history')}
                  />
                </motion.div>
              )}

              {step === 'quality-check' && ocrResult && (
                <motion.div
                  key="quality-check"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.05 }}
                >
                  <QualityCheckStep 
                    ocrResult={ocrResult} 
                    language={profile.language} 
                    onRetake={reset} 
                    onManualInput={() => setStep('manual-input')} 
                  />
                </motion.div>
              )}

              {step === 'verification' && ocrResult && (
                <motion.div
                  key="verification"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.05 }}
                >
                  <VerificationStep 
                    ocrResult={ocrResult} 
                    language={profile.language} 
                    onConfirm={handleVerifiedAnalysis} 
                    onRetake={reset} 
                  />
                </motion.div>
              )}

              {step === 'manual-input' && (
                <motion.div
                  key="manual-input"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.05 }}
                >
                  <ManualInputStep 
                    language={profile.language} 
                    onConfirm={handleVerifiedAnalysis} 
                    onBack={reset} 
                    initialNutrients={ocrResult?.nutrients}
                    initialIngredients={ocrResult?.ingredients}
                  />
                </motion.div>
              )}

              {step === 'analysis' && result && (
                <motion.div
                  key="output-section"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white">
                        <ShieldCheck className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900">{t.analysisComplete}</h3>
                        <p className="text-xs text-gray-500">Bangladeshi Nutrition Expert Analysis</p>
                      </div>
                    </div>
                    <button 
                      onClick={reset}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-bold transition-colors flex items-center gap-2"
                      aria-label="Scan Another Product"
                    >
                      <Scan className="w-4 h-4" />
                      {t.scanAnother}
                    </button>
                  </div>

                  <AnalysisDashboard 
                    result={result} 
                    language={profile.language} 
                    onManualInput={() => setStep('manual-input')}
                    history={history}
                  />
                </motion.div>
              )}

              {step === 'product-analysis' && productResult && (
                <motion.div
                  key="product-output-section"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white">
                        <FlaskConical className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900">{t.analysisComplete}</h3>
                        <p className="text-xs text-gray-500">Product Safety Expert Analysis</p>
                      </div>
                    </div>
                    <button 
                      onClick={reset}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-bold transition-colors flex items-center gap-2"
                    >
                      <Scan className="w-4 h-4" />
                      {t.scanAnother}
                    </button>
                  </div>

                  <ProductAnalysisDashboard 
                    result={productResult} 
                    onBack={reset} 
                    language={profile.language}
                  />
                </motion.div>
              )}

              {step === 'pharma-analysis' && pharmaResult && (
                <motion.div
                  key="pharma-output-section"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center text-white">
                        <Pill className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900">{t.analysisComplete}</h3>
                        <p className="text-xs text-gray-500">Pharmaceutical Expert Analysis</p>
                      </div>
                    </div>
                    <button 
                      onClick={reset}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-bold transition-colors flex items-center gap-2"
                    >
                      <Scan className="w-4 h-4" />
                      {t.scanAnother}
                    </button>
                  </div>

                  <PharmaAnalysisDashboard 
                    result={pharmaResult} 
                    onBack={reset} 
                    language={profile.language}
                  />
                </motion.div>
              )}

              {step === 'electrical-analysis' && electricalResult && (
                <motion.div
                  key="electrical-output-section"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center text-white">
                        <Zap className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900">{t.analysisComplete}</h3>
                        <p className="text-xs text-gray-500">Electrical Safety Expert Analysis</p>
                      </div>
                    </div>
                    <button 
                      onClick={reset}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-bold transition-colors flex items-center gap-2"
                    >
                      <Scan className="w-4 h-4" />
                      {t.scanAnother}
                    </button>
                  </div>

                  <ElectricalAnalysisDashboard 
                    result={electricalResult} 
                    onBack={reset} 
                    language={profile.language}
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {isAnalyzing && (
              <div className="fixed inset-0 z-[60] bg-white/60 backdrop-blur-md flex items-center justify-center">
                <div className="bg-white p-8 rounded-3xl shadow-2xl border border-emerald-100 flex flex-col items-center gap-4 max-w-sm text-center">
                  <div className="relative">
                    <div className="w-16 h-16 border-4 border-emerald-100 border-t-emerald-600 rounded-full animate-spin" />
                    <Scan className="w-6 h-6 text-emerald-600 absolute inset-0 m-auto animate-pulse" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{t.analyzing}</h3>
                </div>
              </div>
            )}

            {error && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 p-4 bg-red-50 border border-red-100 rounded-2xl text-red-700 text-sm font-medium flex items-center gap-3"
              >
                <Info className="w-5 h-5 text-red-500" />
                {error}
              </motion.div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gray-900 rounded-xl flex items-center justify-center">
              <Scan className="w-6 h-6 text-white" />
            </div>
            <span className="font-bold text-gray-900">{t.appName} AI</span>
          </div>
          
          <div className="flex items-center gap-8 text-sm font-medium text-gray-500">
          </div>
          
          <p className="text-sm text-gray-400">
            © 2026 {t.appName}. Empowering healthy choices.
          </p>
        </div>
      </footer>

      {/* Share Toast */}
      <AnimatePresence>
        {showShareToast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] bg-gray-900 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3"
          >
            <div className="w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center">
              <Check className="w-4 h-4 text-white" />
            </div>
            <p className="text-sm font-bold tracking-wide">Link copied to clipboard!</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
