import React from 'react';
import { motion } from 'motion/react';
import { Clock, Sun, Sunset, Moon } from 'lucide-react';

interface DayTimeline3DProps {
  activeMealType: string;
  setActiveMealType: (type: string) => void;
  timeline: {
    morning: string;
    noon: string;
    evening: string;
    night: string;
  };
}

export default function DayTimeline3D({ activeMealType, setActiveMealType, timeline }: DayTimeline3DProps) {
  const nodes = [
    { id: 'preBreakfast', label: timeline?.morning || 'Morning', icon: <Clock className="w-5 h-5" />, color: 'from-amber-400 to-orange-500' },
    { id: 'breakfast', label: timeline?.morning || 'Morning', icon: <Sun className="w-5 h-5" />, color: 'from-orange-400 to-amber-500' },
    { id: 'lunch', label: timeline?.noon || 'Noon', icon: <Sun className="w-5 h-5" />, color: 'from-sky-400 to-blue-500' },
    { id: 'snacks', label: timeline?.evening || 'Evening', icon: <Sunset className="w-5 h-5" />, color: 'from-indigo-400 to-purple-500' },
    { id: 'dinner', label: timeline?.night || 'Night', icon: <Moon className="w-5 h-5" />, color: 'from-slate-400 to-slate-600' },
  ];

  return (
    <div className="relative w-full grid grid-cols-5 gap-1 lg:flex lg:items-center lg:justify-between lg:px-4 py-4 lg:py-8">
      {/* Connecting Line (Hidden on mobile for better layout) */}
      <div className="hidden lg:block absolute top-1/2 left-8 right-8 h-1 bg-white/5 rounded-full -translate-y-1/2 z-0">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: '100%' }}
          className="h-full bg-gradient-to-r from-amber-500 via-indigo-500 to-slate-500 rounded-full opacity-30"
        />
      </div>

      {nodes.map((node, idx) => {
        const isActive = activeMealType === node.id;
        
        return (
          <motion.button
            key={node.id}
            onClick={() => setActiveMealType(node.id)}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="relative z-10 flex flex-col items-center gap-1 lg:gap-3 group"
          >
            {/* 3D Node Sphere */}
            <motion.div 
              animate={{ 
                scale: isActive ? 1.1 : 0.9,
                boxShadow: isActive ? `0 0 20px rgba(79, 70, 229, 0.4)` : '0 0 0px transparent'
              }}
              className={`w-10 h-10 lg:w-14 lg:h-14 rounded-full flex items-center justify-center transition-all ${
                isActive ? `bg-gradient-to-br ${node.color} border-2 border-white/20` : 'bg-slate-900 border border-white/5 group-hover:border-white/20'
              }`}
            >
              <div className={`transition-colors text-sm lg:text-base ${isActive ? 'text-white' : 'text-slate-500 group-hover:text-slate-300'}`}>
                {node.icon}
              </div>

              {/* Active Glow Ring */}
              {isActive && (
                <motion.div 
                  layoutId="active-ring"
                  className="absolute inset-0 rounded-full border-2 lg:border-4 border-white/20 animate-pulse"
                />
              )}
            </motion.div>

            {/* Label */}
            <motion.div 
              animate={{ opacity: isActive ? 1 : 0.5, y: isActive ? 0 : 2 }}
              className="flex flex-col items-center"
            >
              <span className={`text-[8px] lg:text-[10px] font-black uppercase tracking-widest text-center ${isActive ? 'text-white' : 'text-slate-500'}`}>
                {node.label}
              </span>
              {isActive && (
                <motion.div 
                  layoutId="active-dot"
                  className="w-1 h-1 lg:w-1.5 lg:h-1.5 rounded-full bg-white mt-0.5 shadow-[0_0_10px_rgba(255,255,255,0.8)]"
                />
              )}
            </motion.div>
          </motion.button>
        );
      })}
    </div>
  );
}
