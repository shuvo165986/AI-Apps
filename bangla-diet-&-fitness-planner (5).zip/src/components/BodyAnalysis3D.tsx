import React, { useState, useEffect } from 'react';
import { Activity, Flame, Scale, Target, HeartPulse } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface BodyAnalysisProps {
  formData: {
    name?: string;
    gender: string;
    age: string;
    heightFt: string;
    heightIn: string;
    weight: string;
    activityLevel: string;
  };
}

export default function BodyAnalysis3D({ formData }: BodyAnalysisProps) {
  const [phase, setPhase] = useState<'measuring' | 'action'>('measuring');

  useEffect(() => {
    // Reset phase when formData changes
    setPhase('measuring');
    const timer = setTimeout(() => {
      setPhase('action');
    }, 4000);
    return () => clearTimeout(timer);
  }, [formData]);

  // Calculations
  const weight = parseFloat(formData.weight) || 0;
  const heightFt = parseFloat(formData.heightFt) || 0;
  const heightIn = parseFloat(formData.heightIn) || 0;
  const age = parseFloat(formData.age) || 0;
  
  const heightCm = (heightFt * 12 + heightIn) * 2.54;
  const heightM = heightCm / 100;
  
  const bmi = weight > 0 && heightM > 0 ? (weight / (heightM * heightM)).toFixed(1) : '0';
  const bmiValue = parseFloat(bmi);
  
  let condition = 'Normal';
  let conditionColor = 'text-emerald-400';
  let conditionBg = 'bg-emerald-400/20';
  let conditionBorder = 'border-emerald-500/30';
  let conditionAura = 'bg-emerald-500/20';
  
  if (bmiValue < 18.5) {
    condition = 'Underweight';
    conditionColor = 'text-blue-400';
    conditionBg = 'bg-blue-400/20';
    conditionBorder = 'border-blue-500/30';
    conditionAura = 'bg-blue-500/20';
  } else if (bmiValue >= 25 && bmiValue < 29.9) {
    condition = 'Overweight';
    conditionColor = 'text-orange-400';
    conditionBg = 'bg-orange-400/20';
    conditionBorder = 'border-orange-500/30';
    conditionAura = 'bg-orange-500/20';
  } else if (bmiValue >= 30) {
    condition = 'Obese';
    conditionColor = 'text-red-400';
    conditionBg = 'bg-red-400/20';
    conditionBorder = 'border-red-500/30';
    conditionAura = 'bg-red-500/20';
  }

  // BMR & TDEE
  let bmr = 0;
  if (formData.gender === 'Male') {
    bmr = (10 * weight) + (6.25 * heightCm) - (5 * age) + 5;
  } else {
    bmr = (10 * weight) + (6.25 * heightCm) - (5 * age) - 161;
  }

  const activityMultipliers: Record<string, number> = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    high: 1.725,
    extreme: 1.9
  };
  const tdee = Math.round(bmr * (activityMultipliers[formData.activityLevel] || 1.2));

  const inchesOver5Ft = Math.max(0, (heightFt - 5) * 12 + heightIn);
  let idealWeight = 0;
  if (formData.gender === 'Male') {
    idealWeight = 50.0 + (2.3 * inchesOver5Ft);
  } else {
    idealWeight = 45.5 + (2.3 * inchesOver5Ft);
  }

  const getCharacterUrl = () => {
    const isFemale = formData.gender === 'Female';
    if (phase === 'measuring') {
      return isFemale 
        ? 'https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/People/Woman%20Standing.png' 
        : 'https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/People/Man%20Standing.png';
    }
    
    if (bmiValue < 18.5) {
      return isFemale 
        ? 'https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/People/Woman%20Lifting%20Weights.png' 
        : 'https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/People/Man%20Lifting%20Weights.png';
    } else if (bmiValue >= 25) {
      // Overweight - Using gesturing to simulate belly press/workout frustration
      return isFemale 
        ? 'https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/People/Woman%20Gesturing%20No.png' 
        : 'https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/People/Man%20Gesturing%20No.png';
    } else {
      return isFemale 
        ? 'https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/People/Woman%20Dancing.png' 
        : 'https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/People/Man%20Dancing.png';
    }
  };

  // Animation variants for the character based on condition
  const getCharacterAnimation = () => {
    if (phase === 'measuring') {
      return { y: [0, -5, 0], transition: { repeat: Infinity, duration: 2 } };
    }
    if (bmiValue < 18.5) {
      // Lifting weights
      return { y: [0, -15, 0], transition: { repeat: Infinity, duration: 1.5, ease: "easeInOut" } };
    } else if (bmiValue >= 25) {
      // Belly press / squish animation
      return { 
        scaleX: [1, 1.15, 0.9, 1.05, 1], 
        scaleY: [1, 0.9, 1.1, 0.95, 1],
        transition: { repeat: Infinity, duration: 2.5, ease: "easeInOut" } 
      };
    } else {
      // Dancing
      return { 
        rotate: [0, -10, 10, -10, 0], 
        y: [0, -20, 0, -10, 0],
        transition: { repeat: Infinity, duration: 2 } 
      };
    }
  };

  return (
    <div className="my-10 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 md:p-10 border border-slate-700 shadow-2xl relative overflow-hidden">
      {/* Premium Background decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-emerald-500/10 rounded-full blur-[100px]"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-blue-500/10 rounded-full blur-[100px]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5 mix-blend-overlay"></div>
      </div>

      <div className="text-center mb-12 relative z-10">
        <h2 className="text-2xl md:text-4xl font-bold text-white flex items-center justify-center gap-3 tracking-tight">
          <HeartPulse className="w-8 h-8 md:w-10 md:h-10 text-emerald-400 drop-shadow-[0_0_15px_rgba(52,211,153,0.5)]" />
          Personal Body Analysis
        </h2>
        <p className="text-slate-300 mt-3 text-lg font-light">
          {formData.name ? <span className="font-semibold text-emerald-300">{formData.name}</span> : 'Here'}, let's visualize your body metrics
        </p>
      </div>

      <div className="flex flex-col md:flex-row items-center justify-center gap-10 md:gap-16 relative z-10">
        
        {/* Left Stats */}
        <div className="flex flex-col gap-6 w-full md:w-1/3 order-2 md:order-1">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="bg-slate-800/50 backdrop-blur-xl p-6 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-5 hover:bg-slate-800/80 transition-all group"
          >
            <div className={`p-4 rounded-xl ${conditionBg} ${conditionColor} border ${conditionBorder} shadow-inner group-hover:scale-110 transition-transform`}>
              <Scale className="w-7 h-7" />
            </div>
            <div>
              <p className="text-sm text-slate-400 font-medium uppercase tracking-wider">BMI Score</p>
              <div className="flex items-baseline gap-3 mt-1">
                <p className={`text-3xl font-bold ${conditionColor}`}>{bmi}</p>
                <span className={`text-xs font-bold px-3 py-1 rounded-full ${conditionBg} ${conditionColor} border ${conditionBorder}`}>
                  {condition}
                </span>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4, type: "spring" }}
            className="bg-slate-800/50 backdrop-blur-xl p-6 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-5 hover:bg-slate-800/80 transition-all group"
          >
            <div className="p-4 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30 shadow-inner group-hover:scale-110 transition-transform">
              <Target className="w-7 h-7" />
            </div>
            <div>
              <p className="text-sm text-slate-400 font-medium uppercase tracking-wider">Ideal Weight</p>
              <p className="text-3xl font-bold text-white mt-1">{idealWeight.toFixed(1)} <span className="text-base font-normal text-slate-400">kg</span></p>
            </div>
          </motion.div>
        </div>

        {/* Center 3D Character & Scales */}
        <div className="relative order-1 md:order-2 flex justify-center items-end h-80 w-64" style={{ perspective: '1000px' }}>
          
          {/* Glowing aura behind character */}
          <div className={`absolute inset-0 ${conditionAura} blur-3xl rounded-full scale-150 animate-pulse`}></div>
          
          {/* 3D Height Scale (Left) */}
          <AnimatePresence>
            {phase === 'measuring' && (
              <motion.div
                initial={{ opacity: 0, x: -50, rotateY: -30 }}
                animate={{ opacity: 1, x: -20, rotateY: -30 }}
                exit={{ opacity: 0, x: -50, transition: { duration: 0.5 } }}
                className="absolute left-0 bottom-12 w-8 h-64 bg-gradient-to-r from-slate-300 to-slate-400 rounded-t-md border-r-4 border-slate-500 shadow-2xl z-0 flex flex-col justify-between py-2 items-end pr-1 origin-bottom"
                style={{ transformStyle: 'preserve-3d' }}
              >
                {[...Array(12)].map((_, i) => (
                  <div key={i} className={`h-0.5 bg-slate-600 ${i % 2 === 0 ? 'w-4' : 'w-2'}`}></div>
                ))}
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.5, type: "spring" }}
                  className="absolute -top-4 -right-24 bg-indigo-600 text-white text-sm font-bold px-3 py-1.5 rounded-lg shadow-[0_0_15px_rgba(79,70,229,0.5)] border border-indigo-400 flex items-center gap-1 z-30 whitespace-nowrap"
                >
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
                  {formData.heightFt}'{formData.heightIn}"
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* 3D Weight Machine (Bottom) */}
          <AnimatePresence>
            {phase === 'measuring' && (
              <motion.div 
                initial={{ opacity: 0, y: 50, rotateX: 60 }}
                animate={{ opacity: 1, y: 0, rotateX: 60 }}
                exit={{ opacity: 0, y: 50, transition: { duration: 0.5 } }}
                className="absolute -bottom-4 w-56 h-48 bg-gradient-to-b from-slate-200 to-slate-400 rounded-full border-b-[12px] border-slate-600 shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex items-center justify-center z-0 origin-bottom"
                style={{ transformStyle: 'preserve-3d' }}
              >
                {/* Inner scale display */}
                <div className="w-24 h-12 bg-slate-900 rounded-lg flex items-center justify-center border-4 border-slate-300 shadow-inner translate-y-12">
                  <motion.span 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.8 }}
                    className="text-emerald-400 font-mono text-lg font-bold"
                  >
                    {formData.weight}kg
                  </motion.span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* 3D Character Image */}
          <motion.img 
            key={phase} // Force re-render animation on phase change
            src={getCharacterUrl()} 
            alt="3D Body Avatar" 
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, ...getCharacterAnimation() } as any}
            transition={{ type: "spring", bounce: 0.5, duration: 0.8 }}
            className="w-56 h-56 md:w-64 md:h-64 object-contain relative z-20 drop-shadow-[0_20px_30px_rgba(0,0,0,0.4)] mb-8"
          />
          
          {/* Floating Status Badge (Action Phase) */}
          <AnimatePresence>
            {phase === 'action' && (
              <motion.div 
                initial={{ opacity: 0, scale: 0, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ type: "spring", delay: 0.2 }}
                className={`absolute -top-4 bg-slate-800/80 backdrop-blur-md px-4 py-2 rounded-full shadow-xl border ${conditionBorder} text-sm font-bold ${conditionColor} z-30 flex items-center gap-2`}
              >
                {bmiValue < 18.5 && "Time to build muscle! 💪"}
                {bmiValue >= 25 && "Let's burn those calories! 🔥"}
                {bmiValue >= 18.5 && bmiValue < 25 && "Perfect balance! 🕺"}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Stats */}
        <div className="flex flex-col gap-6 w-full md:w-1/3 order-3">
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3, type: "spring" }}
            className="bg-slate-800/50 backdrop-blur-xl p-6 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-5 hover:bg-slate-800/80 transition-all group"
          >
            <div className="p-4 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/30 shadow-inner group-hover:scale-110 transition-transform">
              <Flame className="w-7 h-7" />
            </div>
            <div>
              <p className="text-sm text-slate-400 font-medium uppercase tracking-wider">BMR (Resting)</p>
              <p className="text-3xl font-bold text-white mt-1">{Math.round(bmr)} <span className="text-base font-normal text-slate-400">kcal</span></p>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, type: "spring" }}
            className="bg-slate-800/50 backdrop-blur-xl p-6 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-5 hover:bg-slate-800/80 transition-all group"
          >
            <div className="p-4 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 shadow-inner group-hover:scale-110 transition-transform">
              <Activity className="w-7 h-7" />
            </div>
            <div>
              <p className="text-sm text-slate-400 font-medium uppercase tracking-wider">TDEE (Daily Burn)</p>
              <p className="text-3xl font-bold text-white mt-1">{tdee} <span className="text-base font-normal text-slate-400">kcal</span></p>
            </div>
          </motion.div>
        </div>
        
      </div>
    </div>
  );
}
