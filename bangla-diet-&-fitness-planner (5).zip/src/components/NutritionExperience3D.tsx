import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Clock, 
  User, 
  Utensils, 
  Activity, 
  Zap, 
  ChevronRight, 
  ChevronLeft,
  Info,
  RefreshCw,
  TrendingUp,
  Heart
} from 'lucide-react';
import SmartPlate3D from './SmartPlate3D';
import DayTimeline3D from './DayTimeline3D';

interface NutritionExperience3DProps {
  data: any; // PlanData
  selectedMeals: any;
  onSwap: (type: string, index: number) => void;
}

export default function NutritionExperience3D({ data, selectedMeals, onSwap }: NutritionExperience3DProps) {
  const [activeMealType, setActiveMealType] = useState<string>('breakfast');
  const [showDetails, setShowDetails] = useState(false);

  const mealTypes = [
    { id: 'preBreakfast', label: 'Pre-Breakfast', icon: <Clock className="w-4 h-4" /> },
    { id: 'breakfast', label: 'Breakfast', icon: <Utensils className="w-4 h-4" /> },
    { id: 'lunch', label: 'Lunch', icon: <Utensils className="w-4 h-4" /> },
    { id: 'snacks', label: 'Snacks', icon: <Utensils className="w-4 h-4" /> },
    { id: 'dinner', label: 'Dinner', icon: <Utensils className="w-4 h-4" /> },
  ];

  const currentMealOptions = data.meals[activeMealType] || [];
  const currentMealIndex = selectedMeals[activeMealType] || 0;
  const currentMeal = currentMealOptions[currentMealIndex];

  const nextMeal = () => {
    const nextIdx = (currentMealIndex + 1) % currentMealOptions.length;
    onSwap(activeMealType, nextIdx);
  };

  const prevMeal = () => {
    const prevIdx = (currentMealIndex - 1 + currentMealOptions.length) % currentMealOptions.length;
    onSwap(activeMealType, prevIdx);
  };

  return (
    <div className="relative min-h-[600px] lg:min-h-[800px] w-full bg-slate-950 rounded-[2rem] lg:rounded-[3rem] overflow-hidden border border-slate-800 shadow-2xl">
      {/* Background Ambient Glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-500/10 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-emerald-500/10 rounded-full blur-[120px]"></div>
      </div>

      <div className="relative z-10 p-6 lg:p-12 flex flex-col h-full">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8 lg:mb-12">
          <div>
            <motion.h2 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-2xl lg:text-4xl font-black text-white tracking-tight mb-2"
            >
              Nutrition Experience
            </motion.h2>
            <p className="text-slate-400 font-medium text-sm lg:text-base">Interactive meal planning</p>
          </div>

          <div className="flex items-center gap-2 lg:gap-4 bg-white/5 backdrop-blur-xl p-1 lg:p-2 rounded-xl lg:rounded-2xl border border-white/10">
            <div className="flex items-center gap-2 px-3 lg:px-4 py-1.5 lg:py-2 bg-indigo-500/20 rounded-lg lg:rounded-xl border border-indigo-500/30">
              <Zap className="w-3 h-3 lg:w-4 lg:h-4 text-indigo-400" />
              <span className="text-xs lg:text-sm font-bold text-indigo-400">Energy: {data.avatar?.energyState || 'Medium'}</span>
            </div>
            <div className="flex items-center gap-2 px-3 lg:px-4 py-1.5 lg:py-2 bg-emerald-500/20 rounded-lg lg:rounded-xl border border-emerald-500/30">
              <Heart className="w-3 h-3 lg:w-4 lg:h-4 text-emerald-400" />
              <span className="text-xs lg:text-sm font-bold text-emerald-400">Score: 92</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 flex-1">
          {/* Left Column: Timeline */}
          <div className="lg:col-span-4 flex flex-col gap-8">
            <div className="bg-white/5 rounded-[2rem] border border-white/10 p-6">
              <DayTimeline3D 
                activeMealType={activeMealType} 
                setActiveMealType={setActiveMealType} 
                timeline={data.timeline}
              />
            </div>
          </div>

          {/* Middle Column: 3D Plate */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="flex-1 bg-gradient-to-b from-white/5 to-transparent rounded-[2rem] lg:rounded-[3rem] border border-white/10 p-4 lg:p-8 flex flex-col items-center justify-center relative">
              <div className="w-full flex justify-between items-center mb-4">
                <motion.div
                  key={activeMealType}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex flex-col"
                >
                  <span className="text-indigo-400 text-[10px] lg:text-xs font-black uppercase tracking-widest mb-1">Active Meal</span>
                  <h3 className="text-xl lg:text-3xl font-black text-white">{mealTypes.find(t => t.id === activeMealType)?.label}</h3>
                </motion.div>

                <div className="flex gap-2">
                  <button 
                    onClick={prevMeal}
                    className="p-2 lg:p-3 bg-slate-900 hover:bg-slate-800 text-white rounded-lg lg:rounded-xl border border-slate-800 transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4 lg:w-5 lg:h-5" />
                  </button>
                  <button 
                    onClick={nextMeal}
                    className="p-2 lg:p-3 bg-slate-900 hover:bg-slate-800 text-white rounded-lg lg:rounded-xl border border-slate-800 transition-colors"
                  >
                    <ChevronRight className="w-4 h-4 lg:w-5 lg:h-5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 flex items-center justify-center w-full min-h-[200px] lg:min-h-[300px]">
                <SmartPlate3D meal={currentMeal} />
              </div>

              <div className="mt-4 flex items-center gap-2 lg:gap-4 bg-slate-900/80 backdrop-blur-md px-4 lg:px-6 py-2 lg:py-3 rounded-xl lg:rounded-2xl border border-slate-800 shadow-2xl w-full justify-between">
                <div className="flex flex-col items-center">
                  <span className="text-[9px] lg:text-[10px] font-bold text-slate-500 uppercase">Calories</span>
                  <span className="text-sm lg:text-lg font-black text-white">{currentMeal?.calories}</span>
                </div>
                <div className="w-px h-6 lg:h-8 bg-slate-800"></div>
                <div className="flex flex-col items-center">
                  <span className="text-[9px] lg:text-[10px] font-bold text-slate-500 uppercase">Protein</span>
                  <span className="text-sm lg:text-lg font-black text-white">{currentMeal?.protein}</span>
                </div>
                <div className="w-px h-6 lg:h-8 bg-slate-800"></div>
                <div className="flex flex-col items-center">
                  <span className="text-[9px] lg:text-[10px] font-bold text-slate-500 uppercase">Carbs</span>
                  <span className="text-sm lg:text-lg font-black text-white">{currentMeal?.carbs}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Nutrition Visuals & Controls */}
          <div className="lg:col-span-3 flex flex-col gap-6">
            <div className="bg-white/5 rounded-[2.5rem] border border-white/10 p-8 flex flex-col gap-6">
              <h4 className="text-white font-black text-xl flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-indigo-400" />
                Nutrition Visuals
              </h4>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold uppercase tracking-widest">
                    <span className="text-slate-400">Protein Bar</span>
                    <span className="text-emerald-400">{currentMeal?.protein}</span>
                  </div>
                  <div className="h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: '65%' }}
                      className="h-full bg-emerald-500 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)]"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold uppercase tracking-widest">
                    <span className="text-slate-400">Carbs Meter</span>
                    <span className="text-blue-400">{currentMeal?.carbs}</span>
                  </div>
                  <div className="h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: '45%' }}
                      className="h-full bg-blue-500 rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold uppercase tracking-widest">
                    <span className="text-slate-400">Fat Indicator</span>
                    <span className="text-amber-400">{currentMeal?.fats}</span>
                  </div>
                  <div className="h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: '30%' }}
                      className="h-full bg-amber-500 rounded-full shadow-[0_0_10px_rgba(245,158,11,0.5)]"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex-1 bg-white/5 rounded-[2.5rem] border border-white/10 p-8 flex flex-col gap-4">
              {/* Buttons Removed */}

              <div className="mt-auto p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/20">
                <p className="text-emerald-400 text-xs font-bold text-center leading-relaxed">
                  "This meal provides 40% of your daily protein target. Great choice!"
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Details Modal Overlay */}
      <AnimatePresence>
        {showDetails && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-slate-950/90 backdrop-blur-xl p-12 flex items-center justify-center"
          >
            <div className="max-w-2xl w-full bg-slate-900 rounded-[3rem] border border-slate-800 p-12 relative">
              <button 
                onClick={() => setShowDetails(false)}
                className="absolute top-8 right-8 text-slate-500 hover:text-white transition-colors"
              >
                <RefreshCw className="w-8 h-8 rotate-45" />
              </button>

              <h3 className="text-3xl font-black text-white mb-8">{currentMeal?.name}</h3>
              
              <div className="grid grid-cols-2 gap-8 mb-8">
                <div className="space-y-4">
                  <h5 className="text-indigo-400 text-xs font-black uppercase tracking-widest">Ingredients</h5>
                  <ul className="space-y-2">
                    {currentMeal?.ingredients?.map((ing: string, i: number) => (
                      <li key={i} className="text-slate-300 flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                        {ing}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="space-y-4">
                  <h5 className="text-emerald-400 text-xs font-black uppercase tracking-widest">Micronutrients</h5>
                  <p className="text-slate-300 leading-relaxed">{currentMeal?.micros}</p>
                  
                  <h5 className="text-amber-400 text-xs font-black uppercase tracking-widest mt-6">Taste Profile</h5>
                  <p className="text-slate-300">{currentMeal?.tasteProfile}</p>
                </div>
              </div>

              <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
                <p className="text-slate-400 italic text-sm leading-relaxed">
                  {currentMeal?.description}
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
