import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface SmartPlate3DProps {
  meal: {
    name: string;
    plate_3d?: {
      layout: string;
      items: { name: string; size: 'small' | 'medium' | 'large'; emoji: string }[];
    };
  };
}

export default function SmartPlate3D({ meal }: SmartPlate3DProps) {
  const items = meal?.plate_3d?.items || [];

  const getPosition = (index: number, total: number, layout: string) => {
    if (layout === 'circular') {
      const angle = (index / total) * 2 * Math.PI;
      const radius = 60;
      return { x: Math.cos(angle) * radius, y: Math.sin(angle) * radius };
    }
    
    // Divided layout
    if (index === 0) return { x: 0, y: -40 };
    if (index === 1) return { x: -50, y: 40 };
    return { x: 50, y: 40 };
  };

  return (
    <div className="relative w-full h-full flex items-center justify-center perspective-[1000px]">
      {/* 3D Plate Base */}
      <motion.div 
        animate={{ rotateX: 60, rotateZ: [0, 360] }}
        transition={{ 
          rotateX: { duration: 0 }, 
          rotateZ: { duration: 60, repeat: Infinity, ease: "linear" } 
        }}
        className="relative w-80 h-80 rounded-full bg-slate-100/10 border-[12px] border-white/5 shadow-[0_40px_80px_rgba(0,0,0,0.5),inset_0_0_40px_rgba(255,255,255,0.1)] flex items-center justify-center"
      >
        {/* Inner Plate Ring */}
        <div className="w-[85%] h-[85%] rounded-full border border-white/10 shadow-inner"></div>
        
        {/* Dividers (if layout is divided) */}
        {meal?.plate_3d?.layout === 'divided' && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-px h-full bg-white/5 rotate-45"></div>
            <div className="w-px h-full bg-white/5 -rotate-45"></div>
          </div>
        )}
      </motion.div>

      {/* Food Items (Floating above plate) */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <AnimatePresence mode="wait">
          <motion.div 
            key={meal?.name}
            className="relative w-full h-full flex items-center justify-center"
          >
            {items.map((item, idx) => {
              const pos = getPosition(idx, items.length, meal?.plate_3d?.layout || 'divided');
              const size = item.size === 'large' ? 'text-7xl' : item.size === 'medium' ? 'text-5xl' : 'text-3xl';
              
              return (
                <motion.div
                  key={`${meal?.name}-${item.name}-${idx}`}
                  initial={{ y: -200, opacity: 0, scale: 0.5 }}
                  animate={{ y: pos.y, x: pos.x, opacity: 1, scale: 1 }}
                  exit={{ y: 200, opacity: 0, scale: 0.5 }}
                  transition={{ 
                    type: 'spring', 
                    stiffness: 100, 
                    damping: 15, 
                    delay: idx * 0.2 
                  }}
                  className="absolute z-20 flex flex-col items-center gap-2"
                >
                  {/* Food Item Shadow */}
                  <div className="absolute bottom-[-10px] w-12 h-4 bg-black/40 rounded-full blur-md" />
                  
                  {/* Food Emoji */}
                  <span className={`${size} drop-shadow-[0_10px_20px_rgba(0,0,0,0.5)] select-none`}>
                    {item.emoji}
                  </span>

                  {/* Item Label */}
                  <motion.span 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 1 + idx * 0.1 }}
                    className="text-[10px] font-black text-white/50 uppercase tracking-widest bg-slate-900/80 px-2 py-1 rounded-md backdrop-blur-sm border border-white/5"
                  >
                    {item.name}
                  </motion.span>

                  {/* Steam Animation (if hot) */}
                  {item.size === 'large' && (
                    <div className="absolute -top-8 flex gap-1">
                      {[1, 2, 3].map(i => (
                        <motion.div
                          key={i}
                          animate={{ 
                            y: [-10, -40], 
                            opacity: [0, 0.5, 0],
                            x: [0, i % 2 === 0 ? 5 : -5, 0]
                          }}
                          transition={{ 
                            duration: 2, 
                            repeat: Infinity, 
                            delay: i * 0.5 
                          }}
                          className="w-1 h-4 bg-white/20 rounded-full blur-[2px]"
                        />
                      ))}
                    </div>
                  )}
                </motion.div>
              );
            })}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[1, 2, 3, 4, 5].map(i => (
          <motion.div
            key={i}
            animate={{ 
              y: [0, -100], 
              x: [0, Math.sin(i) * 50],
              opacity: [0, 0.3, 0]
            }}
            transition={{ 
              duration: 4 + i, 
              repeat: Infinity, 
              delay: i * 0.8 
            }}
            className="absolute top-1/2 left-1/2 w-1 h-1 bg-white/20 rounded-full"
          />
        ))}
      </div>
    </div>
  );
}
