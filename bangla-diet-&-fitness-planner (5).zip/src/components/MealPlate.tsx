import React from 'react';
import { motion } from 'motion/react';
import { Salad, Coffee, Utensils, Moon, Sun, Sunrise } from 'lucide-react';

interface MealPlateProps {
  type: 'preBreakfast' | 'breakfast' | 'lunch' | 'snacks' | 'dinner';
  isCompleted: boolean;
}

export default function MealPlate({ type, isCompleted }: MealPlateProps) {
  const getIcon = () => {
    switch (type) {
      case 'preBreakfast': return <Sunrise className="w-8 h-8" />;
      case 'breakfast': return <Coffee className="w-8 h-8" />;
      case 'lunch': return <Sun className="w-8 h-8" />;
      case 'snacks': return <Utensils className="w-8 h-8" />;
      case 'dinner': return <Moon className="w-8 h-8" />;
      default: return <Salad className="w-8 h-8" />;
    }
  };

  const getColor = () => {
    if (isCompleted) return 'bg-emerald-500 shadow-emerald-200';
    switch (type) {
      case 'preBreakfast': return 'bg-amber-400 shadow-amber-100';
      case 'breakfast': return 'bg-orange-400 shadow-orange-100';
      case 'lunch': return 'bg-blue-400 shadow-blue-100';
      case 'snacks': return 'bg-rose-400 shadow-rose-100';
      case 'dinner': return 'bg-indigo-400 shadow-indigo-100';
      default: return 'bg-slate-400 shadow-slate-100';
    }
  };

  return (
    <div className="relative w-24 h-24 flex items-center justify-center">
      {/* Outer Plate Shadow */}
      <div className="absolute inset-0 bg-slate-200 rounded-full blur-xl opacity-50"></div>
      
      {/* The Plate */}
      <motion.div 
        animate={{ 
          rotate: isCompleted ? 360 : 0,
          scale: isCompleted ? 1.1 : 1
        }}
        transition={{ type: 'spring', stiffness: 100 }}
        className="relative w-20 h-20 bg-white rounded-full border-4 border-slate-100 shadow-inner flex items-center justify-center overflow-hidden"
      >
        {/* Inner Plate Ring */}
        <div className="absolute inset-2 border border-slate-50 rounded-full"></div>
        
        {/* Food/Icon Container */}
        <motion.div
          initial={false}
          animate={{ 
            y: isCompleted ? [0, -10, 0] : 0,
            scale: isCompleted ? 1.2 : 1
          }}
          className={`p-3 rounded-full text-white shadow-lg transition-colors duration-500 ${getColor()}`}
        >
          {getIcon()}
        </motion.div>

        {/* Steam/Sparkle effects when completed */}
        {isCompleted && (
          <>
            <motion.div 
              animate={{ y: [-20, -40], opacity: [0, 1, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="absolute top-4 left-1/2 w-1 h-4 bg-emerald-200/50 rounded-full blur-sm"
            />
            <motion.div 
              animate={{ y: [-20, -40], opacity: [0, 1, 0] }}
              transition={{ repeat: Infinity, duration: 2, delay: 0.5 }}
              className="absolute top-4 left-1/3 w-1 h-3 bg-emerald-200/50 rounded-full blur-sm"
            />
          </>
        )}
      </motion.div>

      {/* Completion Ring */}
      <svg className="absolute inset-0 w-full h-full -rotate-90">
        <circle
          cx="48"
          cy="48"
          r="44"
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
          className="text-slate-100"
        />
        <motion.circle
          cx="48"
          cy="48"
          r="44"
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
          strokeDasharray="276"
          initial={{ strokeDashoffset: 276 }}
          animate={{ strokeDashoffset: isCompleted ? 0 : 276 }}
          transition={{ duration: 1, ease: "easeInOut" }}
          className="text-emerald-500"
        />
      </svg>
    </div>
  );
}
