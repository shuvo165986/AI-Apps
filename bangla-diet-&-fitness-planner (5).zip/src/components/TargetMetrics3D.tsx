import React from 'react';
import { Target, Zap, Salad, Droplet, Flame, TrendingUp, Info } from 'lucide-react';
import { motion } from 'motion/react';
import { RadialBarChart, RadialBar, Legend, ResponsiveContainer, PolarAngleAxis } from 'recharts';

interface TargetMetrics3DProps {
  targets: {
    calories: string | number;
    protein: string;
    carbs: string;
    fats: string;
  };
  provided: {
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
  };
}

export default function TargetMetrics3D({ targets, provided }: TargetMetrics3DProps) {
  const parseVal = (val: string | number) => {
    if (typeof val === 'number') return val;
    return parseFloat(val.replace(/[a-zA-Z]/g, '')) || 0;
  };

  const metrics = [
    {
      name: 'Calories',
      target: parseVal(targets.calories),
      actual: provided.calories,
      fill: '#f97316',
      icon: <Flame className="w-5 h-5" />,
      unit: 'kcal',
      fullMark: 3000
    },
    {
      name: 'Protein',
      target: parseVal(targets.protein),
      actual: provided.protein,
      fill: '#10b981',
      icon: <Zap className="w-5 h-5" />,
      unit: 'g',
      fullMark: 200
    },
    {
      name: 'Carbs',
      target: parseVal(targets.carbs),
      actual: provided.carbs,
      fill: '#3b82f6',
      icon: <Salad className="w-5 h-5" />,
      unit: 'g',
      fullMark: 400
    },
    {
      name: 'Fats',
      target: parseVal(targets.fats),
      actual: provided.fats,
      fill: '#f59e0b',
      icon: <Droplet className="w-5 h-5" />,
      unit: 'g',
      fullMark: 100
    }
  ];

  return (
    <div className="my-16 relative overflow-hidden rounded-[3rem] bg-slate-950 p-8 lg:p-12 shadow-2xl border border-slate-800">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-30">
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/20 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-emerald-600/20 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="relative z-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-16">
          <div className="flex items-center gap-5">
            <motion.div 
              initial={{ rotate: -20, scale: 0.8 }}
              animate={{ rotate: 0, scale: 1 }}
              transition={{ type: 'spring', stiffness: 200 }}
              className="p-5 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl shadow-xl shadow-indigo-500/30"
            >
              <Target className="w-10 h-10 text-white" />
            </motion.div>
            <div>
              <h2 className="text-4xl font-black text-white tracking-tight">Performance Comparison</h2>
              <p className="text-slate-400 font-medium text-lg">Target Goals vs. Actual Intake</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 bg-white/5 backdrop-blur-xl px-6 py-3 rounded-2xl border border-white/10 shadow-inner">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <span className="text-sm font-black text-emerald-400 uppercase tracking-widest">Real-time Analytics</span>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-12 items-center">
          {/* Left Side: Target vs Actual Comparison Bars */}
          <div className="space-y-8">
            {metrics.map((item, idx) => {
              const percentage = Math.min(100, (item.actual / item.target) * 100);
              return (
                <motion.div
                  key={item.name}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="relative group"
                >
                  <div className="flex items-center justify-between mb-3 px-2">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-white group-hover:scale-110 transition-transform shadow-lg" style={{ color: item.fill }}>
                        {item.icon}
                      </div>
                      <span className="text-white font-black text-xl tracking-tight">{item.name}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-slate-500 text-xs font-bold uppercase tracking-widest block">Progress</span>
                      <span className="text-white font-black text-xl">{Math.round(percentage)}%</span>
                    </div>
                  </div>

                  {/* 3D-like Dual Bar */}
                  <div className="h-10 bg-slate-900/80 rounded-2xl p-1.5 border border-slate-800 shadow-inner overflow-hidden relative">
                    {/* Target Marker */}
                    <div className="absolute top-0 bottom-0 w-1 bg-white/20 z-10" style={{ left: '100%' }}></div>
                    
                    {/* Actual Progress Bar */}
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${percentage}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.5, ease: "easeOut", delay: 0.5 + idx * 0.1 }}
                      className="h-full rounded-xl relative shadow-lg overflow-hidden"
                      style={{ backgroundColor: item.fill }}
                    >
                      {/* Glossy Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-white/20"></div>
                      <motion.div 
                        animate={{ x: ['-100%', '200%'] }}
                        transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"
                      ></motion.div>
                    </motion.div>
                  </div>

                  {/* Comparison Labels */}
                  <div className="flex justify-between mt-3 px-2">
                    <div className="flex flex-col">
                      <span className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">Actual Intake</span>
                      <span className="text-white font-bold text-sm">{item.actual} <span className="text-slate-600">{item.unit}</span></span>
                    </div>
                    <div className="flex flex-col text-right">
                      <span className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">Target Goal</span>
                      <span className="text-indigo-400 font-bold text-sm">{item.target} <span className="text-slate-600">{item.unit}</span></span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Right Side: 3D Visualization of "One Hand Target, One Hand Provided" */}
          <div className="relative h-[500px] flex items-center justify-center">
            {/* 3D Stage */}
            <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/5 to-transparent rounded-[3rem] border border-white/5"></div>
            
            <div className="relative w-full h-full flex flex-col items-center justify-center gap-8">
              {/* Target Hand Visual */}
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="flex items-center gap-8 w-full px-8"
              >
                <div className="flex-1 text-right">
                  <h4 className="text-indigo-400 font-black text-2xl mb-1">Target Hand</h4>
                  <p className="text-slate-500 text-sm font-medium">Your calculated goals for optimal health</p>
                </div>
                <div className="w-24 h-24 bg-indigo-500/20 rounded-3xl border border-indigo-500/30 flex items-center justify-center shadow-2xl shadow-indigo-500/20 relative group overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <Target className="w-12 h-12 text-indigo-400" />
                </div>
              </motion.div>

              {/* Connector */}
              <div className="h-16 w-1 bg-gradient-to-b from-indigo-500/50 via-slate-800 to-emerald-500/50 rounded-full"></div>

              {/* Provided Hand Visual */}
              <motion.div
                initial={{ opacity: 0, y: -50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="flex items-center gap-8 w-full px-8"
              >
                <div className="w-24 h-24 bg-emerald-500/20 rounded-3xl border border-emerald-500/30 flex items-center justify-center shadow-2xl shadow-emerald-500/20 relative group overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <TrendingUp className="w-12 h-12 text-emerald-400" />
                </div>
                <div className="flex-1">
                  <h4 className="text-emerald-400 font-black text-2xl mb-1">Provided Hand</h4>
                  <p className="text-slate-500 text-sm font-medium">Real-time tracking of what you've consumed</p>
                </div>
              </motion.div>

              {/* Floating 3D Stats */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-slate-900 rounded-full border border-slate-800 flex flex-col items-center justify-center shadow-[0_0_50px_rgba(79,70,229,0.2)] z-20">
                <span className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Total Score</span>
                <span className="text-5xl font-black text-white">
                  {Math.round(metrics.reduce((acc, m) => acc + Math.min(100, (m.actual / m.target) * 100), 0) / 4)}
                </span>
                <div className="mt-2 flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest">Active</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
