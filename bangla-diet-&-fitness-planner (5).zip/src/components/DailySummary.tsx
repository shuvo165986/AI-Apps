import React from 'react';
import { motion } from 'motion/react';
import { Target, Zap, Salad, Droplet, Flame, Trophy } from 'lucide-react';

interface DailySummaryProps {
  targets: {
    calories: string | number;
    protein: string;
    carbs: string;
    fats: string;
  };
  completedItems: Set<string>;
  totalItems: number;
}

export default function DailySummary({ targets, completedItems, totalItems }: DailySummaryProps) {
  const completionRate = totalItems > 0 ? (completedItems.size / totalItems) * 100 : 0;
  const score = Math.round(completionRate);

  const metrics = [
    { label: 'Calories', value: targets.calories, icon: <Flame className="w-4 h-4" />, color: 'bg-orange-500' },
    { label: 'Protein', value: targets.protein, icon: <Zap className="w-4 h-4" />, color: 'bg-emerald-500' },
    { label: 'Carbs', value: targets.carbs, icon: <Salad className="w-4 h-4" />, color: 'bg-blue-500' },
    { label: 'Fats', value: targets.fats, icon: <Droplet className="w-4 h-4" />, color: 'bg-amber-500' }
  ];

  return (
    <div className="my-10 bg-slate-900 rounded-3xl p-8 border border-slate-800 shadow-2xl overflow-hidden relative">
      {/* Background Glow */}
      <div className="absolute -top-24 -right-24 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl"></div>

      <div className="relative z-10 flex flex-col lg:flex-row gap-12 items-center">
        {/* Score Circle */}
        <div className="relative w-48 h-48 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90">
            <circle
              cx="96"
              cy="96"
              r="88"
              fill="none"
              stroke="currentColor"
              strokeWidth="12"
              className="text-slate-800"
            />
            <motion.circle
              cx="96"
              cy="96"
              r="88"
              fill="none"
              stroke="url(#summaryGradient)"
              strokeWidth="12"
              strokeDasharray="553"
              initial={{ strokeDashoffset: 553 }}
              animate={{ strokeDashoffset: 553 - (553 * completionRate) / 100 }}
              transition={{ duration: 2, ease: "easeOut" }}
              strokeLinecap="round"
            />
            <defs>
              <linearGradient id="summaryGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#10b981" />
                <stop offset="100%" stopColor="#3b82f6" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <motion.span 
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-5xl font-black text-white tracking-tighter"
            >
              {score}%
            </motion.span>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Daily Score</span>
          </div>
        </div>

        <div className="flex-grow w-full">
          <div className="p-6 bg-white/5 rounded-3xl border border-white/10 backdrop-blur-sm">
            <h3 className="text-xl font-bold text-white flex items-center gap-2 mb-4">
              <Trophy className="w-6 h-6 text-yellow-400" />
              Daily Achievement
            </h3>
            <p className="text-slate-300 leading-relaxed mb-6">
              You have completed <span className="text-emerald-400 font-bold">{completedItems.size}</span> out of <span className="text-indigo-400 font-bold">{totalItems}</span> tasks scheduled for today. 
              {score >= 80 ? " You're on fire! Keep this momentum going." : score >= 50 ? " Good progress! You're more than halfway there." : " Every small step counts. Keep moving forward!"}
            </p>
            <div className="flex items-center gap-4">
              <div className="px-4 py-2 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-widest">
                {score >= 90 ? 'Elite' : score >= 70 ? 'Pro' : 'Active'}
              </div>
              <div className="px-4 py-2 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-indigo-400 text-xs font-bold uppercase tracking-widest">
                Day {new Date().getDate()}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
