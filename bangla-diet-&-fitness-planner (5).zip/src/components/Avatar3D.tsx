import React from 'react';
import { motion } from 'motion/react';

interface Avatar3DProps {
  avatar: {
    bodyType: string;
    skinTone: string;
    outfit: string;
    energyState: 'low' | 'medium' | 'high';
  };
}

export default function Avatar3D({ avatar }: Avatar3DProps) {
  const skinColors: Record<string, string> = {
    'Warm': '#d2b48c',
    'Neutral': '#e0ac69',
    'Cool': '#8d5524',
    'default': '#e0ac69'
  };

  const skinColor = skinColors[avatar?.skinTone] || skinColors.default;

  return (
    <div className="w-full h-full flex items-center justify-center relative">
      {/* Energy Glow Effect */}
      <motion.div 
        animate={{ 
          scale: avatar?.energyState === 'high' ? [1, 1.2, 1] : [1, 1.05, 1],
          opacity: avatar?.energyState === 'high' ? [0.3, 0.6, 0.3] : [0.1, 0.3, 0.1]
        }}
        transition={{ duration: 3, repeat: Infinity }}
        className={`absolute w-32 h-32 md:w-48 md:h-48 rounded-full blur-[40px] md:blur-[60px] ${
          avatar?.energyState === 'high' ? 'bg-emerald-500' : 
          avatar?.energyState === 'medium' ? 'bg-indigo-500' : 'bg-amber-500'
        }`}
      />

      {/* Hybrid 3D Avatar (SVG based) */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative z-10 w-48 h-48 md:w-64 md:h-64"
      >
        <svg viewBox="0 0 200 200" className="w-full h-full drop-shadow-[0_10px_20px_rgba(0,0,0,0.3)] md:drop-shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
          {/* Head */}
          <motion.ellipse 
            animate={{ y: [0, -2, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            cx="100" cy="50" rx="25" ry="30" fill={skinColor} 
          />
          
          {/* Body */}
          <motion.path 
            animate={{ scaleY: [1, 1.02, 1] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            d="M70,85 Q100,75 130,85 L140,160 Q100,170 60,160 Z" 
            fill="#1e293b" 
          />
          
          {/* Arms */}
          <motion.path 
            animate={{ rotate: [-2, 2, -2] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            d="M70,90 L40,140" stroke={skinColor} strokeWidth="12" strokeLinecap="round" 
          />
          <motion.path 
            animate={{ rotate: [2, -2, 2] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            d="M130,90 L160,140" stroke={skinColor} strokeWidth="12" strokeLinecap="round" 
          />

          {/* Eyes */}
          <motion.g animate={{ scaleY: [1, 0.1, 1] }} transition={{ duration: 4, repeat: Infinity, repeatDelay: 3 }}>
            <circle cx="90" cy="45" r="2" fill="#000" />
            <circle cx="110" cy="45" r="2" fill="#000" />
          </motion.g>

          {/* Smile */}
          <path d="M90,60 Q100,68 110,60" fill="none" stroke="#000" strokeWidth="1.5" strokeLinecap="round" />
        </svg>

        {/* Floating Labels Removed */}
      </motion.div>
    </div>
  );
}
