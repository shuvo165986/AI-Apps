import React, { useState, useEffect } from 'react';
import { Trophy, Flame, Star, Award, CheckCircle2, Zap, Medal } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  unlocked: boolean;
  color: string;
}

export default function GamificationDashboard() {
  const [points, setPoints] = useState(0);
  const [streak, setStreak] = useState(0);
  const [showReward, setShowReward] = useState(false);
  const [lastReward, setLastReward] = useState('');

  const badges: Badge[] = [
    { 
      id: 'first_plan', 
      name: 'First Step', 
      description: 'Generated your first diet plan', 
      icon: <Zap className="w-6 h-6" />, 
      unlocked: points >= 100, 
      color: 'bg-yellow-500' 
    },
    { 
      id: 'protein_king', 
      name: 'Protein King', 
      description: 'Hit your protein target', 
      icon: <Medal className="w-6 h-6" />, 
      unlocked: points >= 500, 
      color: 'bg-blue-500' 
    },
    { 
      id: 'consistency', 
      name: 'Consistent', 
      description: 'Logged for 3 consecutive days', 
      icon: <Award className="w-6 h-6" />, 
      unlocked: streak >= 3, 
      color: 'bg-emerald-500' 
    },
    { 
      id: 'master', 
      name: 'Health Master', 
      description: 'Reached 1000 total points', 
      icon: <Trophy className="w-6 h-6" />, 
      unlocked: points >= 1000, 
      color: 'bg-purple-500' 
    },
  ];

  useEffect(() => {
    const savedPoints = localStorage.getItem('health_points');
    const savedStreak = localStorage.getItem('health_streak');
    if (savedPoints) setPoints(parseInt(savedPoints));
    if (savedStreak) setStreak(parseInt(savedStreak));
  }, []);

  useEffect(() => {
    // Listen for custom events to update points
    const handlePointsUpdate = (e: any) => {
      setPoints(prev => {
        const newPoints = prev + e.detail.amount;
        localStorage.setItem('health_points', newPoints.toString());
        return newPoints;
      });
      setLastReward(e.detail.reason);
      setShowReward(true);
      setTimeout(() => setShowReward(false), 3000);
    };

    window.addEventListener('update-points', handlePointsUpdate);
    return () => window.removeEventListener('update-points', handlePointsUpdate);
  }, []);

  return (
    <div className="my-8 relative">
      {/* Points & Streak Header */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="bg-slate-800/50 backdrop-blur-md p-6 rounded-2xl border border-slate-700 flex items-center justify-between shadow-xl"
        >
          <div className="flex items-center gap-4">
            <div className="p-3 bg-yellow-500/20 rounded-xl">
              <Star className="w-8 h-8 text-yellow-400 fill-yellow-400/20" />
            </div>
            <div>
              <p className="text-slate-400 text-sm font-medium uppercase tracking-wider">Total Points</p>
              <p className="text-3xl font-black text-white">{points}</p>
            </div>
          </div>
          <div className="h-12 w-1 bg-slate-700 rounded-full"></div>
        </motion.div>

        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="bg-slate-800/50 backdrop-blur-md p-6 rounded-2xl border border-slate-700 flex items-center justify-between shadow-xl"
        >
          <div className="flex items-center gap-4">
            <div className="p-3 bg-orange-500/20 rounded-xl">
              <Flame className="w-8 h-8 text-orange-400 fill-orange-400/20" />
            </div>
            <div>
              <p className="text-slate-400 text-sm font-medium uppercase tracking-wider">Current Streak</p>
              <p className="text-3xl font-black text-white">{streak} <span className="text-sm font-normal text-slate-400">Days</span></p>
            </div>
          </div>
          <div className="h-12 w-1 bg-slate-700 rounded-full"></div>
        </motion.div>

        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="bg-slate-800/50 backdrop-blur-md p-6 rounded-2xl border border-slate-700 flex items-center justify-between shadow-xl"
        >
          <div className="flex items-center gap-4">
            <div className="p-3 bg-emerald-500/20 rounded-xl">
              <Trophy className="w-8 h-8 text-emerald-400" />
            </div>
            <div>
              <p className="text-slate-400 text-sm font-medium uppercase tracking-wider">Rank</p>
              <p className="text-2xl font-black text-white">
                {points < 100 ? 'Beginner' : points < 500 ? 'Amateur' : points < 1000 ? 'Pro' : 'Elite'}
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Badges Section */}
      <div className="bg-slate-900/40 backdrop-blur-sm p-6 rounded-3xl border border-slate-800">
        <h3 className="text-white font-bold mb-6 flex items-center gap-2">
          <Award className="w-5 h-5 text-indigo-400" />
          Unlocked Milestones
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
          {badges.map((badge) => (
            <div key={badge.id} className="flex flex-col items-center text-center group">
              <div className={`relative w-16 h-16 rounded-2xl flex items-center justify-center mb-3 transition-all duration-500 ${badge.unlocked ? `${badge.color} shadow-[0_0_20px_rgba(0,0,0,0.3)]` : 'bg-slate-800 grayscale opacity-40'}`}>
                {badge.icon}
                {badge.unlocked && (
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-2 -right-2 bg-white rounded-full p-0.5"
                  >
                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  </motion.div>
                )}
              </div>
              <p className={`text-sm font-bold ${badge.unlocked ? 'text-white' : 'text-slate-600'}`}>{badge.name}</p>
              <p className="text-[10px] text-slate-500 mt-1 leading-tight">{badge.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Floating Reward Notification */}
      <AnimatePresence>
        {showReward && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50 bg-indigo-600 text-white px-6 py-4 rounded-2xl shadow-2xl border border-indigo-400 flex items-center gap-4"
          >
            <div className="bg-white/20 p-2 rounded-lg">
              <Star className="w-6 h-6 fill-white" />
            </div>
            <div>
              <p className="font-bold">Reward Unlocked!</p>
              <p className="text-sm text-indigo-100">{lastReward}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
