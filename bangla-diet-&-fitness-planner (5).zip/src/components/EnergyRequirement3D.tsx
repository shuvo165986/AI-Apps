import React from 'react';
import { Flame, Zap, Activity, Battery, Info } from 'lucide-react';
import { motion } from 'motion/react';

interface EnergyRequirementProps {
  formData: {
    gender: string;
    age: string;
    heightFt: string;
    heightIn: string;
    weight: string;
    activityLevel: string;
  };
}

export default function EnergyRequirement3D({ formData }: EnergyRequirementProps) {
  // Calculations (same as BodyAnalysis3D for consistency)
  const weight = parseFloat(formData.weight) || 0;
  const heightFt = parseFloat(formData.heightFt) || 0;
  const heightIn = parseFloat(formData.heightIn) || 0;
  const age = parseFloat(formData.age) || 0;
  
  const heightCm = (heightFt * 12 + heightIn) * 2.54;
  
  // BMR (Mifflin-St Jeor)
  let bmr = 0;
  if (formData.gender === 'Male') {
    bmr = (10 * weight) + (6.25 * heightCm) - (5 * age) + 5;
  } else {
    bmr = (10 * weight) + (6.25 * heightCm) - (5 * age) - 161;
  }

  // TDEE
  const activityMultipliers: Record<string, number> = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    high: 1.725,
    extreme: 1.9
  };
  const multiplier = activityMultipliers[formData.activityLevel] || 1.2;
  const tdee = Math.round(bmr * multiplier);
  const activityEnergy = tdee - Math.round(bmr);

  // Percentage for visualization
  const bmrPercentage = (bmr / tdee) * 100;
  const activityPercentage = (activityEnergy / tdee) * 100;

  const activityLabels: Record<string, string> = {
    sedentary: 'Sedentary (Office job, little exercise)',
    light: 'Lightly Active (Light exercise 1-3 days/week)',
    moderate: 'Moderately Active (Moderate exercise 3-5 days/week)',
    high: 'Very Active (Hard exercise 6-7 days/week)',
    extreme: 'Extra Active (Very hard exercise & physical job)'
  };

  return (
    <div className="my-10 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-3xl p-6 md:p-10 border border-slate-700 shadow-2xl relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-orange-500/10 rounded-full blur-[100px]"></div>
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-purple-500/10 rounded-full blur-[100px]"></div>
      </div>

      <div className="text-center mb-12 relative z-10">
        <h2 className="text-2xl md:text-3xl font-bold text-white flex items-center justify-center gap-3 tracking-tight">
          <Flame className="w-8 h-8 text-orange-400 drop-shadow-[0_0_15px_rgba(251,146,60,0.5)]" />
          Daily Energy Requirement
        </h2>
        <p className="text-slate-400 mt-2 font-light">
          Breakdown of your daily calorie expenditure
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center relative z-10">
        
        {/* Left: 3D Visualization of Energy Split */}
        <div className="flex flex-col items-center justify-center">
          <div className="relative w-64 h-64 md:w-80 md:h-80 flex items-center justify-center">
            {/* Outer Ring (TDEE) */}
            <svg className="w-full h-full transform -rotate-90 drop-shadow-[0_0_15px_rgba(0,0,0,0.5)]">
              <defs>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>
              <circle
                cx="50%"
                cy="50%"
                r="45%"
                className="stroke-slate-700/30 fill-none"
                strokeWidth="24"
              />
              {/* BMR Segment */}
              <motion.circle
                initial={{ strokeDasharray: "0 1000" }}
                animate={{ 
                  strokeDasharray: `${(bmrPercentage * 2.82).toFixed(1)} 1000`,
                  strokeWidth: [20, 22, 20]
                }}
                transition={{ 
                  strokeDasharray: { duration: 1.5, ease: "easeOut" },
                  strokeWidth: { repeat: Infinity, duration: 3, ease: "easeInOut" }
                }}
                cx="50%"
                cy="50%"
                r="45%"
                className="stroke-orange-500 fill-none"
                strokeWidth="20"
                strokeLinecap="round"
                style={{ filter: 'url(#glow)' }}
              />
              {/* Activity Segment */}
              <motion.circle
                initial={{ strokeDasharray: "0 1000", strokeDashoffset: 0 }}
                animate={{ 
                  strokeDasharray: `${(activityPercentage * 2.82).toFixed(1)} 1000`,
                  strokeDashoffset: -(bmrPercentage * 2.82),
                  strokeWidth: [20, 22, 20]
                }}
                transition={{ 
                  strokeDasharray: { duration: 1.5, delay: 0.5, ease: "easeOut" },
                  strokeDashoffset: { duration: 1.5, delay: 0.5, ease: "easeOut" },
                  strokeWidth: { repeat: Infinity, duration: 3, ease: "easeInOut", delay: 0.5 }
                }}
                cx="50%"
                cy="50%"
                r="45%"
                className="stroke-purple-500 fill-none"
                strokeWidth="20"
                strokeLinecap="round"
                style={{ filter: 'url(#glow)' }}
              />
            </svg>

            {/* Center Content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 1 }}
              >
                <Zap className="w-10 h-10 text-yellow-400 mb-2 animate-pulse" />
              </motion.div>
              <p className="text-4xl md:text-5xl font-black text-white tracking-tighter">
                {tdee}
              </p>
              <p className="text-slate-400 text-sm font-bold uppercase tracking-widest">Total Kcal</p>
            </div>

            {/* Floating 3D Icons */}
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
              className="absolute -top-4 right-10 bg-slate-800 p-3 rounded-2xl border border-slate-600 shadow-xl"
            >
              <Battery className="w-6 h-6 text-orange-400" />
            </motion.div>
            <motion.div 
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 3.5, ease: "easeInOut", delay: 0.5 }}
              className="absolute -bottom-4 left-10 bg-slate-800 p-3 rounded-2xl border border-slate-600 shadow-xl"
            >
              <Activity className="w-6 h-6 text-purple-400" />
            </motion.div>
          </div>
          
          <div className="mt-8 flex gap-6">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-orange-500"></div>
              <span className="text-xs text-slate-300 font-medium">BMR ({Math.round(bmrPercentage)}%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-purple-500"></div>
              <span className="text-xs text-slate-300 font-medium">Activity ({Math.round(activityPercentage)}%)</span>
            </div>
          </div>
        </div>

        {/* Right: Detailed Breakdown Cards */}
        <div className="flex flex-col gap-4">
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-slate-800/40 backdrop-blur-md p-5 rounded-2xl border border-slate-700 hover:bg-slate-800/60 transition-all"
          >
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-orange-400 font-bold flex items-center gap-2">
                <Battery className="w-4 h-4" />
                BMR (Basal Metabolic Rate)
              </h3>
              <span className="text-white font-mono font-bold">{Math.round(bmr)} kcal</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Energy burned while at complete rest to maintain vital functions like breathing and heartbeat.
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="bg-slate-800/40 backdrop-blur-md p-5 rounded-2xl border border-slate-700 hover:bg-slate-800/60 transition-all"
          >
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-purple-400 font-bold flex items-center gap-2">
                <Activity className="w-4 h-4" />
                Activity Expenditure
              </h3>
              <span className="text-white font-mono font-bold">+{activityEnergy} kcal</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Additional energy burned through your daily movement and exercise.
            </p>
            <div className="mt-3 pt-3 border-t border-slate-700/50 flex items-center gap-2">
              <Info className="w-3 h-3 text-slate-500" />
              <span className="text-[10px] text-slate-500 italic">{activityLabels[formData.activityLevel]}</span>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-4 bg-gradient-to-r from-orange-500/20 to-purple-500/20 p-6 rounded-2xl border border-white/10 text-center"
          >
            <p className="text-orange-400 text-sm font-bold mb-1">Total Daily Energy Expenditure (TDEE)</p>
            <p className="text-2xl font-black text-white tracking-tight">
              {tdee} Calories / Day
            </p>
          </motion.div>
        </div>

      </div>
    </div>
  );
}
