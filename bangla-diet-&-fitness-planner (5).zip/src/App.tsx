import { useState, useEffect, useRef, useMemo } from 'react';
import { motion } from 'motion/react';
import { GoogleGenAI } from '@google/genai';
import ReactMarkdown from 'react-markdown';
import BodyAnalysis3D from './components/BodyAnalysis3D';
import EnergyRequirement3D from './components/EnergyRequirement3D';
import NutritionExperience3D from './components/NutritionExperience3D';
import MealPlate from './components/MealPlate';
import DailySummary from './components/DailySummary';
import remarkGfm from 'remark-gfm';
import { Activity, Scale, User, Ruler, Weight, Target, Loader2, Salad, Droplets, Droplet, RefreshCw, Dumbbell, HeartPulse, Move, Flame, LineChart as LineChartIcon, History, Trash2, Plus, Download, Search, PlayCircle, Brain, Sparkles, Clock, Bell, BellOff, X, Check, Sun, Moon, Share2, Save } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, AreaChart, Area, PieChart, Pie, Cell, Legend, ComposedChart } from 'recharts';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const generateContentWithRetry = async (
  prompt: string, 
  primaryModel: string, 
  fallbackModel: string, 
  retries = 3
) => {
  let attempt = 0;
  while (attempt < retries) {
    try {
      const modelToUse = attempt < 2 ? primaryModel : fallbackModel;
      const response = await ai.models.generateContent({
        model: modelToUse,
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        }
      });
      return response;
    } catch (error: any) {
      attempt++;
      console.warn(`Attempt ${attempt} failed with model ${attempt <= 2 ? primaryModel : fallbackModel}:`, error.message);
      if (attempt >= retries) {
        throw new Error("Our AI is currently experiencing high demand. Please try again in a few moments.");
      }
      await delay(2000 + Math.random() * 1000); // 2-3 seconds delay
    }
  }
  throw new Error("Failed to generate content after multiple attempts.");
};

const renderExerciseIcon = (type: string) => {
  switch(type) {
    case 'cardio': return <HeartPulse className="w-6 h-6 text-red-500" />;
    case 'strength': return <Dumbbell className="w-6 h-6 text-purple-500" />;
    case 'stretch': return <Move className="w-6 h-6 text-blue-500" />;
    default: return <Activity className="w-6 h-6 text-emerald-500" />;
  }
};

interface MealOption {
  name: string;
  quantity: string;
  calories: number;
  protein: string;
  carbs: string;
  fats: string;
  micros: string;
  prepTime?: string;
  ingredients?: string[];
  tasteProfile?: string;
  plate_3d?: {
    layout: string;
    items: { name: string; size: 'small' | 'medium' | 'large'; emoji: string }[];
  };
}

interface SearchHistoryItem {
  id: string;
  timestamp: string;
  mealType: string;
  originalFood: string;
  alternative: MealOption;
}

interface ExerciseItem {
  name: string;
  durationOrReps: string;
  description: string;
  type: 'cardio' | 'strength' | 'stretch';
  emoji: string;
  videoLink?: string;
}

interface PlanData {
  analysis: string;
  energy: string;
  targets: {
    calories: string | number;
    protein: string;
    carbs: string;
    fats: string;
  };
  exergy: string;
  meals: {
    preBreakfast: MealOption[];
    breakfast: MealOption[];
    lunch: MealOption[];
    dinner: MealOption[];
    snacks: MealOption[];
  };
  summary: string;
  rda: string;
  exercise: {
    warmup: ExerciseItem[];
    main: ExerciseItem[];
    cooldown: ExerciseItem[];
  };
  water: string;
  insight: string;
  avatar?: {
    bodyType: string;
    skinTone: string;
    outfit: string;
    energyState: 'low' | 'medium' | 'high';
  };
  timeline?: {
    morning: string;
    noon: string;
    evening: string;
    night: string;
  };
  render_prompts?: Record<string, string>;
}

interface ProgressInsights {
  trendAnalysis: string;
  recommendations: string[];
  encouragement: string;
}

interface SleepLog {
  id: string;
  date: string;
  duration: number; // hours
  quality: 'Poor' | 'Fair' | 'Good' | 'Excellent';
}

export default function App() {
  const [formData, setFormData] = useState(() => {
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      try {
        return JSON.parse(savedProfile);
      } catch (e) {
        console.error('Failed to parse user profile', e);
      }
    }
    return {
      name: '',
      gender: 'Male',
      age: '',
      heightFt: '5',
      heightIn: '6',
      weight: '',
      activityLevel: 'moderate',
      goal: 'maintenance',
      waterTarget: '8',
      month: new Date().toLocaleString('default', { month: 'long' }),
      language: 'bn',
      exercisePreference: 'home_no_equipment',
      mealTimes: {
        breakfast: '08:00',
        lunch: '13:30',
        snacks: '17:00',
        dinner: '20:30'
      }
    };
  });

  const [isLoading, setIsLoading] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [isSearchingAlt, setIsSearchingAlt] = useState<string | null>(null);
  const [result, setResult] = useState<PlanData | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Water tracking state
  const [waterTarget, setWaterTarget] = useState<number>(0);
  const [waterConsumed, setWaterConsumed] = useState<number>(0);

  // Cache and debounce state
  const [planCache, setPlanCache] = useState<Record<string, PlanData>>({});
  const isGeneratingRef = useRef(false);

  // Meal swapping state
  const [selectedMeals, setSelectedMeals] = useState({
    preBreakfast: 0,
    breakfast: 0,
    lunch: 0,
    dinner: 0,
    snacks: 0
  });
  const [swapHistory, setSwapHistory] = useState<{type: keyof typeof selectedMeals, prevIndex: number}[]>([]);
  const [activeDropdown, setActiveDropdown] = useState<keyof typeof selectedMeals | null>(null);
  const [searchHistory, setSearchHistory] = useState<SearchHistoryItem[]>([]);

  // Progress tracking state
  const [activeTab, setActiveTab] = useState<'planner' | 'progress'>('planner');
  const [weightLogs, setWeightLogs] = useState<{id: string, date: string, weight: number}[]>([]);
  const [newWeight, setNewWeight] = useState('');
  const [newWeightDate, setNewWeightDate] = useState(new Date().toISOString().split('T')[0]);
  const [chartRange, setChartRange] = useState<'1w' | '1m' | '3m' | 'all'>('all');

  const [activityLogs, setActivityLogs] = useState<{id: string, date: string, activity: string, duration: number}[]>([]);
  const [newActivity, setNewActivity] = useState('');
  const [newActivityDuration, setNewActivityDuration] = useState('');
  const [newActivityDate, setNewActivityDate] = useState(new Date().toISOString().split('T')[0]);
  const [activityChartRange, setActivityChartRange] = useState<'1w' | '1m' | '3m' | 'all'>('all');

  const [nutrientLogs, setNutrientLogs] = useState<{id: string, date: string, calories: number, protein: number, carbs: number, fats: number}[]>([]);
  const [newNutrientCalories, setNewNutrientCalories] = useState('');
  const [newNutrientProtein, setNewNutrientProtein] = useState('');
  const [newNutrientCarbs, setNewNutrientCarbs] = useState('');
  const [newNutrientFats, setNewNutrientFats] = useState('');
  const [newNutrientDate, setNewNutrientDate] = useState(new Date().toISOString().split('T')[0]);
  const [nutrientChartRange, setNutrientChartRange] = useState<'1w' | '1m' | '3m' | 'all'>('all');

  const [sleepLogs, setSleepLogs] = useState<SleepLog[]>([]);
  const [newSleepDuration, setNewSleepDuration] = useState('');
  const [newSleepQuality, setNewSleepQuality] = useState<SleepLog['quality']>('Good');
  const [newSleepDate, setNewSleepDate] = useState(new Date().toISOString().split('T')[0]);
  const [sleepChartRange, setSleepChartRange] = useState<'1w' | '1m' | '3m' | 'all'>('all');

  const [progressInsights, setProgressInsights] = useState<ProgressInsights | null>(null);
  const [isGeneratingInsights, setIsGeneratingInsights] = useState(false);

  // Calculate today's nutritional intake
  const todayIntake = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const todaysLogs = nutrientLogs.filter(log => log.date === today);
    return todaysLogs.reduce((acc, log) => ({
      calories: acc.calories + log.calories,
      protein: acc.protein + log.protein,
      carbs: acc.carbs + log.carbs,
      fats: acc.fats + log.fats
    }), { calories: 0, protein: 0, carbs: 0, fats: 0 });
  }, [nutrientLogs]);

  // Reminders state
  const [remindersEnabled, setRemindersEnabled] = useState(false);
  const [activeReminders, setActiveReminders] = useState<string[]>([]);
  const [snoozedTimes, setSnoozedTimes] = useState<Record<string, string>>({});
  const [completedMeals, setCompletedMeals] = useState<Record<string, boolean>>({});

  // Dark mode state
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('darkMode');
    if (saved !== null) return JSON.parse(saved);
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  const getSeason = (month: string) => {
    const winter = ['December', 'January', 'February'];
    const summer = ['March', 'April', 'May'];
    const monsoon = ['June', 'July', 'August'];
    const autumn = ['September', 'October', 'November'];
    
    if (winter.includes(month)) return 'Winter (শীতকাল)';
    if (summer.includes(month)) return 'Summer (গ্রীষ্মকাল)';
    if (monsoon.includes(month)) return 'Monsoon (বর্ষাকাল)';
    if (autumn.includes(month)) return 'Autumn/Late Autumn (শরৎ/হেমন্ত)';
    return 'Unknown';
  };

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
  }, [darkMode]);

  useEffect(() => {
    const savedWeight = localStorage.getItem('weightLogs');
    if (savedWeight) {
      try {
        setWeightLogs(JSON.parse(savedWeight));
      } catch (e) {
        console.error("Failed to parse weight logs");
      }
    }
    const savedActivity = localStorage.getItem('activityLogs');
    if (savedActivity) {
      try {
        setActivityLogs(JSON.parse(savedActivity));
      } catch (e) {
        console.error("Failed to parse activity logs");
      }
    }
    const savedNutrients = localStorage.getItem('nutrientLogs');
    if (savedNutrients) {
      try {
        setNutrientLogs(JSON.parse(savedNutrients));
      } catch (e) {
        console.error("Failed to parse nutrient logs");
      }
    }
    const savedHistory = localStorage.getItem('searchHistory');
    if (savedHistory) {
      try {
        setSearchHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to parse search history");
      }
    }
    const savedReminders = localStorage.getItem('remindersEnabled');
    if (savedReminders) setRemindersEnabled(JSON.parse(savedReminders));
    const savedCompleted = localStorage.getItem('completedMeals');
    if (savedCompleted) setCompletedMeals(JSON.parse(savedCompleted));
    const savedSleep = localStorage.getItem('sleepLogs');
    if (savedSleep) {
      try {
        setSleepLogs(JSON.parse(savedSleep));
      } catch (e) {
        console.error("Failed to parse sleep logs");
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('weightLogs', JSON.stringify(weightLogs));
  }, [weightLogs]);

  useEffect(() => {
    localStorage.setItem('activityLogs', JSON.stringify(activityLogs));
  }, [activityLogs]);

  useEffect(() => {
    localStorage.setItem('nutrientLogs', JSON.stringify(nutrientLogs));
  }, [nutrientLogs]);

  useEffect(() => {
    localStorage.setItem('sleepLogs', JSON.stringify(sleepLogs));
  }, [sleepLogs]);

  useEffect(() => {
    localStorage.setItem('searchHistory', JSON.stringify(searchHistory));
  }, [searchHistory]);

  useEffect(() => {
    localStorage.setItem('remindersEnabled', JSON.stringify(remindersEnabled));
  }, [remindersEnabled]);

  useEffect(() => {
    localStorage.setItem('completedMeals', JSON.stringify(completedMeals));
  }, [completedMeals]);

  // Reminder checking logic
  useEffect(() => {
    if (!remindersEnabled) {
      setActiveReminders([]);
      return;
    }

    const checkReminders = () => {
      const now = new Date();
      const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      const today = now.toISOString().split('T')[0];

      setActiveReminders(prev => {
        const newActive = [...prev];
        let changed = false;

        Object.entries(formData.mealTimes).forEach(([meal, originalTime]) => {
          const timeToCheck = snoozedTimes[meal] || originalTime;
          const completionKey = `${today}-${meal}`;
          
          if (timeToCheck === currentTime && !completedMeals[completionKey] && !newActive.includes(meal)) {
            newActive.push(meal);
            changed = true;
          }
        });

        return changed ? newActive : prev;
      });
    };

    const interval = setInterval(checkReminders, 10000); // Check every 10 seconds
    checkReminders(); // Initial check

    return () => clearInterval(interval);
  }, [remindersEnabled, formData.mealTimes, snoozedTimes, completedMeals]);

  const dismissReminder = (meal: string) => {
    setActiveReminders(prev => prev.filter(m => m !== meal));
  };

  const markAsEaten = (meal: string) => {
    const today = new Date().toISOString().split('T')[0];
    setCompletedMeals(prev => ({ ...prev, [`${today}-${meal}`]: true }));
    setActiveReminders(prev => prev.filter(m => m !== meal));
  };

  const snoozeReminder = (meal: string) => {
    const now = new Date();
    now.setMinutes(now.getMinutes() + 15);
    const newTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    setSnoozedTimes(prev => ({ ...prev, [meal]: newTime }));
    setActiveReminders(prev => prev.filter(m => m !== meal));
  };

  const convertBanglaToEnglishNumber = (str: string) => {
    const banglaNumbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    let result = str;
    for (let i = 0; i < banglaNumbers.length; i++) {
      result = result.replace(new RegExp(banglaNumbers[i], 'g'), englishNumbers[i]);
    }
    // Remove any non-numeric characters except decimal point
    return result.replace(/[^0-9.]/g, '');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    // Convert Bangla numerals to English for numeric fields
    if (['age', 'heightFt', 'heightIn', 'weight'].includes(name)) {
      const englishValue = convertBanglaToEnglishNumber(value);
      setFormData((prev) => ({ ...prev, [name]: englishValue }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleTimeChange = (meal: keyof typeof formData.mealTimes, value: string) => {
    setFormData(prev => ({
      ...prev,
      mealTimes: {
        ...prev.mealTimes,
        [meal]: value
      }
    }));
    // Clear snooze if user manually changes time
    setSnoozedTimes(prev => {
      const newSnoozed = { ...prev };
      delete newSnoozed[meal as string];
      return newSnoozed;
    });
  };

  const handleAddWeight = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWeight || !newWeightDate) return;
    
    const englishWeight = convertBanglaToEnglishNumber(newWeight);
    if (!englishWeight) return;

    const log = {
      id: Date.now().toString(),
      date: newWeightDate,
      weight: parseFloat(englishWeight)
    };
    
    const updated = [...weightLogs, log].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    setWeightLogs(updated);
    setNewWeight('');
  };

  const handleDeleteWeight = (id: string) => {
    setWeightLogs(weightLogs.filter(log => log.id !== id));
  };

  const handleAddActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newActivity || !newActivityDuration || !newActivityDate) return;
    
    const englishDuration = convertBanglaToEnglishNumber(newActivityDuration);
    if (!englishDuration) return;

    const log = {
      id: Date.now().toString(),
      date: newActivityDate,
      activity: newActivity,
      duration: parseInt(englishDuration, 10)
    };
    
    const updated = [...activityLogs, log].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    setActivityLogs(updated);
    setNewActivity('');
    setNewActivityDuration('');
  };

  const handleDeleteActivity = (id: string) => {
    setActivityLogs(activityLogs.filter(log => log.id !== id));
  };

  const handleAddNutrient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNutrientCalories || !newNutrientDate) return;
    
    const engCal = convertBanglaToEnglishNumber(newNutrientCalories);
    const engPro = convertBanglaToEnglishNumber(newNutrientProtein) || '0';
    const engCarb = convertBanglaToEnglishNumber(newNutrientCarbs) || '0';
    const engFat = convertBanglaToEnglishNumber(newNutrientFats) || '0';
    
    if (!engCal) return;

    const log = {
      id: Date.now().toString(),
      date: newNutrientDate,
      calories: parseFloat(engCal),
      protein: parseFloat(engPro),
      carbs: parseFloat(engCarb),
      fats: parseFloat(engFat)
    };

    const updated = [...nutrientLogs, log].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    setNutrientLogs(updated);
    setNewNutrientCalories('');
    setNewNutrientProtein('');
    setNewNutrientCarbs('');
    setNewNutrientFats('');
  };

  const handleDeleteNutrient = (id: string) => {
    setNutrientLogs(nutrientLogs.filter(log => log.id !== id));
  };

  const handleAddSleep = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSleepDuration || !newSleepDate) return;
    
    const engDuration = convertBanglaToEnglishNumber(newSleepDuration);
    if (!engDuration) return;

    const log: SleepLog = {
      id: Date.now().toString(),
      date: newSleepDate,
      duration: parseFloat(engDuration),
      quality: newSleepQuality
    };

    const updated = [...sleepLogs, log].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    setSleepLogs(updated);
    setNewSleepDuration('');
    setNewSleepQuality('Good');
  };

  const handleDeleteSleep = (id: string) => {
    setSleepLogs(sleepLogs.filter(log => log.id !== id));
  };

  const getFilteredSleepLogs = () => {
    if (sleepChartRange === 'all') return sleepLogs;
    
    const now = new Date();
    const cutoff = new Date();
    if (sleepChartRange === '1w') cutoff.setDate(now.getDate() - 7);
    else if (sleepChartRange === '1m') cutoff.setMonth(now.getMonth() - 1);
    else if (sleepChartRange === '3m') cutoff.setMonth(now.getMonth() - 3);
    
    return sleepLogs.filter(log => new Date(log.date) >= cutoff);
  };

  const exportSleepCSV = () => {
    const headers = ['Date', 'Duration (hours)', 'Quality'];
    const rows = sleepLogs.map(log => [log.date, log.duration, log.quality]);
    
    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `sleep_logs_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getFilteredWeightLogs = () => {
    if (chartRange === 'all') return weightLogs;
    
    const now = new Date();
    const cutoff = new Date();
    
    if (chartRange === '1w') cutoff.setDate(now.getDate() - 7);
    if (chartRange === '1m') cutoff.setMonth(now.getMonth() - 1);
    if (chartRange === '3m') cutoff.setMonth(now.getMonth() - 3);
    
    return weightLogs.filter(log => new Date(log.date) >= cutoff);
  };

  const getFilteredActivityLogs = () => {
    if (activityChartRange === 'all') return activityLogs;
    
    const now = new Date();
    const cutoff = new Date();
    
    if (activityChartRange === '1w') cutoff.setDate(now.getDate() - 7);
    if (activityChartRange === '1m') cutoff.setMonth(now.getMonth() - 1);
    if (activityChartRange === '3m') cutoff.setMonth(now.getMonth() - 3);
    
    return activityLogs.filter(log => new Date(log.date) >= cutoff);
  };

  const getFilteredNutrientLogs = () => {
    if (nutrientChartRange === 'all') return nutrientLogs;
    
    const now = new Date();
    const cutoff = new Date();
    
    if (nutrientChartRange === '1w') cutoff.setDate(now.getDate() - 7);
    if (nutrientChartRange === '1m') cutoff.setMonth(now.getMonth() - 1);
    if (nutrientChartRange === '3m') cutoff.setMonth(now.getMonth() - 3);
    
    return nutrientLogs.filter(log => new Date(log.date) >= cutoff);
  };

  const exportWeightCSV = () => {
    if (weightLogs.length === 0) return;
    const headers = "Date,Weight (kg)\n";
    const rows = weightLogs.map(log => `${log.date},${log.weight}`).join('\n');
    const csvContent = "data:text/csv;charset=utf-8," + headers + rows;
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "weight_progress.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportActivityCSV = () => {
    if (activityLogs.length === 0) return;
    const headers = "Date,Activity,Duration (min)\n";
    const rows = activityLogs.map(log => `${log.date},"${log.activity}",${log.duration}`).join('\n');
    const csvContent = "data:text/csv;charset=utf-8," + headers + rows;
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "activity_logs.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportNutrientCSV = () => {
    if (nutrientLogs.length === 0) return;
    const headers = "Date,Calories,Protein(g),Carbs(g),Fats(g)\n";
    const rows = nutrientLogs.map(log => `${log.date},${log.calories},${log.protein},${log.carbs},${log.fats}`).join('\n');
    const csvContent = "data:text/csv;charset=utf-8," + headers + rows;
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "nutrient_logs.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const generateProgressInsights = async () => {
    if (weightLogs.length < 2 && activityLogs.length === 0) {
      alert("Please log some weight or activity data first to get meaningful insights.");
      return;
    }
    setIsGeneratingInsights(true);
    try {
      const prompt = `
      Act as a world-class fitness and nutrition coach.
      Please analyze the following user data and provide highly personalized, thoughtful, and high-quality insights. Take your time to generate the best possible advice.
      
      User Profile: Name ${formData.name || 'Student'}, Age ${formData.age}, Height ${formData.heightFt}'${formData.heightIn}", Current Goal: ${formData.goal}.
      Weight Logs (JSON): ${JSON.stringify(weightLogs.slice(-14))}
      Activity Logs (JSON): ${JSON.stringify(activityLogs.slice(-14))}
      Sleep Logs (JSON): ${JSON.stringify(sleepLogs.slice(-14))}

      CRITICAL INSTRUCTION: The entire response MUST be written in the Bengali (Bangla) language. Address the user by their name (${formData.name || 'Student'}) to make it highly personalized.
      Keep all points easy to read, but ensure the advice is deeply personalized and insightful based on their specific data.
      Specifically analyze how their sleep duration and quality might be impacting their exercise performance and weight goals.

      Provide a JSON response with the following schema:
      {
        "trendAnalysis": "Markdown string analyzing their weight trend and activity consistency over time. MUST be in Bangla and formatted as short bullet points. Provide deep, personalized insights.",
        "recommendations": ["Highly personalized actionable recommendation 1 in Bangla", "Highly personalized recommendation 2 in Bangla", "Highly personalized recommendation 3 in Bangla"],
        "encouragement": "A short, highly motivational and empathetic message in Bangla."
      }
      `;

      const response = await generateContentWithRetry(
        prompt,
        'gemini-3.1-pro-preview',
        'gemini-3-flash-preview'
      );
      
      let jsonText = response.text || "{}";
      jsonText = jsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
      
      const parsedData: ProgressInsights = JSON.parse(jsonText);
      setProgressInsights(parsedData);
    } catch (err: any) {
      console.error('Error generating insights:', err);
      if (err instanceof SyntaxError) {
        alert('The AI returned data in an invalid format. Please try generating again. (এআই ভুল ফরম্যাটে ডেটা দিয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।)');
      } else if (err.message && (err.message.toLowerCase().includes('network') || err.message.toLowerCase().includes('fetch'))) {
        alert('Network error. Please check your internet connection. (নেটওয়ার্ক সমস্যা। আপনার ইন্টারনেট সংযোগ পরীক্ষা করুন।)');
      } else {
        alert(err.message || 'Failed to generate insights. Please try again.');
      }
    } finally {
      setIsGeneratingInsights(false);
    }
  };

  const generatePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isGeneratingRef.current) return;
    
    // Auto-save profile when generating a plan
    localStorage.setItem('userProfile', JSON.stringify(formData));

    if (!formData.age || !formData.weight) {
      setError('Please fill in all required fields (Age and Weight).');
      return;
    }

    // Create a cache key based on inputs
    const cacheKey = JSON.stringify({
      name: formData.name,
      age: formData.age,
      weight: formData.weight,
      heightFt: formData.heightFt,
      heightIn: formData.heightIn,
      gender: formData.gender,
      goal: formData.goal,
      activityLevel: formData.activityLevel,
      exercisePreference: formData.exercisePreference,
      language: formData.language
    });

    if (planCache[cacheKey]) {
      setResult(planCache[cacheKey]);
      setLoadingProgress(100);
      return;
    }

    setIsLoading(true);
    isGeneratingRef.current = true;
    setError(null);
    setResult(null);
    setLoadingProgress(0);

    // Start progress simulation
    const progressInterval = setInterval(() => {
      setLoadingProgress(prev => {
        // Slow down as it gets closer to 95%
        const increment = prev < 50 ? 2 : prev < 80 ? 1 : 0.5;
        return prev >= 95 ? 95 : prev + increment;
      });
    }, 200);

    // Calculate Water Target (Liters = Weight in kg * 0.033 + Activity Bonus)
    let totalGlasses = 8;
    let totalLiters = 2;
    if (formData.waterTarget && !isNaN(parseInt(formData.waterTarget)) && parseInt(formData.waterTarget) > 0) {
      totalGlasses = parseInt(formData.waterTarget);
      totalLiters = totalGlasses * 0.25;
    } else {
      const weightKg = parseFloat(formData.weight) || 60;
      let activityBonus = 0;
      if (formData.activityLevel === 'moderate') activityBonus = 0.5;
      if (formData.activityLevel === 'high') activityBonus = 1.0;
      
      totalLiters = (weightKg * 0.033) + activityBonus;
      totalGlasses = Math.ceil(totalLiters / 0.25); // Assuming 250ml per glass
    }
    
    setWaterTarget(totalGlasses);
    setWaterConsumed(0);

    const currentSeason = getSeason(formData.month || 'January');
    console.log('Generating plan for language:', formData.language);

    const prompt = `
# 🥗 ADVANCED AI 3D NUTRITION EXPERIENCE GENERATOR
You are an **Advanced AI 3D Experience Designer, Nutrition Scientist, and Interactive UI Engineer**.
Your task is to transform a standard "Daily Diet Plan" into a **HYBRID 3D animated, customizable, and gamified experience**.

## 🎯 DESIGN STYLE
- **Food**: Semi-realistic (appetizing, detailed, slightly stylized)
- **UI**: Clean + modern + slightly playful
- **Animation**: Smooth, soft, satisfying
- **Goal**: Premium feel + engaging interaction

## 🧍 AVATAR SYSTEM
Generate a semi-realistic avatar based on:
- Age: ${formData.age}
- Gender: ${formData.gender}
- Height: ${formData.heightFt} ft ${formData.heightIn} inch
- Weight: ${formData.weight} kg
- Goal: ${formData.goal}
- Activity Level: ${formData.activityLevel}

## 📥 USER CONTEXT
- Name: ${formData.name || 'Student'}
- Region: Bangladesh
- Climate: ${currentSeason}
- Language: ${formData.language === 'bn' ? 'Bangla (Bengali)' : formData.language === 'en' ? 'English' : formData.language === 'hi' ? 'Hindi' : 'Chinese'}

## ⚠️ RULES & CRITICAL INSTRUCTIONS
1. You MUST return a valid JSON object. Do NOT wrap it in markdown blocks.
2. CRITICAL: The output MUST be in the language specified in the USER CONTEXT (Language) ONLY. Do NOT include any other languages. ALL text fields (including food names, descriptions, and ingredients) MUST be in this language, but the JSON keys MUST remain in English.
3. CRITICAL: For each meal type (preBreakfast, breakfast, lunch, dinner, snacks), provide at least 3 distinct options to allow for meal swapping.
   - For "snacks" (afternoon), one of the options MUST be a high-calorie weight gain shake containing dates, banana, and peanut.
4. CRITICAL: All numbers inside the JSON MUST be written in standard Arabic numerals (0-9).
5. For each meal option, include "plate_3d" data with a layout and items (name, size, emoji).
6. Include "avatar" data with bodyType, skinTone, outfit, and energyState.
7. Include "timeline" data for morning, noon, evening, and night.
8. Include "render_prompts" for high-quality 3D visualization.
9. CRITICAL: Generate fun daily activities and game-based exercises that are specifically tailored to the user's goal: ${formData.goal}.
   - If goal is "weight loss" (e.g., "lose weight"): Suggest high-energy, calorie-burning activities like "Dance-off Challenge", "HIIT Jump Rope", "Active Tag", or "Fast-paced Sports".
   - If goal is "weight gain" (e.g., "gain weight"): Suggest strength-building, muscle-toning, and moderate-intensity activities like "Bodyweight Circuit", "Yoga Flow", "Resistance Band Fun", or "Pilates".
10. CRITICAL: Include an "activities" field in the JSON output with a list of daily activities and game-based exercises, each with a name, description, and why it fits the user's goal.

## 📊 OUTPUT FORMAT (JSON SCHEMA TO FOLLOW)
{
  "analysis": "Markdown string for body analysis",
  "energy": "Markdown string for energy requirement",
  "targets": {
    "calories": "2000 kcal",
    "protein": "150g",
    "carbs": "200g",
    "fats": "65g"
  },
  "activities": [
    { "name": "Activity Name", "description": "Description", "goalFit": "Why it fits weight loss/gain" }
  ],
  "avatar": {
    "bodyType": "e.g., Ectomorph/Mesomorph/Endomorph based on BMI",
    "skinTone": "e.g., Warm/Neutral/Cool",
    "outfit": "Simple fitness wear description",
    "energyState": "medium"
  },
  "timeline": {
    "morning": "🌅 Morning (সকাল)",
    "noon": "☀️ Noon (দুপুর)",
    "evening": "🌇 Evening (বিকাল)",
    "night": "🌙 Night (রাত)"
  },
  "meals": {
    "preBreakfast": [
      { 
        "name": "...", "quantity": "...", "calories": 5, "protein": "0g", "carbs": "1g", "fats": "0g", "micros": "...", 
        "prepTime": "...", "ingredients": ["..."], "tasteProfile": "...",
        "plate_3d": {
          "layout": "circular",
          "items": [
            { "name": "Amloki Water", "size": "medium", "emoji": "🥤" }
          ]
        }
      }
    ],
    "breakfast": [
      { 
        "name": "...", "quantity": "...", "calories": 350, "protein": "15g", "carbs": "45g", "fats": "10g", "micros": "...", 
        "prepTime": "...", "ingredients": ["..."], "tasteProfile": "...",
        "plate_3d": {
          "layout": "divided",
          "items": [
            { "name": "Roti", "size": "large", "emoji": "🫓" },
            { "name": "Egg", "size": "medium", "emoji": "🍳" },
            { "name": "Vegetables", "size": "small", "emoji": "🥗" }
          ]
        }
      }
    ],
    "lunch": [ /* 3 options following the same format */ ],
    "dinner": [ /* 3 options following the same format */ ],
    "snacks": [ /* 3 options following the same format */ ]
  },
  "exercise": {
    "warmup": [...],
    "main": [...],
    "cooldown": [...]
  },
  "render_prompts": {
    "breakfast": "A semi-realistic 3D plate with roti, egg, and vegetables...",
    "lunch": "...",
    "dinner": "...",
    "snacks": "..."
  },
  "summary": "...",
  "rda": "...",
  "water": "...",
  "insight": "..."
}
`;

    try {
      const response = await generateContentWithRetry(
        prompt,
        'gemini-3-flash-preview',
        'gemini-3.1-flash-lite-preview'
      );
      
      let jsonText = response.text || "{}";
      jsonText = jsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
      
      // Convert Bengali numerals to standard Arabic numerals before parsing
      const bengaliNumerals = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
      jsonText = jsonText.replace(/[০-৯]/g, (w) => bengaliNumerals.indexOf(w).toString());
      
      const parsedData: PlanData = JSON.parse(jsonText);
      setResult(parsedData);
      setPlanCache(prev => ({ ...prev, [cacheKey]: parsedData }));
      setSelectedMeals({ preBreakfast: 0, breakfast: 0, lunch: 0, dinner: 0, snacks: 0 });
      setLoadingProgress(100);
      awardPoints(100, "Generated a new personalized diet plan! 🎯");
    } catch (err: any) {
      console.error('Error generating plan:', err);
      
      // Fallback plan if API fails completely
      const userName = formData.name ? `${formData.name}, ` : '';
      const fallbackPlan: PlanData = {
        analysis: `## 1. 📊 আপনার বর্তমান অবস্থা\n${userName}আপনার দেওয়া তথ্যের ভিত্তিতে আমরা একটি সাধারণ ডায়েট প্ল্যান তৈরি করেছি।`,
        energy: "## 2. ⚡ আপনার দৈনিক ক্যালরি চাহিদা\nসাধারণত একজন পূর্ণবয়স্ক মানুষের প্রতিদিন ২০০০-২৫০০ ক্যালরি প্রয়োজন হয়।",
        targets: { calories: "2000", protein: "100g", carbs: "250g", fats: "50g" },
        exergy: "## 3. 🎯 ম্যাক্রো নিউট্রিয়েন্ট টার্গেট\nসুষম খাবার খাওয়ার চেষ্টা করুন।",
        meals: {
          preBreakfast: [{ name: "উষ্ণ গরম পানি ও লেবু", quantity: "১ গ্লাস", calories: 5, protein: "0g", carbs: "1g", fats: "0g", micros: "Vitamin C", prepTime: "2 mins", ingredients: ["পানি", "লেবু"], tasteProfile: "Sour", plate_3d: { layout: "circular", items: [{ name: "Lemon Water", size: "medium", emoji: "🥤" }] } }],
          breakfast: [{ name: "রুটি, ডিম ভাজি ও সবজি", quantity: "২টি রুটি, ১টি ডিম", calories: 350, protein: "15g", carbs: "45g", fats: "12g", micros: "Iron, Vitamin A", prepTime: "15 mins", ingredients: ["আটা", "ডিম", "সবজি"], tasteProfile: "Savory", plate_3d: { layout: "divided", items: [{ name: "Roti", size: "large", emoji: "🫓" }, { name: "Egg", size: "medium", emoji: "🍳" }] } }],
          lunch: [{ name: "ভাত, ডাল, মাছ ও সবজি", quantity: "১.৫ কাপ ভাত, ১ টুকরো মাছ", calories: 500, protein: "25g", carbs: "65g", fats: "15g", micros: "Omega-3, Zinc", prepTime: "30 mins", ingredients: ["চাল", "ডাল", "মাছ", "সবজি"], tasteProfile: "Savory", plate_3d: { layout: "divided", items: [{ name: "Rice", size: "large", emoji: "🍚" }, { name: "Fish", size: "medium", emoji: "🐟" }] } }],
          snacks: [{ name: "ছোলা বুট বা মুড়ি মাখানো", quantity: "১ বাটি", calories: 150, protein: "5g", carbs: "25g", fats: "3g", micros: "Fiber", prepTime: "5 mins", ingredients: ["ছোলা", "মুড়ি"], tasteProfile: "Savory", plate_3d: { layout: "circular", items: [{ name: "Chana", size: "medium", emoji: "🥣" }] } }],
          dinner: [{ name: "ভাত বা রুটি, মুরগির মাংস ও ডাল", quantity: "১ কাপ ভাত, ২ টুকরো মাংস", calories: 450, protein: "30g", carbs: "50g", fats: "12g", micros: "Protein, B12", prepTime: "30 mins", ingredients: ["চাল/আটা", "মুরগি", "ডাল"], tasteProfile: "Savory", plate_3d: { layout: "divided", items: [{ name: "Rice", size: "large", emoji: "🍚" }, { name: "Chicken", size: "medium", emoji: "🍗" }] } }]
        },
        summary: "## 5. 📝 সারাংশ\nএটি একটি সাধারণ প্ল্যান। প্রতিদিন পর্যাপ্ত পানি পান করুন এবং ঘুমানোর চেষ্টা করুন।",
        rda: "## 6. 💊 ভিটামিন ও মিনারেল\nপ্রতিদিন তাজা ফলমূল ও শাকসবজি খাওয়ার চেষ্টা করুন।",
        exercise: {
          warmup: [{ name: "হাঁটা বা জগিং", durationOrReps: "৫ মিনিট", description: "শরীরের তাপমাত্রা বাড়াতে হালকা জগিং করুন।", type: "cardio", emoji: "🏃", videoLink: "https://www.youtube.com/results?search_query=warmup" }],
          main: [{ name: "বডিওয়েট স্কোয়াট ও পুশ-আপ", durationOrReps: "৩ সেট, ১০-১২ রেপস", description: "পেশী মজবুত করার জন্য এই ব্যায়ামগুলো করুন।", type: "strength", emoji: "🏋️", videoLink: "https://www.youtube.com/results?search_query=bodyweight+workout" }],
          cooldown: [{ name: "স্ট্রেচিং", durationOrReps: "৫ মিনিট", description: "ব্যায়াম শেষে পেশী শিথিল করতে স্ট্রেচিং করুন।", type: "stretch", emoji: "🧘", videoLink: "https://www.youtube.com/results?search_query=cooldown+stretches" }]
        },
        water: `## 8. 💧 পানি পানের লক্ষ্য\nপ্রতিদিন অন্তত ${totalLiters.toFixed(1)} লিটার বা ${totalGlasses} গ্লাস পানি পান করুন।`,
        insight: "## 9. 🧠 হেলথ ইনসাইট\n- **বর্তমান অবস্থা:** সাধারণ\n- **পরামর্শ:** নিয়মিত ব্যায়াম করুন এবং স্বাস্থ্যকর খাবার খান।",
        avatar: { bodyType: "Mesomorph", skinTone: "Neutral", outfit: "Fitness wear", energyState: "medium" },
        timeline: { morning: "🌅 Morning", noon: "☀️ Noon", evening: "🌇 Evening", night: "🌙 Night" }
      };
      
      setResult(fallbackPlan);
      setPlanCache(prev => ({ ...prev, [cacheKey]: fallbackPlan }));
      setSelectedMeals({ preBreakfast: 0, breakfast: 0, lunch: 0, dinner: 0, snacks: 0 });
      setLoadingProgress(100);
    } finally {
      clearInterval(progressInterval);
      setTimeout(() => {
        setIsLoading(false);
        isGeneratingRef.current = false;
      }, 500); // Give user a moment to see 100%
    }
  };

  const [isRegeneratingExercise, setIsRegeneratingExercise] = useState(false);
  const [completedItems, setCompletedItems] = useState<Set<string>>(new Set());

  const awardPoints = (amount: number, reason: string) => {
    window.dispatchEvent(new CustomEvent('update-points', { 
      detail: { amount, reason } 
    }));
  };

  const toggleItemCompletion = (id: string, points: number, reason: string) => {
    setCompletedItems(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
        awardPoints(points, reason);
      }
      return next;
    });
  };

  const regenerateExercisePlan = async () => {
    if (!result) return;
    setIsRegeneratingExercise(true);
    
    const prompt = `
    You are an expert fitness coach who believes exercise should be fun and engaging, like play.
    Create a new, customized exercise plan for a user with the following profile:
    - Name: ${formData.name || 'Student'}
    - Gender: ${formData.gender}
    - Age: ${formData.age}
    - Height: ${formData.heightFt} ft ${formData.heightIn} inch
    - Weight: ${formData.weight} kg
    - Activity level: ${formData.activityLevel}
    - Goal: ${formData.goal}
    - Exercise Preference: ${formData.exercisePreference}

    CRITICAL INSTRUCTION:
    1. You MUST return a valid JSON object. Do NOT wrap it in markdown blocks.
    2. The output MUST be in the BANGLA (Bengali) language, but the JSON keys MUST remain in English as specified.
    3. INSTEAD of traditional exercises (running, squats, gym workouts), suggest FUN, ENGAGING, and GAME-BASED physical activities that are suitable for students (e.g., football, badminton, skipping rope games, tag games, cycling challenges, dance challenges).
    4. Ensure the activities are effective for the user's goal (${formData.goal}).
       - For Weight Loss: Focus on high-intensity games (tag, fast-paced football).
       - For Muscle Building: Focus on activities involving resistance or bodyweight-like movements (climbing, active sports).
       - For Maintenance/General Fitness: Focus on a mix of cardio and fun movement.
    5. Each activity must mention a duration (e.g., 20 mins).
    6. Address the user by their name (${formData.name || 'Student'}) in the descriptions where appropriate.
    
    JSON SCHEMA TO FOLLOW:
    {
      "warmup": [{"name": "Activity name in Bangla", "durationOrReps": "e.g. 10 mins", "description": "Short description in Bangla", "type": "warmup", "emoji": "🏃", "videoLink": "https://www.youtube.com/results?search_query=..."}, ...],
      "main": [{"name": "Activity name in Bangla", "durationOrReps": "e.g. 30 mins", "description": "Short description in Bangla", "type": "strength", "emoji": "🏋️", "videoLink": "https://www.youtube.com/results?search_query=..."}, ...],
      "cooldown": [{"name": "Activity name in Bangla", "durationOrReps": "e.g. 5 mins", "description": "Short description in Bangla", "type": "cooldown", "emoji": "🧘", "videoLink": "https://www.youtube.com/results?search_query=..."}]
    }
    `;

    try {
      const response = await generateContentWithRetry(
        prompt,
        'gemini-3-flash-preview',
        'gemini-3.1-flash-lite-preview'
      );
      
      let jsonText = response.text || "{}";
      jsonText = jsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
      
      const newExercisePlan = JSON.parse(jsonText);
      
      setResult(prev => {
        if (!prev) return prev;
        return { ...prev, exercise: newExercisePlan };
      });
    } catch (err: any) {
      console.error('Error regenerating exercise plan:', err);
      alert(err.message || 'Failed to regenerate exercise plan. Please try again.');
    } finally {
      setIsRegeneratingExercise(false);
    }
  };

  const searchAlternative = async (mealType: keyof typeof selectedMeals, currentMeal: MealOption) => {
    if (!result) return;
    setIsSearchingAlt(mealType);
    
    const currentSeason = getSeason(formData.month || 'January');

    const prompt = `
    Find a single alternative Bangladeshi food item for the following meal:
    Name: ${currentMeal.name}
    Calories: ${currentMeal.calories}
    Protein: ${currentMeal.protein}
    Carbs: ${currentMeal.carbs}
    Fats: ${currentMeal.fats}

    The alternative MUST be a common Bangladeshi food, have very similar nutritional values (calories, protein, carbs, fats), and be appropriate for a ${mealType} meal.
    Consider factors like preparation time, ingredient availability, and user taste preferences when suggesting alternatives.
    CRITICAL: DO NOT suggest Oats (ওটস). Use local alternatives like flattened rice (চিড়া), puffed rice (মুড়ি), or roti (রুটি) instead.
    CRITICAL: Prioritize seasonal vegetables and fruits available in Bangladesh during ${currentSeason} (${formData.month || 'January'}).
    
    Return ONLY a JSON object representing the new meal option.
    
    JSON SCHEMA TO FOLLOW:
    {
      "name": "Food name in Bangla",
      "quantity": "Amount in Bangla",
      "calories": 300,
      "protein": "10g",
      "carbs": "40g",
      "fats": "5g",
      "micros": "Key vitamins in Bangla",
      "prepTime": "15 mins",
      "ingredients": ["Ingredient 1", "Ingredient 2"],
      "tasteProfile": "Savory"
    }
    `;

    try {
      const response = await generateContentWithRetry(
        prompt,
        'gemini-3-flash-preview',
        'gemini-3.1-flash-lite-preview'
      );
      
      let jsonText = response.text || "{}";
      jsonText = jsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
      
      const newMeal: MealOption = JSON.parse(jsonText);
      
      setResult(prev => {
        if (!prev) return prev;
        const updatedMeals = { ...prev.meals };
        updatedMeals[mealType] = [...updatedMeals[mealType], newMeal];
        return { ...prev, meals: updatedMeals };
      });
      
      // Select the newly added meal
      setSwapHistory(prev => [...prev, { type: mealType, prevIndex: selectedMeals[mealType] }]);
      setSelectedMeals(prev => ({
        ...prev,
        [mealType]: result.meals[mealType].length
      }));

      // Save to history
      const historyItem: SearchHistoryItem = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        mealType,
        originalFood: currentMeal.name,
        alternative: newMeal
      };
      setSearchHistory(prev => [historyItem, ...prev].slice(0, 50)); // Keep last 50 searches

    } catch (err: any) {
      console.error('Error finding alternative:', err);
      if (err instanceof SyntaxError) {
        alert('The AI returned data in an invalid format. Please try finding an alternative again. (এআই ভুল ফরম্যাটে ডেটা দিয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।)');
      } else if (err.message && (err.message.toLowerCase().includes('network') || err.message.toLowerCase().includes('fetch'))) {
        alert('Network error. Please check your internet connection. (নেটওয়ার্ক সমস্যা। আপনার ইন্টারনেট সংযোগ পরীক্ষা করুন।)');
      } else {
        alert(err.message || 'Failed to find an alternative. Please try again.');
      }
    } finally {
      setIsSearchingAlt(null);
    }
  };

  const handleReuseHistory = (item: SearchHistoryItem) => {
    if (!result) return;
    const mealType = item.mealType as keyof typeof result.meals;
    
    setResult(prev => {
      if (!prev) return prev;
      const updatedMeals = { ...prev.meals };
      const exists = updatedMeals[mealType].some(m => m.name === item.alternative.name);
      
      if (!exists) {
        updatedMeals[mealType] = [...updatedMeals[mealType], item.alternative];
      }
      return { ...prev, meals: updatedMeals };
    });
    
    const currentOptions = result.meals[mealType];
    const existingIndex = currentOptions.findIndex(m => m.name === item.alternative.name);
    const newIndex = existingIndex !== -1 ? existingIndex : currentOptions.length;
    
    setSelectedMeals(prev => ({
      ...prev,
      [mealType]: newIndex
    }));
  };

  const renderMealCard = (title: string, mealType: keyof typeof selectedMeals, options: MealOption[]) => {
    if (!options || options.length === 0) return null;
    const currentIndex = selectedMeals[mealType] % options.length;
    const currentMeal = options[currentIndex];
    const isDropdownOpen = activeDropdown === mealType;
    const mealId = `meal-${mealType}-${currentMeal.name}`;
    const isCompleted = completedItems.has(mealId);
    
    return (
      <motion.div 
        layout
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className={`bg-white border rounded-xl p-5 shadow-sm relative overflow-visible mb-4 transition-all duration-300 hover:shadow-md ${isCompleted ? 'border-emerald-500 bg-emerald-50/30' : 'border-emerald-200'}`}
      >
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <h4 className={`text-xl font-bold capitalize flex items-center gap-2 ${isCompleted ? 'text-emerald-900' : 'text-emerald-800'}`}>
              {title}
              <span className="text-sm font-normal text-slate-500 flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-md">
                <Clock className="w-3.5 h-3.5" />
                {formData.mealTimes[mealType]}
              </span>
            </h4>
            {isCompleted && (
              <span className="bg-emerald-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter flex items-center gap-1">
                <Check className="w-3 h-3" /> Done
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 relative">
            <button
              onClick={() => toggleItemCompletion(mealId, 50, `Finished ${title}! 🍽️`)}
              className={`p-2 rounded-full transition-all ${isCompleted ? 'bg-emerald-500 text-white shadow-lg' : 'bg-slate-100 text-slate-400 hover:bg-emerald-100 hover:text-emerald-600'}`}
              title={isCompleted ? "Mark as incomplete" : "Mark as finished"}
            >
              <Check className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setActiveDropdown(isDropdownOpen ? null : mealType)}
              className="flex items-center gap-1 text-sm bg-emerald-100 text-emerald-700 px-3 py-1.5 rounded-full hover:bg-emerald-200 transition-colors"
              title="Swap for an alternative meal"
            >
              <RefreshCw className="w-4 h-4" />
              Swap ({currentIndex + 1}/{options.length})
            </button>
            
            {isDropdownOpen && (
              <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 z-20 overflow-hidden">
                <div className="p-3 border-b border-slate-100 bg-slate-50">
                  <button 
                    onClick={() => {
                      searchAlternative(mealType, currentMeal);
                      setActiveDropdown(null);
                    }}
                    disabled={isSearchingAlt === mealType}
                    className="w-full flex items-center justify-center gap-2 text-sm bg-blue-100 text-blue-700 px-3 py-2 rounded-lg hover:bg-blue-200 transition-colors disabled:opacity-50 font-medium"
                  >
                    {isSearchingAlt === mealType ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                    Find New Alternative
                  </button>
                </div>
                <div className="max-h-60 overflow-y-auto">
                  {options.map((opt, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setSwapHistory(prev => [...prev, { type: mealType, prevIndex: currentIndex }]);
                        setSelectedMeals(prev => ({ ...prev, [mealType]: idx }));
                        setActiveDropdown(null);
                      }}
                      className={`w-full text-left px-4 py-3 text-sm hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0 ${idx === currentIndex ? 'bg-emerald-50 text-emerald-800' : 'text-slate-700'}`}
                    >
                      <div className="font-semibold">{opt.name}</div>
                      <div className="text-xs mt-1 opacity-80">{opt.calories} kcal | P: {opt.protein} | C: {opt.carbs} | F: {opt.fats}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row justify-between items-start gap-6">
            <div className="flex-grow space-y-4 w-full">
              <div className="flex justify-between items-start gap-4">
                <div>
                  <span className="font-semibold text-slate-800 text-lg">{currentMeal.name}</span>
                  <p className="text-slate-600 text-sm mt-1"><span className="font-medium">পরিমাণ (Quantity):</span> {currentMeal.quantity}</p>
                </div>
                <a 
                  href={`https://www.youtube.com/results?search_query=${encodeURIComponent(currentMeal.name + ' bangladeshi recipe')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-shrink-0 inline-flex items-center gap-1.5 text-xs font-medium text-red-600 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg transition-colors border border-red-100"
                >
                  <PlayCircle className="w-4 h-4" />
                  Recipe
                </a>
                <button
                  onClick={() => searchAlternative(mealType, currentMeal)}
                  disabled={isSearchingAlt === mealType}
                  className="flex-shrink-0 inline-flex items-center gap-1.5 text-xs font-medium text-blue-600 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition-colors border border-blue-100 disabled:opacity-50"
                >
                  {isSearchingAlt === mealType ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                  Try Again
                </button>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center text-sm">
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                  <div className="text-slate-500 text-xs mb-1">Calories</div>
                  <div className="font-semibold text-slate-700">{currentMeal.calories}</div>
                </div>
                <div className="bg-emerald-50 p-2 rounded-lg border border-emerald-100">
                  <div className="text-emerald-600 text-xs mb-1">Protein</div>
                  <div className="font-semibold text-emerald-700">{currentMeal.protein}</div>
                </div>
                <div className="bg-blue-50 p-2 rounded-lg border border-blue-100">
                  <div className="text-blue-600 text-xs mb-1">Carbs</div>
                  <div className="font-semibold text-blue-700">{currentMeal.carbs}</div>
                </div>
                <div className="bg-amber-50 p-2 rounded-lg border border-amber-100">
                  <div className="text-amber-600 text-xs mb-1">Fats</div>
                  <div className="font-semibold text-amber-700">{currentMeal.fats}</div>
                </div>
              </div>
            </div>
            
            {/* Animated Plate */}
            <div className="flex-shrink-0 self-center md:self-start bg-slate-50 p-3 rounded-3xl border border-slate-100 shadow-inner">
              <MealPlate type={mealType} isCompleted={isCompleted} />
            </div>
          </div>
          
          {(currentMeal.prepTime || currentMeal.tasteProfile) && (
            <div className="flex flex-wrap gap-2 mt-3">
              {currentMeal.prepTime && (
                <span className="inline-flex items-center gap-1 text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-md">
                  <Clock className="w-3 h-3" /> {currentMeal.prepTime}
                </span>
              )}
              {currentMeal.tasteProfile && (
                <span className="inline-flex items-center gap-1 text-xs bg-purple-50 text-purple-600 px-2 py-1 rounded-md border border-purple-100">
                  <Sparkles className="w-3 h-3" /> {currentMeal.tasteProfile}
                </span>
              )}
            </div>
          )}

          {currentMeal.ingredients && currentMeal.ingredients.length > 0 && (
            <div className="mt-3 text-sm text-slate-600">
              <span className="font-medium text-slate-700">উপকরণ (Ingredients):</span> {currentMeal.ingredients.join(', ')}
            </div>
          )}

          <div className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-100 mt-3">
            <span className="font-medium text-slate-700">Micronutrients:</span> {currentMeal.micros}
          </div>
        </div>
      </motion.div>
    );
  };

  const saveProfile = () => {
    localStorage.setItem('userProfile', JSON.stringify(formData));
    alert('প্রোফাইল সেভ করা হয়েছে! (Profile saved successfully!)');
  };

  const handleMealSwap = (type: string, index: number) => {
    setSelectedMeals(prev => ({ ...prev, [type]: index }));
  };

  const undoSwap = () => {
    if (swapHistory.length === 0) return;
    
    const lastSwap = swapHistory[swapHistory.length - 1];
    setSelectedMeals(prev => ({ ...prev, [lastSwap.type]: lastSwap.prevIndex }));
    setSwapHistory(prev => prev.slice(0, -1));
  };

  const handleSharePlan = async () => {
    if (!result) return;
    
    const planText = `
আমার ব্যক্তিগত ডায়েট এবং ব্যায়ামের প্ল্যান 🥗🏃‍♂️

লক্ষ্য ক্যালরি: ${result.targets?.calories || 'প্রযোজ্য নয়'}
প্রোটিন: ${result.targets?.protein || 'প্রযোজ্য নয়'} | শর্করা: ${result.targets?.carbs || 'প্রযোজ্য নয়'} | ফ্যাট: ${result.targets?.fats || 'প্রযোজ্য নয়'}

🍽️ ডায়েট প্ল্যান:
- সকালের নাস্তা: ${result.meals.breakfast.map(m => m.name).join(', ')}
- দুপুরের খাবার: ${result.meals.lunch.map(m => m.name).join(', ')}
- বিকালের নাস্তা: ${result.meals.snacks.map(m => m.name).join(', ')}
- রাতের খাবার: ${result.meals.dinner.map(m => m.name).join(', ')}

💧 পানির লক্ষ্য: ${waterTarget} গ্লাস

💪 ব্যায়ামের রুটিন:
- ওয়ার্ম-আপ: ${result.exercise.warmup.map(e => e.name).join(', ')}
- মূল ব্যায়াম: ${result.exercise.main.map(e => e.name).join(', ')}
- কুল-ডাউন: ${result.exercise.cooldown.map(e => e.name).join(', ')}

এআই ডায়েট এবং ফিটনেস প্ল্যানার দ্বারা তৈরি!
    `.trim();

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'আমার ডায়েট এবং ব্যায়ামের প্ল্যান',
          text: planText,
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      navigator.clipboard.writeText(planText);
      alert('প্ল্যানটি ক্লিপবোর্ডে কপি করা হয়েছে!');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans transition-colors duration-300">
      <header className="bg-emerald-600 text-white py-6 shadow-md transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Salad className="w-8 h-8" />
            <h1 className="text-2xl font-bold tracking-tight">Bangla Diet & Fitness Planner</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/20 shadow-lg group hover:bg-white/20 transition-all cursor-pointer">
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center text-xl shadow-inner border-2 border-white/30 group-hover:scale-110 transition-transform">
                  😎
                </div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-slate-900 rounded-full shadow-sm"></div>
              </div>
              <div className="hidden sm:block">
                <div className="text-xs font-black text-indigo-200 uppercase tracking-widest leading-none mb-1">Pro User</div>
                <div className="text-sm font-bold text-white leading-none">Fitness Enthusiast</div>
              </div>
            </div>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-full hover:bg-emerald-700 transition-colors"
              aria-label="Toggle Dark Mode"
            >
              {darkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-center border-b border-slate-200 mb-8">
          <button 
            onClick={() => setActiveTab('planner')} 
            className={`px-6 py-3 font-medium flex items-center gap-2 transition-colors ${activeTab === 'planner' ? 'text-emerald-600 border-b-2 border-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <Salad className="w-4 h-4" /> Diet Planner
          </button>
          <button 
            onClick={() => setActiveTab('progress')} 
            className={`px-6 py-3 font-medium flex items-center gap-2 transition-colors ${activeTab === 'progress' ? 'text-emerald-600 border-b-2 border-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <LineChartIcon className="w-4 h-4" /> Progress Tracker
          </button>
        </div>

        {activeTab === 'planner' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Form Section */}
            <div className="lg:col-span-4 space-y-6">
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold flex items-center gap-2 text-slate-800">
                  <User className="w-5 h-5 text-emerald-600" />
                  Personal Details
                </h2>
                <button
                  type="button"
                  onClick={saveProfile}
                  className="text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1 bg-emerald-50 px-3 py-1.5 rounded-lg transition-colors"
                  title="Save profile details for next time"
                >
                  <Save className="w-4 h-4" /> Save
                </button>
              </div>
              
              <form onSubmit={generatePlan} className="space-y-5">
                {/* Language */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Language (ভাষা)</label>
                  <select
                    name="language"
                    value={formData.language}
                    onChange={handleChange}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  >
                    <option value="bn">Bangla (বাংলা)</option>
                    <option value="en">English</option>
                    <option value="hi">Hindi (हिन्दी)</option>
                    <option value="zh">Chinese (中文)</option>
                  </select>
                </div>

                {/* Name */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Name (Optional)</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name || ''}
                    onChange={handleChange}
                    placeholder="Enter your name"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  />
                </div>

                {/* Gender */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Gender</label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>

                {/* Age */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Age (years)</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    name="age"
                    value={formData.age}
                    onChange={handleChange}
                    placeholder="e.g., 25"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    required
                  />
                </div>

                {/* Height */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-1">
                    <Ruler className="w-4 h-4" /> Height
                  </label>
                  <div className="flex gap-3">
                    <div className="flex-1">
                      <div className="flex items-center border border-slate-300 rounded-lg overflow-hidden focus-within:ring-2 focus-within:ring-emerald-500 focus-within:border-emerald-500 transition-all">
                        <input
                          type="text"
                          inputMode="numeric"
                          name="heightFt"
                          value={formData.heightFt}
                          onChange={handleChange}
                          className="w-full px-3 py-2 outline-none"
                          required
                        />
                        <span className="bg-slate-100 px-3 py-2 text-slate-500 text-sm border-l border-slate-300">ft</span>
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center border border-slate-300 rounded-lg overflow-hidden focus-within:ring-2 focus-within:ring-emerald-500 focus-within:border-emerald-500 transition-all">
                        <input
                          type="text"
                          inputMode="numeric"
                          name="heightIn"
                          value={formData.heightIn}
                          onChange={handleChange}
                          className="w-full px-3 py-2 outline-none"
                          required
                        />
                        <span className="bg-slate-100 px-3 py-2 text-slate-500 text-sm border-l border-slate-300">in</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Weight */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-1">
                    <Weight className="w-4 h-4" /> Weight (kg)
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    name="weight"
                    value={formData.weight}
                    onChange={handleChange}
                    placeholder="e.g., 65"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    required
                  />
                </div>

                {/* Activity Level */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-1">
                    <Activity className="w-4 h-4" /> Activity Level
                  </label>
                  <select
                    name="activityLevel"
                    value={formData.activityLevel}
                    onChange={handleChange}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  >
                    <option value="low">Low (Sedentary, little to no exercise)</option>
                    <option value="moderate">Moderate (Exercise 3-5 days/week)</option>
                    <option value="high">High (Heavy exercise 6-7 days/week)</option>
                  </select>
                </div>

                {/* Goal */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-1">
                    <Target className="w-4 h-4" /> Goal
                  </label>
                  <select
                    name="goal"
                    value={formData.goal}
                    onChange={handleChange}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  >
                    <option value="weight loss">Weight Loss</option>
                    <option value="maintenance">Maintenance</option>
                    <option value="weight gain">Weight Gain</option>
                  </select>
                </div>

                {/* Month/Season */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-1">
                    <Sun className="w-4 h-4" /> Current Month (বর্তমান মাস)
                  </label>
                  <select
                    name="month"
                    value={formData.month || 'January'}
                    onChange={handleChange}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  >
                    {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(m => (
                      <option key={m} value={m}>{m} ({getSeason(m).split(' ')[0]})</option>
                    ))}
                  </select>
                </div>

                {/* Water Target */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-1">
                    <Droplet className="w-4 h-4 text-blue-500" /> Daily Water Target (Glasses)
                  </label>
                  <input
                    type="number"
                    name="waterTarget"
                    value={formData.waterTarget}
                    onChange={handleChange}
                    placeholder="e.g., 8"
                    min="1"
                    max="30"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  />
                  <p className="text-xs text-slate-500 mt-1">Leave empty for automatic calculation</p>
                </div>

                {/* Exercise Preference */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-1">
                    <Dumbbell className="w-4 h-4 text-orange-500" /> Exercise Preference
                  </label>
                  <select
                    name="exercisePreference"
                    value={formData.exercisePreference}
                    onChange={handleChange}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  >
                    <option value="home_no_equipment">Home Workout (No Equipment)</option>
                    <option value="gym">Gym Workout</option>
                    <option value="yoga">Yoga & Flexibility</option>
                    <option value="cardio">Cardio Focus</option>
                    <option value="light_walking">Light Walking / Mobility</option>
                  </select>
                </div>

                {/* Meal Timings */}
                <div className="pt-4 border-t border-slate-200">
                  <div className="flex justify-between items-center mb-3">
                    <label className="text-sm font-medium text-slate-700 flex items-center gap-1">
                      <Clock className="w-4 h-4" /> Meal Timings
                    </label>
                    <button
                      type="button"
                      onClick={() => setRemindersEnabled(!remindersEnabled)}
                      className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-full transition-colors font-medium ${remindersEnabled ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                    >
                      {remindersEnabled ? <Bell className="w-3.5 h-3.5" /> : <BellOff className="w-3.5 h-3.5" />}
                      {remindersEnabled ? 'Reminders On' : 'Reminders Off'}
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-500 mb-1">Breakfast</label>
                      <input
                        type="time"
                        value={formData.mealTimes.breakfast}
                        onChange={(e) => handleTimeChange('breakfast', e.target.value)}
                        className="w-full rounded-lg border-slate-300 border px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-500 mb-1">Lunch</label>
                      <input
                        type="time"
                        value={formData.mealTimes.lunch}
                        onChange={(e) => handleTimeChange('lunch', e.target.value)}
                        className="w-full rounded-lg border-slate-300 border px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-500 mb-1">Snacks</label>
                      <input
                        type="time"
                        value={formData.mealTimes.snacks}
                        onChange={(e) => handleTimeChange('snacks', e.target.value)}
                        className="w-full rounded-lg border-slate-300 border px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-500 mb-1">Dinner</label>
                      <input
                        type="time"
                        value={formData.mealTimes.dinner}
                        onChange={(e) => handleTimeChange('dinner', e.target.value)}
                        className="w-full rounded-lg border-slate-300 border px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                        required
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed mt-4 shadow-sm"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Generating Plan...
                    </>
                  ) : (
                    'Generate My Plan'
                  )}
                </button>
              </form>
              
              {error && (
                <div className="mt-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm border border-red-200">
                  {error}
                </div>
              )}
            </div>
          </div>

          {/* Results Section */}
          <div className="lg:col-span-8">
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 lg:p-8 min-h-[600px]">
              {isLoading ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-10 py-20">
                  <div className="relative w-48 h-48 flex items-center justify-center" style={{ perspective: '1000px' }}>
                    {/* 3D Rings */}
                    <div className="absolute inset-0" style={{ transform: 'rotateX(60deg) rotateY(0deg)' }}>
                      <div className="w-full h-full rounded-full border-4 border-t-emerald-500 border-b-emerald-500 border-l-transparent border-r-transparent animate-spin" style={{ animationDuration: '2s' }}></div>
                    </div>
                    <div className="absolute inset-2" style={{ transform: 'rotateX(40deg) rotateY(60deg)' }}>
                      <div className="w-full h-full rounded-full border-4 border-t-emerald-400 border-b-emerald-400 border-l-transparent border-r-transparent animate-spin" style={{ animationDuration: '3s', animationDirection: 'reverse' }}></div>
                    </div>
                    <div className="absolute inset-4" style={{ transform: 'rotateX(80deg) rotateY(30deg)' }}>
                      <div className="w-full h-full rounded-full border-4 border-t-emerald-300 border-b-emerald-300 border-l-transparent border-r-transparent animate-spin" style={{ animationDuration: '4s' }}></div>
                    </div>
                    <div className="absolute inset-6" style={{ transform: 'rotateX(20deg) rotateY(80deg)' }}>
                      <div className="w-full h-full rounded-full border-4 border-t-emerald-200 border-b-emerald-200 border-l-transparent border-r-transparent animate-spin" style={{ animationDuration: '2.5s' }}></div>
                    </div>

                    {/* Center Progress */}
                    <div className="absolute flex flex-col items-center justify-center bg-white/80 rounded-full w-24 h-24 backdrop-blur-sm shadow-sm border border-emerald-100">
                      <span className="text-3xl font-bold text-emerald-600">{Math.floor(loadingProgress)}%</span>
                    </div>
                  </div>

                  <div className="text-center space-y-3">
                    <p className="text-xl font-medium text-slate-700 animate-pulse">Crafting your personalized diet plan...</p>
                    <p className="text-sm text-slate-500 max-w-sm mx-auto">
                      {loadingProgress < 30 && "Analyzing physical profile..."}
                      {loadingProgress >= 30 && loadingProgress < 60 && "Calculating BMR & TDEE..."}
                      {loadingProgress >= 60 && loadingProgress < 90 && "Selecting optimal Bangladeshi foods..."}
                      {loadingProgress >= 90 && "Finalizing your plan..."}
                    </p>
                    <div className="inline-block mt-4 px-4 py-2 bg-slate-100 rounded-full border border-slate-200">
                      <p className="text-xs text-slate-600 font-mono flex items-center gap-2">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        Estimated time remaining: <span className="font-bold">{Math.max(0, Math.ceil(15 * (1 - loadingProgress / 100)))}s</span>
                      </p>
                    </div>
                  </div>
                </div>
              ) : result ? (
                <div className="space-y-8">
                  {/* Action Bar */}
                  <div className="flex justify-end">
                    <button 
                      onClick={handleSharePlan}
                      className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors shadow-sm font-medium"
                    >
                      <Share2 className="w-4 h-4" /> প্ল্যানটি শেয়ার করুন
                    </button>
                  </div>

                  {/* Water Tracker UI */}
                  <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100 shadow-sm">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-bold text-blue-800 flex items-center gap-2">
                        <Droplets className="w-6 h-6" />
                        Daily Water Tracker
                      </h3>
                      <div className="text-right">
                        <p className="text-blue-900 font-medium">Target: {waterTarget} glasses ({(waterTarget * 0.25).toFixed(1)}L)</p>
                        <p className="text-blue-700 text-sm">Consumed: {waterConsumed} glasses</p>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-3 mb-4">
                      {Array.from({ length: Math.max(waterTarget, waterConsumed + 1) }).map((_, i) => {
                        const isConsumed = i < waterConsumed;
                        return (
                          <button
                            key={i}
                            onClick={() => {
                              const newAmount = i + 1 === waterConsumed ? i : i + 1;
                              if (newAmount > waterConsumed) {
                                awardPoints(10, "Stayed hydrated! 💧");
                              }
                              setWaterConsumed(newAmount);
                            }}
                            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 ${
                              isConsumed 
                                ? 'bg-blue-500 text-white shadow-md scale-105' 
                                : 'bg-white text-blue-300 border-2 border-dashed border-blue-200 hover:bg-blue-100 hover:border-blue-300 hover:text-blue-400'
                            }`}
                            title={isConsumed ? "Mark as unconsumed" : "Mark as consumed"}
                          >
                            <Droplet className={`w-6 h-6 ${isConsumed ? 'fill-current' : ''}`} />
                          </button>
                        );
                      })}
                    </div>
                    
                    <div className="w-full bg-blue-200 rounded-full h-3 overflow-hidden">
                      <div 
                        className="bg-blue-500 h-3 rounded-full transition-all duration-500 ease-out" 
                        style={{ width: `${Math.min(100, (waterConsumed / waterTarget) * 100)}%` }}
                      ></div>
                    </div>
                    {waterConsumed >= waterTarget && (
                      <p className="text-sm text-blue-600 font-medium mt-3 text-center">
                        🎉 Great job! You've reached your daily hydration goal.
                      </p>
                    )}
                  </div>

                  {/* 3D Body Analysis Section */}
                  <BodyAnalysis3D formData={formData} />
                  
                  {/* 3D Energy Requirement Section */}
                  <EnergyRequirement3D formData={formData} />

                  {/* 3D Target Metrics Section (Removed) */}

                  {/* Daily Summary Section */}
                  {result.targets && (
                    <DailySummary 
                      targets={result.targets} 
                      completedItems={completedItems} 
                      totalItems={
                        (result.meals.preBreakfast ? 1 : 0) + 
                        1 + 1 + 1 + 1 + // Breakfast, Lunch, Snacks, Dinner
                        result.exercise.warmup.length + 
                        result.exercise.main.length + 
                        result.exercise.cooldown.length
                      }
                    />
                  )}

                  {/* Interactive Meals Section (3D Experience) */}
                  <div className="my-16">
                    <NutritionExperience3D 
                      data={result} 
                      selectedMeals={selectedMeals} 
                      onSwap={handleMealSwap} 
                    />
                  </div>

                  {/* Markdown Sections 5-6 */}
                  <div className="prose prose-slate prose-emerald dark:prose-invert max-w-none prose-headings:font-bold prose-headings:text-black dark:prose-headings:text-white prose-h1:text-3xl prose-h2:text-2xl prose-h2:mt-8 prose-h2:mb-4 prose-h2:pb-2 prose-h2:border-b prose-h2:border-slate-100 prose-table:w-full prose-th:bg-emerald-50 dark:prose-th:bg-emerald-900/30 prose-th:p-3 prose-td:p-3 prose-tr:border-b prose-tr:border-slate-200 prose-p:text-black prose-li:text-black prose-td:text-black prose-th:text-black dark:prose-p:text-white dark:prose-li:text-white dark:prose-td:text-white dark:prose-th:text-white prose-strong:text-black dark:prose-strong:text-white">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{result.summary}</ReactMarkdown>
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{result.rda}</ReactMarkdown>
                  </div>

                  {/* Exercise Plan UI */}
                  <div className="my-8">
                    <div className="flex justify-between items-end mb-6 border-b border-slate-200 pb-2">
                      <h2 className="text-2xl font-bold text-slate-900">💪 FUN DAILY ACTIVITY PLAN (খেলাধুলা ও মজার ব্যায়াম)</h2>
                    </div>
                    
                    <div className="space-y-6">
                      <div className="bg-orange-50 rounded-xl p-5 border border-orange-100">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {[
                            { name: "ফুটবল বা ব্যাডমিন্টন চ্যালেঞ্জ", duration: "৩০ মিনিট", desc: "বন্ধুদের সাথে মাঠে বা ছাদে ফুটবল খেলুন অথবা ব্যাডমিন্টন খেলুন।", emoji: "⚽", video: "https://www.youtube.com/results?search_query=football+or+badminton+skills+for+beginners" },
                            { name: "স্কিপিং রোপ গেম", duration: "১৫ মিনিট", desc: "দড়ি লাফানোর সময় বিভিন্ন চ্যালেঞ্জ নিন।", emoji: "🪢", video: "https://www.youtube.com/results?search_query=skipping+rope+tricks+for+beginners" },
                            { name: "ট্যাগ বা চোর-পুলিশ খেলা", duration: "২০ মিনিট", desc: "বন্ধুদের সাথে দৌড়াদৌড়ি করে ট্যাগ বা চোর-পুলিশ খেলুন।", emoji: "🏃", video: "https://www.youtube.com/results?search_query=fun+tag+games+for+students" },
                            { name: "ড্যান্স চ্যালেঞ্জ", duration: "১৫ মিনিট", desc: "আপনার পছন্দের মিউজিক চালিয়ে দারুণ সব স্টেপ ট্রাই করুন।", emoji: "💃", video: "https://www.youtube.com/results?search_query=easy+dance+challenge+for+beginners" }
                          ].map((ex, i) => (
                            <motion.div 
                              key={i} 
                              whileHover={{ scale: 1.05, rotateY: 5, rotateX: 5 }}
                              transition={{ type: "spring", stiffness: 300, damping: 20 }}
                              className="p-4 rounded-lg shadow-sm border bg-white border-orange-100 flex gap-4 items-start"
                            >
                              <div className="flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center text-2xl shadow-inner border bg-orange-100 border-orange-200">
                                {ex.emoji}
                              </div>
                              <div className="flex-grow">
                                <h4 className="font-bold text-slate-800">{ex.name}</h4>
                                <p className="text-sm font-medium mb-1 text-orange-600">{ex.duration}</p>
                                <p className="text-sm text-slate-600 mb-2">{ex.desc}</p>
                                <a 
                                  href={ex.video} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center justify-center gap-2 text-sm font-bold text-white bg-orange-600 hover:bg-orange-700 px-4 py-2 rounded-lg transition-all shadow-md hover:shadow-lg"
                                >
                                  <PlayCircle className="w-4 h-4" />
                                  Watch Demo Video
                                </a>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Markdown Sections 8-9 */}
                  <div className="prose prose-slate prose-emerald dark:prose-invert max-w-none prose-headings:font-bold prose-headings:text-black dark:prose-headings:text-white prose-h1:text-3xl prose-h2:text-2xl prose-h2:mt-8 prose-h2:mb-4 prose-h2:pb-2 prose-h2:border-b prose-h2:border-slate-100 prose-table:w-full prose-th:bg-emerald-50 dark:prose-th:bg-emerald-900/30 prose-th:p-3 prose-td:p-3 prose-tr:border-b prose-tr:border-slate-200 prose-p:text-black prose-li:text-black prose-td:text-black prose-th:text-black dark:prose-p:text-white dark:prose-li:text-white dark:prose-td:text-white dark:prose-th:text-white prose-strong:text-black dark:prose-strong:text-white">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{result.water}</ReactMarkdown>
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{result.insight}</ReactMarkdown>
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4 py-20">
                  <Scale className="w-16 h-16 text-slate-200" />
                  <h3 className="text-xl font-medium text-slate-600">Your Plan Will Appear Here</h3>
                  <p className="text-center max-w-md">
                    Fill out your personal details on the left and click "Generate My Plan" to get a customized, scientifically-backed Bangladeshi diet and fitness routine.
                  </p>
                </div>
              )}
            </div>

            {/* Search History Section (Visible even if result is null) */}
            {searchHistory.length > 0 && (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 lg:p-8 mt-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <History className="w-5 h-5 text-emerald-600" />
                    Alternative Food Search History
                  </h3>
                  <button 
                    onClick={() => setSearchHistory([])}
                    className="text-sm text-red-500 hover:text-red-700 flex items-center gap-1"
                  >
                    <Trash2 className="w-4 h-4" /> Clear
                  </button>
                </div>
                <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                  {searchHistory.map(item => (
                    <div key={item.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 bg-slate-50 rounded-lg border border-slate-100">
                      <div>
                        <div className="text-sm text-slate-500 mb-1">
                          {new Date(item.timestamp).toLocaleString()} • <span className="capitalize text-emerald-600 font-medium">{item.mealType}</span>
                        </div>
                        <div className="font-medium text-slate-800">
                          Searched for: <span className="line-through text-slate-500 mr-2">{item.originalFood}</span>
                          <span className="text-emerald-700">Found: {item.alternative.name}</span>
                        </div>
                        <div className="text-sm text-slate-600 mt-1">
                          {item.alternative.calories} kcal | P: {item.alternative.protein} | C: {item.alternative.carbs} | F: {item.alternative.fats}
                        </div>
                      </div>
                      <button
                        onClick={() => handleReuseHistory(item)}
                        disabled={!result}
                        className="mt-3 sm:mt-0 px-4 py-2 bg-white border border-emerald-200 text-emerald-700 rounded-lg text-sm font-medium hover:bg-emerald-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Add to Current Plan
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

        </div>
        ) : (
          <div className="max-w-4xl mx-auto space-y-8">
            {/* AI Insights Section */}
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl shadow-sm border border-emerald-100 p-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
                <h2 className="text-xl font-bold flex items-center gap-2 text-emerald-800">
                  <Brain className="w-6 h-6 text-emerald-600" />
                  AI Progress Insights (এআই প্রগতি বিশ্লেষণ)
                </h2>
                <button
                  onClick={generateProgressInsights}
                  disabled={isGeneratingInsights || (weightLogs.length < 2 && activityLogs.length === 0)}
                  className="bg-emerald-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-emerald-700 transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isGeneratingInsights ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  {progressInsights ? 'Refresh Insights (রিফ্রেশ করুন)' : 'Analyze My Progress (বিশ্লেষণ করুন)'}
                </button>
              </div>
              
              {!progressInsights && !isGeneratingInsights && (
                <p className="text-emerald-700 text-sm">
                  Click the button above to get personalized AI analysis of your weight trends and activity logs. (আপনার ওজন এবং ব্যায়ামের এআই বিশ্লেষণ পেতে উপরের বাটনে ক্লিক করুন।)
                </p>
              )}

              {isGeneratingInsights && (
                <div className="py-8 flex flex-col items-center justify-center text-emerald-600 space-y-3">
                  <Loader2 className="w-8 h-8 animate-spin" />
                  <p className="animate-pulse font-medium">Analyzing your progress data... (আপনার তথ্য বিশ্লেষণ করা হচ্ছে...)</p>
                </div>
              )}

              {progressInsights && !isGeneratingInsights && (
                <div className="space-y-6 mt-6">
                  <div className="bg-white rounded-xl p-5 border border-emerald-100 shadow-sm">
                    <h3 className="font-bold text-slate-800 mb-3 flex items-center gap-2">
                      <LineChartIcon className="w-5 h-5 text-blue-500" /> Trend Analysis (প্রবণতা বিশ্লেষণ)
                    </h3>
                    <div className="prose prose-sm prose-slate dark:prose-invert max-w-none prose-headings:font-bold prose-headings:text-black dark:prose-headings:text-white prose-p:text-black prose-li:text-black prose-strong:text-black dark:prose-p:text-white dark:prose-li:text-white dark:prose-strong:text-white">
                      <ReactMarkdown remarkPlugins={[remarkGfm]}>{progressInsights.trendAnalysis}</ReactMarkdown>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-xl p-5 border border-emerald-100 shadow-sm">
                    <h3 className="font-bold text-slate-800 mb-3 flex items-center gap-2">
                      <Target className="w-5 h-5 text-orange-500" /> Actionable Recommendations (পরামর্শ)
                    </h3>
                    <ul className="space-y-2">
                      {progressInsights.recommendations.map((rec, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-slate-700">
                          <span className="text-emerald-500 mt-0.5">•</span>
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-emerald-600 text-white rounded-xl p-5 shadow-sm text-center">
                    <p className="font-medium text-lg italic">"{progressInsights.encouragement}"</p>
                  </div>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                <h2 className="text-xl font-semibold flex items-center gap-2 text-slate-800">
                  <LineChartIcon className="w-5 h-5 text-emerald-600" />
                  Weight Progress
                </h2>
                
                {weightLogs.length > 0 && (
                  <div className="flex items-center gap-3">
                    <div className="flex bg-slate-100 p-1 rounded-lg">
                      {(['1w', '1m', '3m', 'all'] as const).map(range => (
                        <button
                          key={range}
                          onClick={() => setChartRange(range)}
                          className={`px-3 py-1 text-sm rounded-md transition-colors ${chartRange === range ? 'bg-white text-emerald-700 shadow-sm font-medium' : 'text-slate-600 hover:text-slate-900'}`}
                        >
                          {range === '1w' ? '1W' : range === '1m' ? '1M' : range === '3m' ? '3M' : 'All'}
                        </button>
                      ))}
                    </div>
                    <button onClick={exportWeightCSV} className="flex items-center gap-1 text-sm text-emerald-600 hover:text-emerald-700 font-medium bg-emerald-50 px-3 py-1.5 rounded-lg transition-colors">
                      <Download className="w-4 h-4" /> Export
                    </button>
                  </div>
                )}
              </div>
              
              <form onSubmit={handleAddWeight} className="flex flex-col sm:flex-row gap-4 mb-8">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Date</label>
                  <input 
                    type="date" 
                    value={newWeightDate}
                    onChange={(e) => setNewWeightDate(e.target.value)}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    required
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Weight (kg)</label>
                  <input 
                    type="text" 
                    inputMode="decimal"
                    value={newWeight}
                    onChange={(e) => setNewWeight(e.target.value)}
                    placeholder="e.g., 65.5"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    required
                  />
                </div>
                <div className="flex items-end">
                  <button 
                    type="submit"
                    className="w-full sm:w-auto bg-emerald-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" /> Log Weight
                  </button>
                </div>
              </form>

              {weightLogs.length > 0 ? (
                <div className="h-80 w-full mt-8">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={getFilteredWeightLogs()} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                      <defs>
                        <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#059669" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#059669" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="date" stroke="#64748b" fontSize={12} tickMargin={10} />
                      <YAxis stroke="#64748b" fontSize={12} domain={['auto', 'auto']} tickMargin={10} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                        labelStyle={{ color: '#64748b', marginBottom: '4px' }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="weight" 
                        stroke="#059669" 
                        strokeWidth={3}
                        fillOpacity={1}
                        fill="url(#colorWeight)"
                        activeDot={{ r: 6, fill: '#059669', strokeWidth: 0 }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-500 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  <Scale className="w-12 h-12 mx-auto text-slate-300 mb-3" />
                  <p>No weight logs yet. Start tracking your progress!</p>
                </div>
              )}
            </div>

            {weightLogs.length > 0 && (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
                <h2 className="text-xl font-semibold mb-6 flex items-center gap-2 text-slate-800">
                  <History className="w-5 h-5 text-emerald-600" />
                  Weight History
                </h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 text-sm">
                        <th className="pb-3 font-medium">Date</th>
                        <th className="pb-3 font-medium">Weight (kg)</th>
                        <th className="pb-3 font-medium text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[...weightLogs].reverse().map((log) => (
                        <tr key={log.id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50 transition-colors">
                          <td className="py-3 text-slate-700">{new Date(log.date).toLocaleDateString()}</td>
                          <td className="py-3 font-medium text-slate-900">{log.weight}</td>
                          <td className="py-3 text-right">
                            <button 
                              onClick={() => handleDeleteWeight(log.id)}
                              className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors"
                              title="Delete entry"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                <h2 className="text-xl font-semibold flex items-center gap-2 text-slate-800">
                  <Activity className="w-5 h-5 text-emerald-600" />
                  Fitness Activity Log
                </h2>
                
                {activityLogs.length > 0 && (
                  <div className="flex items-center gap-3">
                    <div className="flex bg-slate-100 p-1 rounded-lg">
                      {(['1w', '1m', '3m', 'all'] as const).map(range => (
                        <button
                          key={range}
                          onClick={() => setActivityChartRange(range)}
                          className={`px-3 py-1 text-sm rounded-md transition-colors ${activityChartRange === range ? 'bg-white text-emerald-700 shadow-sm font-medium' : 'text-slate-600 hover:text-slate-900'}`}
                        >
                          {range === '1w' ? '1W' : range === '1m' ? '1M' : range === '3m' ? '3M' : 'All'}
                        </button>
                      ))}
                    </div>
                    <button onClick={exportActivityCSV} className="flex items-center gap-1 text-sm text-emerald-600 hover:text-emerald-700 font-medium bg-emerald-50 px-3 py-1.5 rounded-lg transition-colors">
                      <Download className="w-4 h-4" /> Export
                    </button>
                  </div>
                )}
              </div>
              
              <form onSubmit={handleAddActivity} className="flex flex-col sm:flex-row gap-4 mb-8">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Date</label>
                  <input 
                    type="date" 
                    value={newActivityDate}
                    onChange={(e) => setNewActivityDate(e.target.value)}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    required
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Activity</label>
                  <input 
                    type="text" 
                    value={newActivity}
                    onChange={(e) => setNewActivity(e.target.value)}
                    placeholder="e.g., Running, Yoga"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    required
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Duration (min)</label>
                  <input 
                    type="text" 
                    inputMode="numeric"
                    value={newActivityDuration}
                    onChange={(e) => setNewActivityDuration(e.target.value)}
                    placeholder="e.g., 30"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    required
                  />
                </div>
                <div className="flex items-end">
                  <button 
                    type="submit"
                    className="w-full sm:w-auto bg-emerald-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" /> Log Activity
                  </button>
                </div>
              </form>

              {activityLogs.length > 0 ? (
                <>
                  <div className="h-64 w-full mt-8 mb-8">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={getFilteredActivityLogs()} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                        <XAxis dataKey="date" stroke="#64748b" fontSize={12} tickMargin={10} />
                        <YAxis stroke="#64748b" fontSize={12} tickMargin={10} />
                        <Tooltip 
                          contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                          labelStyle={{ color: '#64748b', marginBottom: '4px' }}
                          cursor={{ fill: '#f1f5f9' }}
                        />
                        <Legend />
                        <Bar dataKey="duration" fill="#0ea5e9" radius={[4, 4, 0, 0]} name="Duration (min)" />
                        <Line type="monotone" dataKey="duration" stroke="#0284c7" strokeWidth={2} dot={false} name="Trend" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 text-sm">
                        <th className="pb-3 font-medium">Date</th>
                        <th className="pb-3 font-medium">Activity</th>
                        <th className="pb-3 font-medium">Duration</th>
                        <th className="pb-3 font-medium text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[...activityLogs].reverse().map((log) => (
                        <tr key={log.id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50 transition-colors">
                          <td className="py-3 text-slate-700">{new Date(log.date).toLocaleDateString()}</td>
                          <td className="py-3 font-medium text-slate-900">{log.activity}</td>
                          <td className="py-3 text-slate-700">{log.duration} min</td>
                          <td className="py-3 text-right">
                            <button 
                              onClick={() => handleDeleteActivity(log.id)}
                              className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors"
                              title="Delete entry"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                </>
              ) : (
                <div className="text-center py-12 text-slate-500 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  <Activity className="w-12 h-12 mx-auto text-slate-300 mb-3" />
                  <p>No activity logs yet. Start tracking your workouts!</p>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                <h2 className="text-xl font-semibold flex items-center gap-2 text-slate-800">
                  <Salad className="w-5 h-5 text-emerald-600" />
                  Nutrient Intake Log
                </h2>
                
                {nutrientLogs.length > 0 && (
                  <div className="flex items-center gap-3">
                    <div className="flex bg-slate-100 p-1 rounded-lg">
                      {(['1w', '1m', '3m', 'all'] as const).map(range => (
                        <button
                          key={range}
                          onClick={() => setNutrientChartRange(range)}
                          className={`px-3 py-1 text-sm rounded-md transition-colors ${nutrientChartRange === range ? 'bg-white text-emerald-700 shadow-sm font-medium' : 'text-slate-600 hover:text-slate-900'}`}
                        >
                          {range === '1w' ? '1W' : range === '1m' ? '1M' : range === '3m' ? '3M' : 'All'}
                        </button>
                      ))}
                    </div>
                    <button onClick={exportNutrientCSV} className="flex items-center gap-1 text-sm text-emerald-600 hover:text-emerald-700 font-medium bg-emerald-50 px-3 py-1.5 rounded-lg transition-colors">
                      <Download className="w-4 h-4" /> Export
                    </button>
                  </div>
                )}
              </div>
              
              <form onSubmit={handleAddNutrient} className="flex flex-col sm:flex-row flex-wrap gap-4 mb-8">
                <div className="flex-1 min-w-[150px]">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Date</label>
                  <input 
                    type="date" 
                    value={newNutrientDate}
                    onChange={(e) => setNewNutrientDate(e.target.value)}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    required
                  />
                </div>
                <div className="flex-1 min-w-[120px]">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Calories</label>
                  <input 
                    type="text" 
                    inputMode="decimal"
                    value={newNutrientCalories}
                    onChange={(e) => setNewNutrientCalories(e.target.value)}
                    placeholder="e.g., 2000"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    required
                  />
                </div>
                <div className="flex-1 min-w-[100px]">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Protein (g)</label>
                  <input 
                    type="text" 
                    inputMode="decimal"
                    value={newNutrientProtein}
                    onChange={(e) => setNewNutrientProtein(e.target.value)}
                    placeholder="e.g., 150"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  />
                </div>
                <div className="flex-1 min-w-[100px]">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Carbs (g)</label>
                  <input 
                    type="text" 
                    inputMode="decimal"
                    value={newNutrientCarbs}
                    onChange={(e) => setNewNutrientCarbs(e.target.value)}
                    placeholder="e.g., 200"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  />
                </div>
                <div className="flex-1 min-w-[100px]">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Fats (g)</label>
                  <input 
                    type="text" 
                    inputMode="decimal"
                    value={newNutrientFats}
                    onChange={(e) => setNewNutrientFats(e.target.value)}
                    placeholder="e.g., 60"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  />
                </div>
                <div className="flex items-end w-full sm:w-auto mt-2 sm:mt-0">
                  <button 
                    type="submit"
                    className="w-full sm:w-auto bg-emerald-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" /> Add
                  </button>
                </div>
              </form>

              {nutrientLogs.length > 0 ? (
                <>
                  <div className="h-64 w-full mt-8 mb-8">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={getFilteredNutrientLogs()} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                        <XAxis dataKey="date" stroke="#64748b" fontSize={12} tickMargin={10} />
                        <YAxis yAxisId="left" stroke="#64748b" fontSize={12} tickMargin={10} />
                        <YAxis yAxisId="right" orientation="right" stroke="#64748b" fontSize={12} tickMargin={10} />
                        <Tooltip 
                          contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                          labelStyle={{ color: '#64748b', marginBottom: '4px' }}
                        />
                        <Legend />
                        <Bar yAxisId="left" dataKey="calories" fill="#f59e0b" radius={[4, 4, 0, 0]} name="Calories" />
                        <Line yAxisId="right" type="monotone" dataKey="protein" stroke="#ef4444" strokeWidth={2} name="Protein (g)" />
                        <Line yAxisId="right" type="monotone" dataKey="carbs" stroke="#3b82f6" strokeWidth={2} name="Carbs (g)" />
                        <Line yAxisId="right" type="monotone" dataKey="fats" stroke="#10b981" strokeWidth={2} name="Fats (g)" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 text-sm">
                        <th className="pb-3 font-medium">Date</th>
                        <th className="pb-3 font-medium">Calories</th>
                        <th className="pb-3 font-medium">Protein</th>
                        <th className="pb-3 font-medium">Carbs</th>
                        <th className="pb-3 font-medium">Fats</th>
                        <th className="pb-3 font-medium text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[...nutrientLogs].reverse().map((log) => (
                        <tr key={log.id} className="border-b border-slate-100 last:border-0">
                          <td className="py-3 text-slate-700">{new Date(log.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</td>
                          <td className="py-3 text-slate-700 font-medium">{log.calories} kcal</td>
                          <td className="py-3 text-slate-700">{log.protein}g</td>
                          <td className="py-3 text-slate-700">{log.carbs}g</td>
                          <td className="py-3 text-slate-700">{log.fats}g</td>
                          <td className="py-3 text-right">
                            <button 
                              onClick={() => handleDeleteNutrient(log.id)}
                              className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors"
                              title="Delete entry"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                </>
              ) : (
                <div className="text-center py-12 text-slate-500 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  <Salad className="w-12 h-12 mx-auto text-slate-300 mb-3" />
                  <p>No nutrient logs yet. Start tracking your daily intake!</p>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                <h2 className="text-xl font-semibold flex items-center gap-2 text-slate-800">
                  <Moon className="w-5 h-5 text-indigo-600" />
                  Sleep Tracker (ঘুমের ট্র্যাকার)
                </h2>
                
                {sleepLogs.length > 0 && (
                  <div className="flex items-center gap-3">
                    <div className="flex bg-slate-100 p-1 rounded-lg">
                      {(['1w', '1m', '3m', 'all'] as const).map(range => (
                        <button
                          key={range}
                          onClick={() => setSleepChartRange(range)}
                          className={`px-3 py-1 text-sm rounded-md transition-colors ${sleepChartRange === range ? 'bg-white text-indigo-700 shadow-sm font-medium' : 'text-slate-600 hover:text-slate-900'}`}
                        >
                          {range === '1w' ? '1W' : range === '1m' ? '1M' : range === '3m' ? '3M' : 'All'}
                        </button>
                      ))}
                    </div>
                    <button onClick={exportSleepCSV} className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-700 font-medium bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors">
                      <Download className="w-4 h-4" /> Export
                    </button>
                  </div>
                )}
              </div>
              
              <form onSubmit={handleAddSleep} className="flex flex-col sm:flex-row gap-4 mb-8">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Date</label>
                  <input 
                    type="date" 
                    value={newSleepDate}
                    onChange={(e) => setNewSleepDate(e.target.value)}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                    required
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Duration (hours)</label>
                  <input 
                    type="text" 
                    inputMode="decimal"
                    value={newSleepDuration}
                    onChange={(e) => setNewSleepDuration(e.target.value)}
                    placeholder="e.g., 7.5"
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                    required
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Quality</label>
                  <select 
                    value={newSleepQuality}
                    onChange={(e) => setNewSleepQuality(e.target.value as SleepLog['quality'])}
                    className="w-full rounded-lg border-slate-300 border px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all bg-white"
                  >
                    <option value="Poor">Poor (খারাপ)</option>
                    <option value="Fair">Fair (মোটামুটি)</option>
                    <option value="Good">Good (ভালো)</option>
                    <option value="Excellent">Excellent (চমৎকার)</option>
                  </select>
                </div>
                <div className="flex items-end">
                  <button 
                    type="submit"
                    className="w-full sm:w-auto bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" /> Log Sleep
                  </button>
                </div>
              </form>

              {sleepLogs.length > 0 ? (
                <>
                  <div className="h-64 w-full mt-8 mb-8">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={getFilteredSleepLogs()} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                        <XAxis dataKey="date" stroke="#64748b" fontSize={12} tickMargin={10} />
                        <YAxis stroke="#64748b" fontSize={12} tickMargin={10} domain={[0, 'auto']} />
                        <Tooltip 
                          contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                          labelStyle={{ color: '#64748b', marginBottom: '4px' }}
                        />
                        <Legend />
                        <Bar dataKey="duration" fill="#6366f1" radius={[4, 4, 0, 0]} name="Duration (hrs)" />
                        <Line type="monotone" dataKey="duration" stroke="#4f46e5" strokeWidth={2} dot={false} name="Trend" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 text-slate-500 text-sm">
                          <th className="pb-3 font-medium">Date</th>
                          <th className="pb-3 font-medium">Duration</th>
                          <th className="pb-3 font-medium">Quality</th>
                          <th className="pb-3 font-medium text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[...sleepLogs].reverse().map((log) => (
                          <tr key={log.id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50 transition-colors">
                            <td className="py-3 text-slate-700">{new Date(log.date).toLocaleDateString()}</td>
                            <td className="py-3 font-medium text-slate-900">{log.duration} hrs</td>
                            <td className="py-3">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                log.quality === 'Excellent' ? 'bg-emerald-100 text-emerald-700' :
                                log.quality === 'Good' ? 'bg-blue-100 text-blue-700' :
                                log.quality === 'Fair' ? 'bg-amber-100 text-amber-700' :
                                'bg-red-100 text-red-700'
                              }`}>
                                {log.quality}
                              </span>
                            </td>
                            <td className="py-3 text-right">
                              <button 
                                onClick={() => handleDeleteSleep(log.id)}
                                className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors"
                                title="Delete entry"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : (
                <div className="text-center py-12 text-slate-500 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  <Moon className="w-12 h-12 mx-auto text-slate-300 mb-3" />
                  <p>No sleep logs yet. Start tracking your rest!</p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Reminders Overlay */}
      {activeReminders.length > 0 && (
        <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-4">
          {activeReminders.map(meal => (
            <div key={meal} className="bg-white rounded-2xl shadow-xl border border-emerald-200 p-5 w-80 animate-in slide-in-from-bottom-5 fade-in duration-300">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2 text-emerald-800 font-bold capitalize text-lg">
                  <Bell className="w-5 h-5 animate-pulse" />
                  Time for {meal}!
                </div>
                <button onClick={() => dismissReminder(meal)} className="text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-100 transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <p className="text-sm text-slate-600 mb-4">
                It's {formData.mealTimes[meal as keyof typeof formData.mealTimes]}, time to have your {meal}.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => markAsEaten(meal)}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium py-2.5 rounded-xl transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <Check className="w-4 h-4" /> Eaten
                </button>
                <button
                  onClick={() => snoozeReminder(meal)}
                  className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-medium py-2.5 rounded-xl transition-colors"
                >
                  Snooze 15m
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
