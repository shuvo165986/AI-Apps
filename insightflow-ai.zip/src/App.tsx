import React, { useState } from 'react';
import { 
  BarChart3, 
  FileSpreadsheet, 
  Sparkles, 
  RefreshCw, 
  ArrowLeft,
  Search,
  Download,
  Database,
  Plus,
  ChevronRight,
  Trash2,
  Layers,
  GitCompare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import FileUpload from './components/FileUpload';
import DataPreview from './components/DataPreview';
import AnalysisReport from './components/AnalysisReport';
import DashboardCharts from './components/DashboardCharts';
import DashboardFilters from './components/DashboardFilters';
import DataActions from './components/DataActions';
import DataInsights from './components/DataInsights';
import KPICards from './components/KPICards';
import DataComparison from './components/DataComparison';
import { DatasetInfo, AnalysisResult } from './types';
import { analyzeDataset } from './lib/gemini';
import { cn } from './lib/utils';

interface DatasetState {
  id: string;
  info: DatasetInfo;
  analysis: AnalysisResult | null;
  isAnalyzing: boolean;
  error: string | null;
  filters: Record<string, any>;
  query: string;
}

const QUICK_QUERIES = [
  "Identify top 5 trends and their business implications",
  "Perform a deep-dive into data quality and integrity issues",
  "Analyze correlations to find hidden drivers of performance",
  "Suggest 3 strategic growth opportunities based on the data",
  "Detect seasonal patterns and forecast future cycles",
  "Identify high-value segments and their defining characteristics",
  "Perform a SWOT analysis (Strengths, Weaknesses, Opportunities, Threats)",
  "Detect anomalies that could indicate operational risks or errors",
  "Evaluate efficiency and suggest cost-optimization strategies",
  "Analyze the impact of outliers on core business metrics",
  "Assess customer behavior patterns and retention indicators",
  "Identify the most influential factors driving current growth"
];

export default function App() {
  const [datasets, setDatasets] = useState<DatasetState[]>([]);
  const datasetsRef = React.useRef<DatasetState[]>([]);
  
  React.useEffect(() => {
    datasetsRef.current = datasets;
  }, [datasets]);

  const [activeId, setActiveId] = useState<string | null>(null);
  const [showUpload, setShowUpload] = useState(true);
  const [showComparison, setShowComparison] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const activeDataset = datasets.find(d => d.id === activeId);

  // Analysis Queue to prevent rate limits
  const analysisQueue = React.useRef<string[]>([]);
  const isProcessingQueue = React.useRef(false);

  const processAnalysisQueue = async () => {
    if (isProcessingQueue.current || analysisQueue.current.length === 0) return;
    
    isProcessingQueue.current = true;
    const nextId = analysisQueue.current[0];
    
    // Find the dataset in the latest state
    const datasetToAnalyze = datasetsRef.current.find(d => d.id === nextId);
    
    if (datasetToAnalyze) {
      try {
        // Always analyze if it's in the queue (allows re-runs)
        const currentQuery = datasetToAnalyze.query;
        const result = await analyzeDataset(datasetToAnalyze.info, currentQuery);
        
        // Include the query used in the result for display
        const resultWithQuery = { ...result, queryUsed: currentQuery };

        setDatasets(prev => prev.map(d => d.id === nextId ? { 
          ...d, 
          analysis: resultWithQuery, 
          isAnalyzing: false,
          error: null 
        } : d));
      } catch (error: any) {
        console.error("Queue analysis failed:", error);
        setDatasets(prev => prev.map(d => d.id === nextId ? { 
          ...d, 
          error: error.message || "Analysis failed.", 
          isAnalyzing: false 
        } : d));
      }
    }
    
    analysisQueue.current.shift();
    isProcessingQueue.current = false;
    
    // Small delay between calls to be safe
    if (analysisQueue.current.length > 0) {
      setTimeout(processAnalysisQueue, 1500);
    }
  };

  const handleDataLoaded = (data: DatasetInfo) => {
    const newId = Math.random().toString(36).substr(2, 9);
    const newState: DatasetState = {
      id: newId,
      info: data,
      analysis: null,
      isAnalyzing: true,
      error: null,
      filters: {},
      query: ''
    };

    setDatasets(prev => {
      const next = [...prev, newState];
      datasetsRef.current = next;
      return next;
    });
    setActiveId(newId);
    setShowUpload(false);
    
    // Add to queue for sequential processing
    if (!analysisQueue.current.includes(newId)) {
      analysisQueue.current.push(newId);
    }
    processAnalysisQueue();
  };

  const handleFilterChange = (column: string, value: any) => {
    if (!activeId) return;
    setDatasets(prev => prev.map(d => {
      if (d.id !== activeId) return d;
      
      if (column === '__clear_all__') {
        return { ...d, filters: {} };
      }

      const newFilters = { ...d.filters };
      if (value === '' || value === null || value === undefined) {
        delete newFilters[column];
      } else {
        newFilters[column] = value;
      }
      return { ...d, filters: newFilters };
    }));
  };

  const filteredData = React.useMemo(() => {
    try {
      if (!activeDataset) return [];
      const { info, filters } = activeDataset;
      if (!info.data || !Array.isArray(info.data)) return [];
      if (!filters || Object.keys(filters).length === 0) return info.data;

      return info.data.filter(row => {
        if (!row || typeof row !== 'object') return false;
        
        return Object.entries(filters).every(([key, value]) => {
          if (value === undefined || value === null || value === '') return true;
          
          try {
            if (key.endsWith('_start')) {
              const col = key.replace('_start', '');
              const val = row[col];
              if (val === undefined || val === null) return false;
              const rowVal = new Date(val as any);
              const filterVal = new Date(value as any);
              return !isNaN(rowVal.getTime()) && rowVal >= filterVal;
            }
            if (key.endsWith('_end')) {
              const col = key.replace('_end', '');
              const val = row[col];
              if (val === undefined || val === null) return false;
              const rowVal = new Date(val as any);
              const filterVal = new Date(value as any);
              return !isNaN(rowVal.getTime()) && rowVal <= filterVal;
            }
            
            const cellValue = row[key];
            return String(cellValue ?? '').toLowerCase() === String(value ?? '').toLowerCase();
          } catch (e) {
            console.warn(`Filter error for key ${key}:`, e);
            return true;
          }
        });
      });
    } catch (err) {
      console.error("Filtering logic failed:", err);
      return activeDataset?.info.data || [];
    }
  }, [activeDataset]);

  const runAnalysis = () => {
    if (!activeDataset || !activeId) return;
    
    setDatasets(prev => {
      const next = prev.map(d => d.id === activeId ? { ...d, isAnalyzing: true, error: null } : d);
      datasetsRef.current = next;
      return next;
    });
    
    // Add to queue for sequential processing
    if (!analysisQueue.current.includes(activeId)) {
      analysisQueue.current.push(activeId);
    }
    processAnalysisQueue();
  };

  const removeDataset = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDatasets(prev => {
      const filtered = prev.filter(d => d.id !== id);
      if (activeId === id) {
        setActiveId(filtered.length > 0 ? filtered[filtered.length - 1].id : null);
        if (filtered.length === 0) setShowUpload(true);
      }
      return filtered;
    });
    // Remove from queue if present
    analysisQueue.current = analysisQueue.current.filter(qid => qid !== id);
  };

  const clearAllDatasets = () => {
    setDatasets([]);
    setActiveId(null);
    setShowUpload(true);
    analysisQueue.current = [];
  };

  const handleDataUpdated = (newData: DatasetInfo) => {
    if (!activeId) return;
    setDatasets(prev => {
      const next = prev.map(d => d.id === activeId ? { ...d, info: newData, analysis: null, isAnalyzing: true } : d);
      datasetsRef.current = next;
      return next;
    });
    
    // Add to queue for sequential processing
    if (!analysisQueue.current.includes(activeId)) {
      analysisQueue.current.push(activeId);
    }
    processAnalysisQueue();
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-700 flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-[1600px] mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5 group cursor-pointer" onClick={() => setShowUpload(true)}>
            <div className="bg-indigo-600 p-2 rounded-xl group-hover:rotate-12 transition-transform">
              <BarChart3 className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight">InsightFlow <span className="text-indigo-600">AI</span></span>
          </div>
          
          <div className="flex items-center gap-4">
            {datasets.length > 0 && (
              <button 
                onClick={() => setShowUpload(!showUpload)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all",
                  showUpload 
                    ? "bg-slate-100 text-slate-600" 
                    : "bg-indigo-50 text-indigo-600 hover:bg-indigo-100"
                )}
              >
                {showUpload ? <ChevronRight className="w-4 h-4 rotate-180" /> : <Plus className="w-4 h-4" />}
                {showUpload ? "Back to Analysis" : "Upload More"}
              </button>
            )}
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar for Datasets */}
        {datasets.length > 0 && (
          <aside className="w-72 bg-white border-r border-slate-200 flex flex-col shrink-0">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Database className="w-3 h-3" />
                Your Datasets ({datasets.length})
              </h3>
              <div className="flex items-center gap-2">
                {datasets.length >= 2 && (
                  <button 
                    onClick={() => setShowComparison(true)}
                    className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                    title="Compare Datasets"
                  >
                    <GitCompare className="w-3.5 h-3.5" />
                  </button>
                )}
                {datasets.length > 0 && (
                  <button 
                    onClick={clearAllDatasets}
                    className="text-[10px] font-bold text-rose-500 hover:text-rose-600 uppercase tracking-widest"
                  >
                    Clear All
                  </button>
                )}
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar">
              {datasets.map((d) => (
                <div
                  key={d.id}
                  className={cn(
                    "w-full flex items-center gap-2 p-1 rounded-xl transition-all group",
                    activeId === d.id ? "bg-indigo-50/50" : "hover:bg-slate-50"
                  )}
                >
                  <div className="pl-2">
                    <input 
                      type="checkbox"
                      checked={selectedIds.includes(d.id)}
                      onChange={(e) => {
                        e.stopPropagation();
                        setSelectedIds(prev => 
                          prev.includes(d.id) 
                            ? prev.filter(id => id !== d.id) 
                            : [...prev, d.id]
                        );
                      }}
                      className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                    />
                  </div>
                  <div
                    onClick={() => {
                      setActiveId(d.id);
                      setShowUpload(false);
                    }}
                    className={cn(
                      "flex-1 flex items-center gap-3 p-2 rounded-lg text-left transition-all cursor-pointer min-w-0",
                      activeId === d.id 
                        ? "text-indigo-700 font-medium" 
                        : "text-slate-600"
                    )}
                  >
                    <div className={cn(
                      "p-2 rounded-lg shrink-0",
                      activeId === d.id ? "bg-white text-indigo-600 shadow-sm" : "bg-slate-100 text-slate-400"
                    )}>
                      {d.isAnalyzing ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <FileSpreadsheet className="w-4 h-4" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold truncate">{d.info.name}</p>
                      <p className="text-[10px] opacity-60">{(d.info.rowCount).toLocaleString()} rows</p>
                    </div>
                    <button 
                      onClick={(e) => removeDataset(d.id, e)}
                      className="p-1.5 opacity-0 group-hover:opacity-100 hover:bg-rose-50 hover:text-rose-600 rounded-md transition-all"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            {datasets.length > 1 && (
              <div className="p-4 border-t border-slate-100 bg-slate-50/50 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    {selectedIds.length} Selected
                  </span>
                  {selectedIds.length > 0 && (
                    <button 
                      onClick={() => setSelectedIds([])}
                      className="text-[10px] font-bold text-indigo-600 hover:underline uppercase tracking-widest"
                    >
                      Deselect All
                    </button>
                  )}
                </div>
                <button 
                  onClick={() => {
                    const toMerge = datasets.filter(d => selectedIds.length > 0 ? selectedIds.includes(d.id) : true);
                    if (toMerge.length < 2) {
                      alert("Please select at least 2 datasets to merge.");
                      return;
                    }

                    // Advanced merge logic: check for column intersection
                    const firstDataset = toMerge[0];
                    const commonColumns = toMerge.reduce((acc, curr) => 
                      acc.filter(col => curr.info.columns.includes(col)), 
                      firstDataset.info.columns
                    );

                    if (commonColumns.length === 0) {
                      alert("Selected datasets have no common columns and cannot be merged.");
                      return;
                    }

                    const differentColumns = toMerge.some(d => d.info.columns.length !== commonColumns.length);
                    if (differentColumns) {
                      const proceed = window.confirm(
                        `The selected datasets have some differing columns. Merging will only keep the ${commonColumns.length} common columns: ${commonColumns.join(', ')}. Proceed?`
                      );
                      if (!proceed) return;
                    }

                    const mergedData = toMerge.flatMap(d => 
                      d.info.data.map(row => {
                        const newRow: Record<string, any> = {};
                        commonColumns.forEach(col => {
                          newRow[col] = row[col];
                        });
                        return newRow;
                      })
                    );

                    const mergedColumnTypes = firstDataset.info.columnTypes.filter(ct => commonColumns.includes(ct.name));

                    handleDataLoaded({
                      name: `Merged Dataset (${toMerge.length} files)`,
                      columns: commonColumns,
                      columnTypes: mergedColumnTypes,
                      data: mergedData,
                      preview: mergedData.slice(0, 20),
                      rowCount: mergedData.length
                    });
                    setSelectedIds([]);
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2 bg-white border border-indigo-200 rounded-xl text-xs font-bold text-indigo-600 hover:bg-indigo-50 transition-all shadow-sm"
                >
                  <Layers className="w-3.5 h-3.5" />
                  {selectedIds.length > 0 ? 'Merge Selected' : 'Merge All Files'}
                </button>
              </div>
            )}
            <div className="p-4 border-t border-slate-100">
              <button 
                onClick={() => setShowUpload(true)}
                className="w-full flex items-center justify-center gap-2 py-2.5 border-2 border-dashed border-slate-200 rounded-xl text-xs font-bold text-slate-400 hover:border-indigo-300 hover:text-indigo-600 hover:bg-indigo-50 transition-all"
              >
                <Plus className="w-4 h-4" />
                Add New File
              </button>
            </div>
          </aside>
        )}

        <main className="flex-1 overflow-y-auto bg-[#F8FAFC] custom-scrollbar">
          <div className="max-w-6xl mx-auto px-6 py-12">
            <AnimatePresence mode="wait">
              {showComparison ? (
                <motion.div
                  key="comparison"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="space-y-6"
                >
                  <div className="flex items-center gap-4 mb-2">
                    <button 
                      onClick={() => setShowComparison(false)}
                      className="p-2 hover:bg-white rounded-xl border border-slate-200 text-slate-600 transition-all"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <h2 className="text-2xl font-bold text-slate-900">Back to Dashboard</h2>
                  </div>
                  <DataComparison 
                    datasets={datasets.map(d => ({ id: d.id, info: d.info }))} 
                    onClose={() => setShowComparison(false)} 
                  />
                </motion.div>
              ) : showUpload ? (
                <motion.div
                  key="upload"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="flex flex-col items-center text-center gap-8"
                >
                  <div className="max-w-2xl space-y-4">
                    <h1 className="text-5xl font-extrabold tracking-tight text-slate-900 sm:text-6xl">
                      Turn raw data into <span className="text-indigo-600">brilliant insights.</span>
                    </h1>
                    <p className="text-lg text-slate-500 max-w-lg mx-auto leading-relaxed">
                      Upload your Excel or CSV files and let our AI Data Analyst uncover hidden patterns, trends, and actionable business intelligence.
                    </p>
                  </div>
                  
                  <FileUpload onDataLoaded={handleDataLoaded} />
                  
                  {datasets.length > 0 && (
                    <div className="w-full max-w-3xl space-y-4">
                      <div className="flex items-center justify-between px-2">
                        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Active Datasets</h4>
                        <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">{datasets.length} Files</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {datasets.map(d => (
                          <button
                            key={d.id}
                            onClick={() => {
                              setActiveId(d.id);
                              setShowUpload(false);
                            }}
                            className="bg-white border border-slate-200 p-4 rounded-2xl flex items-center gap-4 hover:border-indigo-300 hover:shadow-md transition-all text-left"
                          >
                            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl shrink-0">
                              <FileSpreadsheet className="w-5 h-5" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-bold text-slate-900 truncate">{d.info.name}</p>
                              <p className="text-xs text-slate-500">{(d.info.rowCount).toLocaleString()} rows</p>
                            </div>
                            <ChevronRight className="w-4 h-4 text-slate-300" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 w-full max-w-3xl mt-8">
                    {[
                      { icon: Sparkles, title: "AI-Powered", desc: "Advanced Gemini analysis" },
                      { icon: FileSpreadsheet, title: "Excel Ready", desc: "Supports .xlsx & .csv" },
                      { icon: RefreshCw, title: "Real-time", desc: "Instant data visualization" }
                    ].map((feature, i) => (
                      <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 flex flex-col items-center gap-3">
                        <div className="p-2.5 bg-slate-50 rounded-xl text-indigo-600">
                          <feature.icon className="w-5 h-5" />
                        </div>
                        <h4 className="font-bold text-slate-900">{feature.title}</h4>
                        <p className="text-xs text-slate-500">{feature.desc}</p>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ) : activeDataset ? (
                <motion.div
                  key={activeId}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-8"
                >
                  {/* Dataset Info Header */}
                  <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="flex items-center gap-4">
                      <div className="bg-indigo-50 p-4 rounded-2xl text-indigo-600">
                        <FileSpreadsheet className="w-8 h-8" />
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold text-slate-900">{activeDataset.info.name}</h2>
                        <p className="text-slate-500 font-medium">{(activeDataset.info.rowCount).toLocaleString()} rows • {(activeDataset.info.columns.length)} columns</p>
                      </div>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                      <div className="relative flex-1 sm:min-w-[400px] group">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input 
                          type="text"
                          placeholder="Ask a specific question (e.g. 'Analyze sales trends')"
                          className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                          value={activeDataset.query}
                          onChange={(e) => {
                            const val = e.target.value;
                            setDatasets(prev => prev.map(d => d.id === activeId ? { ...d, query: val } : d));
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') runAnalysis();
                          }}
                        />
                        {activeDataset.query === '' && (
                          <div className="absolute left-0 top-full mt-2 w-full bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-2 opacity-0 pointer-events-none group-focus-within:opacity-100 group-focus-within:pointer-events-auto transition-all max-h-64 overflow-y-auto custom-scrollbar">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-3 py-2 sticky top-0 bg-white">Suggested Queries</p>
                            {QUICK_QUERIES.map(q => (
                              <button
                                key={q}
                                onClick={() => {
                                  setDatasets(prev => prev.map(d => d.id === activeId ? { ...d, query: q } : d));
                                }}
                                className="w-full text-left px-3 py-2 text-xs text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition-colors"
                              >
                                {q}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                      <button
                        onClick={runAnalysis}
                        disabled={activeDataset.isAnalyzing}
                        className={cn(
                          "px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2",
                          activeDataset.isAnalyzing && "opacity-70 cursor-not-allowed"
                        )}
                      >
                        {activeDataset.isAnalyzing ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4" />
                            {activeDataset.analysis ? 'Re-run Analysis' : 'Run AI Analysis'}
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Data Preview */}
                  <DataPreview dataset={activeDataset.info} />

                  {/* Data Actions Studio */}
                  <DataActions 
                    dataset={activeDataset.info} 
                    onDataUpdated={handleDataUpdated} 
                  />

                  {/* Statistical Insights */}
                  <DataInsights dataset={activeDataset.info} />

                  {/* Error Message */}
                  {activeDataset.error && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-6 rounded-2xl bg-rose-50 border border-rose-100 flex items-start gap-4 text-rose-700"
                    >
                      <div className="p-2 bg-rose-100 rounded-lg">
                        <RefreshCw className="w-5 h-5" />
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-bold">Analysis Interrupted</h4>
                        <p className="text-sm opacity-90">{activeDataset.error}</p>
                        <button 
                          onClick={runAnalysis}
                          className="mt-2 text-xs font-bold uppercase tracking-widest hover:underline"
                        >
                          Try Again
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* Analysis Results */}
                  {activeDataset.analysis && (
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
                      <KPICards dataset={activeDataset.info} />
                      
                      <div className="flex items-center justify-between mb-6 mt-12">
                        <h2 className="text-3xl font-extrabold tracking-tight text-slate-900">Analysis Report</h2>
                        <button className="flex items-center gap-2 text-sm font-bold text-indigo-600 hover:text-indigo-700">
                          <Download className="w-4 h-4" />
                          Export PDF
                        </button>
                      </div>
                      
                      <AnalysisReport analysis={activeDataset.analysis} />
                      
                      <DashboardFilters 
                        data={activeDataset.info.data}
                        columns={activeDataset.info.columns}
                        columnTypes={activeDataset.info.columnTypes}
                        filters={activeDataset.filters}
                        onFilterChange={handleFilterChange}
                        onClearFilters={() => handleFilterChange('__clear_all__', null)}
                      />

                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-bold text-slate-900">Visualizations</h3>
                        <p className="text-xs text-slate-500">Showing {(filteredData?.length || 0).toLocaleString()} of {(activeDataset.info.rowCount).toLocaleString()} rows</p>
                      </div>

                      <DashboardCharts analysis={activeDataset.analysis} data={filteredData} />
                    </div>
                  )}
                </motion.div>
              ) : (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center py-20 text-center"
                >
                  <div className="p-6 bg-slate-100 rounded-full text-slate-400 mb-4">
                    <Database className="w-12 h-12" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">No active dataset</h3>
                  <p className="text-slate-500 mt-2 mb-6 text-sm">Select a dataset from the sidebar or upload a new one to begin.</p>
                  <button
                    onClick={() => setShowUpload(true)}
                    className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all"
                  >
                    Upload New File
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="py-8 border-t border-slate-200 bg-white z-10">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-2">
          <div className="flex items-center justify-center gap-2 opacity-50">
            <BarChart3 className="w-4 h-4" />
            <span className="font-bold text-sm tracking-tight">InsightFlow AI</span>
          </div>
          <p className="text-[10px] text-slate-400">
            © 2026 InsightFlow AI. Powered by Gemini 2.0. Built for professional data intelligence.
          </p>
        </div>
      </footer>
    </div>
  );
}
