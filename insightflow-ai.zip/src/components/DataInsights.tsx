import React, { useMemo } from 'react';
import { 
  BarChart2, 
  Hash, 
  Type, 
  Calendar, 
  AlertTriangle, 
  Target,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { DatasetInfo } from '../types';
import { DataAnalysisEngine, LocalStats } from '../lib/dataAnalysis';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface DataInsightsProps {
  dataset: DatasetInfo;
}

export default function DataInsights({ dataset }: DataInsightsProps) {
  const stats = useMemo(() => 
    DataAnalysisEngine.calculateStats(dataset.columns, dataset.data, dataset.columnTypes),
    [dataset]
  );

  const numericStats = stats.filter(s => s.type === 'numeric');
  const categoricalStats = stats.filter(s => s.type === 'categorical');

  return (
    <div className="space-y-8 mt-12">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-600 text-white rounded-xl">
            <BarChart2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-900">Statistical Insights</h3>
            <p className="text-sm text-slate-500">Local computation of dataset characteristics</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.columnName}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className={cn(
                  "p-1.5 rounded-lg",
                  stat.type === 'numeric' ? "bg-blue-50 text-blue-600" :
                  stat.type === 'categorical' ? "bg-purple-50 text-purple-600" :
                  stat.type === 'date' ? "bg-emerald-50 text-emerald-600" :
                  "bg-slate-50 text-slate-600"
                )}>
                  {stat.type === 'numeric' ? <Hash className="w-4 h-4" /> :
                   stat.type === 'categorical' ? <Target className="w-4 h-4" /> :
                   stat.type === 'date' ? <Calendar className="w-4 h-4" /> :
                   <Type className="w-4 h-4" />}
                </div>
                <h4 className="font-bold text-slate-900 truncate max-w-[150px]">{stat.columnName}</h4>
              </div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{stat.type}</span>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Uniqueness</span>
                <span className="font-bold text-slate-700">{Math.round((stat.uniqueCount / dataset.rowCount) * 100)}%</span>
              </div>
              <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-indigo-500" 
                  style={{ width: `${(stat.uniqueCount / dataset.rowCount) * 100}%` }}
                />
              </div>

              {stat.type === 'numeric' && stat.avg !== undefined && (
                <div className="pt-2 grid grid-cols-2 gap-4 border-t border-slate-50 mt-2">
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold">Average</p>
                    <p className="text-sm font-bold text-slate-900">{stat.avg.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold">Range</p>
                    <p className="text-sm font-bold text-slate-900">{((stat.max || 0) - (stat.min || 0)).toLocaleString(undefined, { maximumFractionDigits: 1 })}</p>
                  </div>
                </div>
              )}

              {stat.missingCount > 0 && (
                <div className="flex items-center gap-2 text-rose-600 bg-rose-50 px-2 py-1 rounded-lg mt-2">
                  <AlertTriangle className="w-3 h-3" />
                  <span className="text-[10px] font-bold">{stat.missingCount} missing values</span>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
