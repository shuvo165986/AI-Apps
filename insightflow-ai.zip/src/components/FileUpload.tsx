import React, { useCallback, useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import { 
  Upload, 
  FileText, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  ArrowRight,
  Loader2,
  Database,
  Info,
  Table as TableIcon,
  Rows,
  Zap,
  FileSpreadsheet,
  Trash2,
  Sparkles,
  Wand2,
  Eraser,
  Settings2,
  Check,
  Calendar,
  FilterX
} from 'lucide-react';
import { cn } from '../lib/utils';
import { DatasetInfo, DataRow } from '../types';
import { FileValidator } from '../lib/fileValidator';
import { DataCleaner, CleaningAction } from '../lib/dataCleaner';
import { DataAnalysisEngine } from '../lib/dataAnalysis';
import { analyzeDataset } from '../lib/gemini';

interface FileUploadProps {
  onDataLoaded: (data: DatasetInfo) => void;
}

const MAX_ROWS_FOR_FULL_LOAD = 50000;
const CHUNK_SIZE = 5000;

interface SheetMetadata {
  name: string;
  rowCount: number;
  columnCount: number;
}

interface PendingFile {
  id: string;
  file: File;
  status: 'pending' | 'processing' | 'completed' | 'error';
  error?: string;
  progress: number;
}

export default function FileUpload({ onDataLoaded }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [pendingFiles, setPendingFiles] = useState<PendingFile[]>([]);
  const [activeFileBuffer, setActiveFileBuffer] = useState<ArrayBuffer | null>(null);
  const [activeFileName, setActiveFileName] = useState<string>("");
  const [sheets, setSheets] = useState<SheetMetadata[]>([]);
  const [selectedActions, setSelectedActions] = useState<CleaningAction[]>(['trim']);
  const [aiSuggestions, setAiSuggestions] = useState<{issue: string, recommendation: string}[]>([]);
  const [isAiScanning, setIsAiScanning] = useState(false);
  const isAborted = useRef<boolean>(false);

  const toggleAction = (action: CleaningAction) => {
    setSelectedActions(prev => 
      prev.includes(action) ? prev.filter(a => a !== action) : [...prev, action]
    );
  };

  const scanWithAi = async (sheetName: string) => {
    if (!activeFileBuffer) return;
    setIsAiScanning(true);
    setError(null);

    try {
      const data = new Uint8Array(activeFileBuffer);
      const wb = XLSX.read(data, { 
        type: 'array',
        sheets: [sheetName],
        sheetRows: 20 // Only read first 20 rows for AI scan
      });

      const worksheet = wb.Sheets[sheetName];
      if (!worksheet) throw new Error("Sheet not found");

      // Robust header detection for AI scan
      const allRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
      const firstDataRowIndex = allRows.findIndex(row => row && row.length > 0);
      
      if (firstDataRowIndex === -1) {
        throw new Error("The sheet appears to be empty.");
      }

      const columns = allRows[firstDataRowIndex].map(String).filter(Boolean);
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
        header: columns,
        range: firstDataRowIndex + 1
      }) as DataRow[];

      const columnTypes = DataAnalysisEngine.detectColumnTypes(columns, jsonData);

      const result = await analyzeDataset({
        name: sheetName,
        columns,
        columnTypes,
        data: jsonData,
        preview: jsonData.slice(0, 10),
        rowCount: jsonData.length
      });

      setAiSuggestions(result.cleaningRecommendations);
      if (result.suggestedActions && result.suggestedActions.length > 0) {
        setSelectedActions(result.suggestedActions as CleaningAction[]);
      }
    } catch (err) {
      console.error("AI Scan Error:", err);
      setError("Failed to get AI cleaning suggestions.");
    } finally {
      setIsAiScanning(false);
    }
  };
  const getSheetMetadata = (wb: XLSX.WorkBook): SheetMetadata[] => {
    try {
      if (!wb || !wb.SheetNames || !wb.Sheets) return [];
      return wb.SheetNames.map(name => {
        const sheet = wb.Sheets[name];
        if (!sheet) return { name, rowCount: 0, columnCount: 0 };
        const ref = sheet['!ref'];
        let rowCount = 0;
        let columnCount = 0;
        if (ref) {
          const range = XLSX.utils.decode_range(ref);
          rowCount = range.e.r - range.s.r + 1;
          columnCount = range.e.c - range.s.c + 1;
        }
        return { name, rowCount, columnCount };
      });
    } catch (err) {
      console.error("Error getting sheet metadata:", err);
      return [];
    }
  };

  /**
   * Processes a CSV file using streaming for memory efficiency
   */
  const processCSV = (fileId: string, file: File) => {
    setPendingFiles(prev => prev.map(f => f.id === fileId ? { ...f, status: 'processing', progress: 0 } : f));
    setLoading(true);
    
    let rowCount = 0;
    const results: DataRow[] = [];
    let columns: string[] = [];

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      chunk: (chunk, parser) => {
        if (isAborted.current) {
          parser.abort();
          return;
        }
        
        const data = chunk.data as any[];
        rowCount += data.length;
        
        if (results.length < MAX_ROWS_FOR_FULL_LOAD) {
          const remaining = MAX_ROWS_FOR_FULL_LOAD - results.length;
          const toAdd = data.slice(0, remaining);
          results.push(...toAdd);
        }
        
        if (columns.length === 0 && chunk.meta.fields) {
          columns = chunk.meta.fields;
        }
        
        const progress = Math.min(99, Math.round((rowCount / 10000) * 10));
        setPendingFiles(prev => prev.map(f => f.id === fileId ? { ...f, progress } : f));
      },
      complete: () => {
        if (isAborted.current) {
          setLoading(false);
          return;
        }

        if (results.length === 0) {
          const errMsg = "The CSV file is empty or malformed.";
          setPendingFiles(prev => prev.map(f => f.id === fileId ? { ...f, status: 'error', error: errMsg } : f));
          setError(errMsg);
          setLoading(false);
          return;
        }

        // Sanitize columns
        const cleanColumns = columns.filter(Boolean);

        let finalData = results;
        if (selectedActions.length > 0) {
          finalData = DataCleaner.clean(results, selectedActions);
        }

        const columnTypes = DataAnalysisEngine.detectColumnTypes(cleanColumns, finalData);

        onDataLoaded({
          name: `${file.name}${rowCount > MAX_ROWS_FOR_FULL_LOAD ? ' [Sampled]' : ''}`,
          columns: cleanColumns,
          columnTypes,
          data: finalData,
          preview: finalData.slice(0, 20),
          rowCount
        });

        setPendingFiles(prev => prev.map(f => f.id === fileId ? { ...f, status: 'completed', progress: 100 } : f));
        setLoading(false);
      },
      error: (err) => {
        const errMsg = `CSV Parsing Error: ${err.message}`;
        setPendingFiles(prev => prev.map(f => f.id === fileId ? { ...f, status: 'error', error: errMsg } : f));
        setError(errMsg);
        setLoading(false);
      }
    });
  };

  /**
   * Processes a specific sheet from an Excel workbook
   */
  const processSheet = async (sheetName: string, overrideBuffer?: ArrayBuffer) => {
    const buffer = overrideBuffer || activeFileBuffer;
    if (!buffer) {
      console.error("No active file buffer found for processing.");
      return;
    }
    
    setLoading(true);
    setError(null);
    isAborted.current = false;

    try {
      console.group(`Processing Sheet: ${sheetName}`);
      
      // Read workbook with minimal memory footprint - use Uint8Array for better compatibility
      const data = new Uint8Array(buffer);
      let wb;
      try {
        // Try optimized read first
        wb = XLSX.read(data, { 
          type: 'array',
          sheets: [sheetName],
          cellDates: true,
          cellNF: false,
          cellText: false
        });

        // If the optimized read didn't actually load the sheet (some versions/formats behave differently)
        if (!wb.Sheets || !wb.Sheets[sheetName]) {
          console.warn("Optimized read did not return the requested sheet, falling back...");
          throw new Error("Sheet not in optimized result");
        }
      } catch (e) {
        console.warn("Optimized sheet read failed or incomplete, performing full read...");
        wb = XLSX.read(data, { type: 'array', cellDates: true });
      }

      let worksheet = wb.Sheets[sheetName];
      
      // Fallback 1: Case-insensitive or malformed name matching
      if (!worksheet) {
        const allSheetNames = wb.SheetNames && wb.SheetNames.length > 0 ? wb.SheetNames : Object.keys(wb.Sheets);
        console.log("Searching for sheet in:", allSheetNames);
        
        const actualName = allSheetNames.find(n => n.toLowerCase() === sheetName.toLowerCase());
        if (actualName) {
          console.log(`Found match with different casing: ${actualName}`);
          worksheet = wb.Sheets[actualName];
        }
        
        // Fallback 2: If there's only one sheet in the entire workbook, use it
        if (!worksheet && allSheetNames.length === 1) {
          console.log("Only one sheet available, using it as fallback");
          worksheet = wb.Sheets[allSheetNames[0]];
        }
      }

      if (!worksheet) {
        const available = Object.keys(wb.Sheets).join(", ") || "none";
        const names = (wb.SheetNames || []).join(", ") || "none";
        throw new Error(`Sheet "${sheetName}" not found. Available in Sheets: [${available}], in SheetNames: [${names}]`);
      }
      
      const ref = worksheet['!ref'];
      if (!ref) {
        // Handle empty sheet
        onDataLoaded({
          name: `${activeFileName} (${sheetName}) [Empty]`,
          columns: [],
          columnTypes: [],
          data: [],
          preview: [],
          rowCount: 0
        });
        setLoading(false);
        console.groupEnd();
        return;
      }
      
      const range = XLSX.utils.decode_range(ref);
      if (!range || !range.s || !range.e) throw new Error("Invalid sheet range detected.");

      const totalRows = range.e.r - range.s.r + 1;
      console.log(`Total rows detected: ${totalRows}`);
      
      // Extract headers more robustly
      const allRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
      const firstDataRowIndex = allRows.findIndex(row => row && row.length > 0);
      
      if (firstDataRowIndex === -1) {
        throw new Error("The sheet appears to be empty.");
      }

      const columns = allRows[firstDataRowIndex].map(String).filter(Boolean);
      const uniqueColumns = Array.from(new Set(columns));
      
      // Update range to start after headers if we found them
      const dataRange = { ...range, s: { ...range.s, r: range.s.r + firstDataRowIndex + 1 } };
      
      // Check if we actually have data rows after the header
      const hasDataRows = dataRange.s.r <= range.e.r;
      
      let allData: DataRow[] = [];

      if (!hasDataRows) {
        console.warn("No data rows found after header. Checking if header row itself contains data...");
        // If there's only one row and it looks like data (e.g. contains numbers), 
        // we might have misidentified it as a header.
        const headerRow = allRows[firstDataRowIndex];
        const looksLikeData = headerRow.some(val => typeof val === 'number' || (typeof val === 'string' && !isNaN(parseFloat(val))));
        
        if (looksLikeData) {
          console.log("Header row looks like data, treating it as a data row with generic headers.");
          const genericColumns = headerRow.map((_, i) => `Column ${i + 1}`);
          const singleRow = XLSX.utils.sheet_to_json(worksheet, { 
            range: { s: { ...range.s, r: range.s.r + firstDataRowIndex }, e: { ...range.e, r: range.s.r + firstDataRowIndex } },
            header: genericColumns
          }) as DataRow[];
          
          const columnTypes = DataAnalysisEngine.detectColumnTypes(genericColumns, singleRow);

          onDataLoaded({
            name: `${activeFileName} (${sheetName})`,
            columns: genericColumns,
            columnTypes,
            data: singleRow,
            preview: singleRow,
            rowCount: 1
          });
          setLoading(false);
          console.groupEnd();
          return;
        }
      }

      const shouldSample = totalRows > MAX_ROWS_FOR_FULL_LOAD;
      
      if (shouldSample) {
        console.log("Large dataset detected, using high-fidelity sampling...");
        const firstChunk = XLSX.utils.sheet_to_json(worksheet, { 
          range: { s: dataRange.s, e: { ...range.e, r: Math.min(dataRange.s.r + 5000, range.e.r) } },
          header: uniqueColumns
        }) as DataRow[];
        
        const mid = Math.floor(totalRows / 2);
        const midChunk = XLSX.utils.sheet_to_json(worksheet, { 
          range: { s: { ...range.s, r: mid }, e: { ...range.e, r: Math.min(mid + 2500, range.e.r) } },
          header: uniqueColumns
        }) as DataRow[];
        
        const lastChunk = XLSX.utils.sheet_to_json(worksheet, { 
          range: { s: { ...range.s, r: Math.max(range.e.r - 2500, range.s.r) }, e: range.e },
          header: uniqueColumns
        }) as DataRow[];
        
        allData = [...(firstChunk || []), ...(midChunk || []), ...(lastChunk || [])];
      } else {
        // Process in chunks to keep UI responsive
        for (let r = dataRange.s.r; r <= range.e.r; r += CHUNK_SIZE) {
          if (isAborted.current) break;
          
          const chunkRange = { 
            s: { ...range.s, r }, 
            e: { ...range.e, r: Math.min(r + CHUNK_SIZE - 1, range.e.r) } 
          };
          
          const chunk = XLSX.utils.sheet_to_json(worksheet, { 
            range: chunkRange,
            header: uniqueColumns
          }) as DataRow[];
          if (chunk && chunk.length > 0) {
            allData = [...allData, ...chunk];
          }
          
          const progress = Math.min(Math.round((r / totalRows) * 100), 100);
          setPendingFiles(prev => prev.map(f => f.file.name === activeFileName ? { ...f, progress } : f));
          await new Promise(resolve => setTimeout(resolve, 0));
        }
      }

      if (isAborted.current) {
        console.log("Processing aborted by user.");
        setLoading(false);
        console.groupEnd();
        return;
      }

      // Final validation and sanitization
      if (allData.length === 0) {
        throw new Error("No data rows found in this sheet. Please check if the file contains data below the header row.");
      }

      let sanitizedData = allData.map(row => FileValidator.sanitizeRow(row, uniqueColumns));

      // Apply cleaning actions
      if (selectedActions.length > 0) {
        sanitizedData = DataCleaner.clean(sanitizedData, selectedActions);
      }

      const columnTypes = DataAnalysisEngine.detectColumnTypes(uniqueColumns, sanitizedData);

      onDataLoaded({
        name: `${activeFileName} (${sheetName})${shouldSample ? ' [Sampled]' : ''}`,
        columns: uniqueColumns,
        columnTypes,
        data: sanitizedData,
        preview: sanitizedData.slice(0, 20),
        rowCount: totalRows
      });

      setPendingFiles(prev => prev.map(f => f.file.name === activeFileName ? { ...f, status: 'completed', progress: 100 } : f));
      setActiveFileBuffer(null);
      setSheets([]);
      console.log("Sheet processing complete.");
      console.groupEnd();
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : "Failed to parse sheet data.";
      console.error("Sheet processing error:", errMsg);
      setError(errMsg);
      setPendingFiles(prev => prev.map(f => f.file.name === activeFileName ? { ...f, status: 'error', error: errMsg } : f));
      console.groupEnd();
    } finally {
      setLoading(false);
    }
  };

  /**
   * Initial file handling and format detection
   */
  const handleFiles = async (files: FileList | File[]) => {
    setError(null);
    const newPending: PendingFile[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!FileValidator.isSupported(file.name)) {
        setError(`Unsupported file format: ${file.name}`);
        continue;
      }
      
      if (file.size === 0) {
        setError(`File is empty (0 bytes): ${file.name}`);
        continue;
      }

      newPending.push({
        id: Math.random().toString(36).substr(2, 9),
        file,
        status: 'pending',
        progress: 0
      });
    }

    if (newPending.length === 0) return;

    setPendingFiles(prev => [...prev, ...newPending]);
    
    // Auto-process the first new file if nothing is loading
    const nextToProcess = newPending[0];
    if (!loading) {
      startProcessing(nextToProcess);
    }
  };

  const startProcessing = async (pending: PendingFile) => {
    const { file, id } = pending;
    setLoading(true);
    isAborted.current = false;
    setActiveFileName(file.name);

    if (file.name.endsWith('.csv')) {
      processCSV(id, file);
      return;
    }

    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const buffer = e.target?.result as ArrayBuffer;
          if (!buffer) throw new Error("Failed to read file buffer.");
          
          setActiveFileBuffer(buffer);

          // Use Uint8Array for maximum compatibility with all Excel formats (xlsx, xls, xlsb, ods, etc.)
          const data = new Uint8Array(buffer);
          
          let wb;
          try {
            // Standard read - optimized for data extraction
            wb = XLSX.read(data, { 
              type: 'array',
              cellDates: true,
              cellNF: false,
              cellText: false,
              bookProps: false
            });
          } catch (readErr) {
            console.warn("Standard read failed, trying recovery...", readErr);
            try {
              // Basic fallback
              wb = XLSX.read(data, { type: 'array' });
            } catch (fallbackErr) {
              // Check for CSV/HTML mislabeling
              const header = new TextDecoder().decode(data.slice(0, 500));
              if (header.includes(',') || header.includes(';') || header.includes('\t')) {
                processCSV(id, file);
                return;
              }
              throw new Error("This file format is not recognized or the file is corrupted.");
            }
          }
          
          if (!wb || !wb.SheetNames || wb.SheetNames.length === 0) {
            // Check for hidden sheets or malformed workbook structure
            const sheetKeys = wb?.Sheets ? Object.keys(wb.Sheets) : [];
            if (sheetKeys.length > 0) {
              wb.SheetNames = sheetKeys;
            } else {
              throw new Error("No readable data found in this file. Please ensure it's a valid Excel or CSV file.");
            }
          }

          const metadata = getSheetMetadata(wb);
          setSheets(metadata);

          // If only one sheet, auto-process it
          if (wb.SheetNames.length === 1) {
            await processSheet(wb.SheetNames[0], buffer);
          } else {
            setLoading(false);
            setPendingFiles(prev => prev.map(f => f.id === id ? { ...f, status: 'processing', progress: 50 } : f));
          }
        } catch (err) {
          const errMsg = err instanceof Error ? err.message : "Failed to parse workbook structure.";
          setError(errMsg);
          setPendingFiles(prev => prev.map(f => f.id === id ? { ...f, status: 'error', error: errMsg } : f));
          setLoading(false);
        }
      };
      
      reader.onerror = () => {
        setError("File reading failed.");
        setLoading(false);
      };
      
      reader.readAsArrayBuffer(file);
    } catch (err) {
      setError("An unexpected error occurred during file reading.");
      setLoading(false);
    }
  };

  const removeFile = (id: string) => {
    setPendingFiles(prev => prev.filter(f => f.id !== id));
    if (activeFileName === pendingFiles.find(f => f.id === id)?.file.name) {
      setActiveFileBuffer(null);
      setSheets([]);
      setActiveFileName("");
    }
  };

  // Auto-process next file in queue
  React.useEffect(() => {
    if (!loading && pendingFiles.length > 0) {
      const nextPending = pendingFiles.find(f => f.status === 'pending');
      if (nextPending) {
        startProcessing(nextPending);
      }
    }
  }, [loading, pendingFiles]);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files) {
      handleFiles(e.dataTransfer.files);
    }
  }, [loading]);

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(e.target.files);
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6">
      {/* Upload Area */}
      <div
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={onDrop}
        className={cn(
          "relative border-2 border-dashed rounded-3xl p-10 transition-all duration-300 flex flex-col items-center justify-center gap-4 cursor-pointer overflow-hidden",
          isDragging ? "border-indigo-500 bg-indigo-50/50 scale-[1.01]" : "border-slate-200 hover:border-indigo-400 hover:bg-slate-50/50",
          loading && "opacity-75 pointer-events-none"
        )}
      >
        <input
          type="file"
          className="absolute inset-0 opacity-0 cursor-pointer"
          accept=".xlsx,.xls,.csv"
          onChange={onFileChange}
          multiple
          disabled={loading}
        />
        
        <div className="relative">
          <div className="p-5 rounded-2xl bg-indigo-100 text-indigo-600">
            {loading ? <Loader2 className="w-10 h-10 animate-spin" /> : <Upload className="w-10 h-10" />}
          </div>
          {loading && (
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-600 rounded-full border-2 border-white animate-pulse" />
          )}
        </div>
        
        <div className="text-center space-y-2">
          <h3 className="text-xl font-bold text-slate-900">
            {loading ? "Processing Data..." : "Upload Datasets"}
          </h3>
          <p className="text-sm text-slate-500 max-w-xs mx-auto">
            Drag and drop multiple Excel or CSV files. We'll handle the heavy lifting.
          </p>
        </div>

        <div className="flex items-center gap-6 mt-2">
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span>Fast Parsing</span>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            <Database className="w-3.5 h-3.5 text-indigo-400" />
            <span>Any Size</span>
          </div>
        </div>
      </div>

      {/* Cleaning Tools Section */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <Settings2 className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">Cleaning Tools</h4>
              <p className="text-xs text-slate-500">Apply these before finalizing your data</p>
            </div>
          </div>
          {sheets.length === 1 && (
            <button
              onClick={() => scanWithAi(sheets[0].name)}
              disabled={isAiScanning || loading}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50"
            >
              {isAiScanning ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
              AI Smart Clean
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {[
            { id: 'trim', label: 'Trim', icon: Eraser },
            { id: 'lowercase', label: 'lower', icon: null },
            { id: 'uppercase', label: 'UPPER', icon: null },
            { id: 'titlecase', label: 'Title', icon: null },
            { id: 'numeric', label: 'Num', icon: Wand2 },
            { id: 'remove_nulls', label: 'No Nulls', icon: FilterX },
            { id: 'normalize_dates', label: 'Dates', icon: Calendar },
          ].map((action) => (
            <button
              key={action.id}
              onClick={() => toggleAction(action.id as CleaningAction)}
              className={cn(
                "flex items-center justify-center gap-2 px-2 py-2.5 rounded-xl border text-[10px] font-bold uppercase tracking-wider transition-all",
                selectedActions.includes(action.id as CleaningAction)
                  ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-200"
                  : "bg-white border-slate-200 text-slate-600 hover:border-indigo-200 hover:bg-slate-50"
              )}
            >
              {action.icon && <action.icon className="w-3 h-3" />}
              {action.label}
            </button>
          ))}
        </div>

        {aiSuggestions.length > 0 && (
          <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-4 space-y-3 animate-in fade-in slide-in-from-top-2">
            <div className="flex items-center gap-2 text-indigo-700">
              <Sparkles className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">AI Recommendations</span>
            </div>
            <div className="space-y-2">
              {aiSuggestions.map((s, i) => (
                <div key={i} className="flex gap-3 text-xs">
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
                  <div>
                    <span className="font-bold text-slate-700">{s.issue}:</span>
                    <span className="text-slate-600 ml-1">{s.recommendation}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Pending Files List */}
      {pendingFiles.length > 0 && (
        <div className="space-y-3 animate-in fade-in slide-in-from-bottom-4">
          <div className="flex items-center justify-between px-2">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">File Queue</h4>
            <button 
              onClick={() => setPendingFiles([])}
              className="text-[10px] font-bold text-rose-500 hover:underline"
            >
              Clear All
            </button>
          </div>
          
          <div className="grid grid-cols-1 gap-3">
            {pendingFiles.map((pf) => (
              <div 
                key={pf.id}
                className={cn(
                  "bg-white border rounded-2xl p-4 flex items-center justify-between gap-4 transition-all",
                  pf.status === 'processing' ? "border-indigo-200 ring-1 ring-indigo-100" : "border-slate-200"
                )}
              >
                <div className="flex items-center gap-4 flex-1 min-w-0">
                  <div className={cn(
                    "p-2.5 rounded-xl shrink-0",
                    pf.status === 'completed' ? "bg-emerald-50 text-emerald-600" : 
                    pf.status === 'error' ? "bg-rose-50 text-rose-600" : "bg-slate-50 text-slate-400"
                  )}>
                    {pf.file.name.endsWith('.csv') ? <FileText className="w-5 h-5" /> : <FileSpreadsheet className="w-5 h-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-700 truncate">{pf.file.name}</span>
                      {pf.status === 'completed' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />}
                      {pf.status === 'error' && <AlertCircle className="w-3.5 h-3.5 text-rose-500" />}
                    </div>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-[10px] text-slate-400">{(pf.file.size / 1024).toFixed(1)} KB</span>
                      {pf.status === 'processing' && (
                        <div className="flex-1 h-1 bg-slate-100 rounded-full overflow-hidden max-w-[100px]">
                          <div 
                            className="h-full bg-indigo-500 transition-all duration-300" 
                            style={{ width: `${pf.progress}%` }}
                          />
                        </div>
                      )}
                      {pf.status === 'error' && <span className="text-[10px] text-rose-500 font-medium truncate">{pf.error}</span>}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  {pf.status === 'pending' && (
                    <button 
                      onClick={() => startProcessing(pf)}
                      className="p-2 hover:bg-indigo-50 text-indigo-600 rounded-lg transition-colors"
                      title="Start Processing"
                    >
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  )}
                  <button 
                    onClick={() => removeFile(pf.id)}
                    className="p-2 hover:bg-slate-100 text-slate-400 hover:text-rose-500 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sheet Selection Modal-like UI */}
      {sheets.length > 1 && !loading && (
        <div className="bg-white border-2 border-indigo-100 rounded-3xl p-8 shadow-xl shadow-indigo-100/50 animate-in zoom-in-95 duration-300">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-indigo-600 text-white rounded-2xl">
                <Layers className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900">Workbook Detected</h3>
                <p className="text-sm text-slate-500">Pick a sheet to analyze from <span className="font-semibold text-slate-700">{activeFileName}</span></p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
            {sheets.map((sheet) => (
              <button
                key={sheet.name}
                onClick={() => processSheet(sheet.name)}
                className="flex flex-col p-5 rounded-2xl border border-slate-100 hover:border-indigo-300 hover:bg-indigo-50/30 text-left transition-all group relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity">
                  <ArrowRight className="w-4 h-4 text-indigo-500" />
                </div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 rounded-xl bg-slate-50 group-hover:bg-white transition-colors">
                    <TableIcon className="w-5 h-5 text-slate-400 group-hover:text-indigo-500" />
                  </div>
                  <span className="font-bold text-slate-800 group-hover:text-indigo-900 truncate">{sheet.name}</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5">
                    <Rows className="w-3.5 h-3.5 text-slate-300" />
                    <span className="text-xs font-medium text-slate-500">{sheet.rowCount.toLocaleString()} rows</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5 text-slate-300" />
                    <span className="text-xs font-medium text-slate-500">{sheet.columnCount} cols</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
          
          <div className="mt-8 p-5 rounded-2xl bg-indigo-50/50 border border-indigo-100 flex items-start gap-4">
            <Info className="w-5 h-5 text-indigo-600 mt-0.5 shrink-0" />
            <div className="space-y-1">
              <p className="text-sm font-bold text-indigo-900">Selective Sheet Loading</p>
              <p className="text-xs text-indigo-700/70 leading-relaxed">
                We only load the data for the sheet you select to keep the application fast and memory-efficient.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Global Error Display */}
      {error && (
        <div className="p-5 rounded-2xl bg-rose-50 border border-rose-100 flex items-start gap-4 text-rose-700 animate-in fade-in slide-in-from-top-4">
          <div className="p-2 bg-rose-100 rounded-xl">
            <AlertCircle className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <h4 className="font-bold text-sm">Upload Error</h4>
            <p className="text-xs opacity-90 leading-relaxed">{error}</p>
            <button 
              onClick={() => setError(null)}
              className="text-[10px] font-bold uppercase tracking-widest mt-2 hover:underline"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
