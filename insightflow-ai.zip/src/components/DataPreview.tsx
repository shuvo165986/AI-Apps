import React from 'react';
import { DatasetInfo } from '../types';

interface DataPreviewProps {
  dataset: DatasetInfo;
}

export default function DataPreview({ dataset }: DataPreviewProps) {
  if (!dataset) return null;

  const columns = dataset.columns || [];
  const preview = dataset.preview || [];

  return (
    <div className="w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
      <div className="px-6 py-4 border-bottom border-slate-100 bg-slate-50/50 flex items-center justify-between">
        <h3 className="font-semibold text-slate-900">Dataset Preview</h3>
        <span className="text-xs font-medium px-2 py-1 rounded-full bg-slate-200 text-slate-600">
          Showing first 10 rows of {dataset.rowCount || 0}
        </span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50 border-b border-slate-200">
              {columns.map((col) => (
                <th key={col} className="px-6 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {preview.map((row, i) => (
              <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                {columns.map((col) => (
                  <td key={col} className="px-6 py-3 text-sm text-slate-600 whitespace-nowrap">
                    {String(row?.[col] ?? '-')}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
