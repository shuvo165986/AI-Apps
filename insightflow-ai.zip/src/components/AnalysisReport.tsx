import React from 'react';
import { 
  FileSearch, 
  ShieldAlert, 
  BarChart3, 
  TrendingUp, 
  Zap, 
  Lightbulb, 
  LayoutDashboard, 
  CheckCircle2,
  Wrench,
  Sparkles
} from 'lucide-react';
import { AnalysisResult } from '../types';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface AnalysisReportProps {
  analysis: AnalysisResult;
}

export default function AnalysisReport({ analysis }: AnalysisReportProps) {
  const sections = [
    { title: 'Dataset Overview', icon: FileSearch, content: analysis?.overview || '', color: 'text-blue-600', bg: 'bg-blue-50' },
    { title: 'Data Quality Check', icon: ShieldAlert, items: analysis?.qualityIssues || [], color: 'text-amber-600', bg: 'bg-amber-50' },
    { title: 'Key Statistics', icon: BarChart3, content: analysis?.statistics || '', color: 'text-indigo-600', bg: 'bg-indigo-50' },
    { title: 'Trends & Patterns', icon: TrendingUp, content: analysis?.trends || '', color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { title: 'Outliers & Anomalies', icon: Zap, content: analysis?.outliers || '', color: 'text-rose-600', bg: 'bg-rose-50' },
    { title: 'Business Insights', icon: Lightbulb, content: analysis?.insights || '', color: 'text-purple-600', bg: 'bg-purple-50' },
    { title: 'Dashboard Structure', icon: LayoutDashboard, content: analysis?.dashboardStructure || '', color: 'text-slate-600', bg: 'bg-slate-50' },
  ];

  return (
    <div className="space-y-8 mt-12">
      {analysis.queryUsed && (
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-3 bg-indigo-50 border border-indigo-100 p-4 rounded-2xl"
        >
          <div className="p-2 bg-indigo-600 text-white rounded-lg">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Analysis Focus</p>
            <p className="text-sm font-bold text-indigo-900">"{analysis.queryUsed}"</p>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {sections.map((section, index) => (
          <motion.div
            key={section.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className={`p-2 rounded-lg ${section.bg} ${section.color}`}>
                <section.icon className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900">{section.title}</h3>
            </div>
            
            {section.items ? (
              <ul className="space-y-2">
                {section.items?.map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                    <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-slate-400 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-wrap">
                {section.content}
              </p>
            )}
          </motion.div>
        ))}
      </div>

      {analysis?.cleaningRecommendations && analysis.cleaningRecommendations.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white overflow-hidden rounded-3xl border border-slate-200 shadow-sm"
        >
          <div className="bg-slate-900 p-6 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-white/10 text-orange-400">
                <Wrench className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Data Cleaning Guide</h3>
                <p className="text-xs text-slate-400 mt-0.5">Detected {analysis.cleaningRecommendations.length} critical data quality issues</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Health Score</div>
              <div className={cn(
                "text-2xl font-black px-3 py-1 rounded-lg",
                analysis.cleaningRecommendations.length > 5 ? "bg-rose-500/20 text-rose-400" : 
                analysis.cleaningRecommendations.length > 2 ? "bg-amber-500/20 text-amber-400" : 
                "bg-emerald-500/20 text-emerald-400"
              )}>
                {Math.max(0, 100 - (analysis.cleaningRecommendations.length * 12))}%
              </div>
            </div>
          </div>
          
          <div className="p-6 grid grid-cols-1 gap-4">
            {analysis.cleaningRecommendations.map((rec, i) => (
              <div key={i} className="group p-5 rounded-2xl bg-slate-50 border border-slate-100 hover:border-indigo-200 hover:bg-white transition-all">
                <div className="flex flex-col md:flex-row md:items-start gap-6">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-2 h-2 rounded-full bg-rose-500" />
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Issue Detected</span>
                    </div>
                    <p className="text-sm font-bold text-slate-900 leading-snug">{rec?.issue || 'Unknown Issue'}</p>
                  </div>
                  <div className="hidden md:block w-px h-12 bg-slate-200 self-center" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-2 h-2 rounded-full bg-indigo-500" />
                      <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">Recommended Action</span>
                    </div>
                    <p className="text-sm text-slate-600 leading-relaxed">{rec?.recommendation || 'No recommendation provided'}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-indigo-600 p-8 rounded-3xl text-white shadow-xl shadow-indigo-200"
      >
        <div className="flex items-center gap-3 mb-6">
          <CheckCircle2 className="w-6 h-6" />
          <h3 className="text-xl font-bold">Actionable Recommendations</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {analysis.recommendations?.map((rec, i) => (
            <div key={i} className="bg-white/10 backdrop-blur-sm p-4 rounded-xl border border-white/20">
              <p className="text-sm font-medium">{rec}</p>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
