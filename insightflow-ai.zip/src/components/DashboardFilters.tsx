import React, { useMemo, useState } from 'react';
import { Filter, X, Calendar, Tag, Plus, Search } from 'lucide-react';
import { DataRow, ColumnTypeInfo } from '../types';
import { cn } from '../lib/utils';

interface DashboardFiltersProps {
  data: DataRow[];
  columns: string[];
  columnTypes: ColumnTypeInfo[];
  filters: Record<string, any>;
  onFilterChange: (column: string, value: any) => void;
  onClearFilters: () => void;
}

export default function DashboardFilters({ 
  data, 
  columns, 
  columnTypes,
  filters, 
  onFilterChange, 
  onClearFilters 
}: DashboardFiltersProps) {
  const [showAddFilter, setShowAddFilter] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  const categoricalColumns = useMemo(() => {
    return columnTypes.filter(t => t.type === 'categorical').map(t => t.name);
  }, [columnTypes]);

  const dateColumns = useMemo(() => {
    return columnTypes.filter(t => t.type === 'date').map(t => t.name);
  }, [columnTypes]);

  const otherColumns = useMemo(() => {
    if (!columns) return [];
    const existing = [...categoricalColumns, ...dateColumns];
    return columns.filter(col => !existing.includes(col));
  }, [columns, categoricalColumns, dateColumns]);

  const activeFilterKeys = Object.keys(filters);
  const hasActiveFilters = activeFilterKeys.length > 0;

  const getOptionsForColumn = (col: string) => {
    return Array.from(new Set(data.map(row => row?.[col])))
      .filter(val => val !== null && val !== undefined && val !== '')
      .sort();
  };

  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm mb-8 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
            <Filter className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900">Dashboard Filters</h3>
            <p className="text-xs text-slate-500">Refine your data analysis in real-time</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {hasActiveFilters && (
            <button 
              onClick={onClearFilters}
              className="px-3 py-1.5 text-xs font-bold text-rose-500 hover:bg-rose-50 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <X className="w-3.5 h-3.5" />
              Reset
            </button>
          )}
          <div className="relative">
            <button 
              onClick={() => setShowAddFilter(!showAddFilter)}
              className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-2 hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Filter
            </button>
            
            {showAddFilter && (
              <div className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 p-2 animate-in fade-in zoom-in-95 duration-200">
                <div className="p-2 border-b border-slate-100 mb-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                    <input 
                      type="text"
                      placeholder="Search columns..."
                      className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      autoFocus
                    />
                  </div>
                </div>
                <div className="max-h-60 overflow-y-auto custom-scrollbar">
                  {columns
                    .filter(col => col.toLowerCase().includes(searchTerm.toLowerCase()))
                    .map(col => (
                      <button
                        key={col}
                        onClick={() => {
                          if (!filters[col]) onFilterChange(col, '');
                          setShowAddFilter(false);
                          setSearchTerm('');
                        }}
                        className="w-full text-left px-3 py-2 text-xs font-medium text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition-colors flex items-center justify-between"
                      >
                        {col}
                        {filters[col] !== undefined && <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />}
                      </button>
                    ))
                  }
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Filter Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {/* Always show categorical and date columns that have active filters or are "important" */}
        {[...categoricalColumns, ...dateColumns, ...activeFilterKeys]
          .filter((col, index, self) => self.indexOf(col) === index) // Unique
          .filter(col => !col.endsWith('_start') && !col.endsWith('_end')) // Filter out range keys
          .map(col => {
            const isDate = dateColumns.includes(col);
            const options = getOptionsForColumn(col);
            
            if (isDate) {
              return (
                <div key={col} className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                      <Calendar className="w-3 h-3 text-indigo-500" />
                      {col}
                    </label>
                    {(filters[`${col}_start`] || filters[`${col}_end`]) && (
                      <button 
                        onClick={() => {
                          onFilterChange(`${col}_start`, '');
                          onFilterChange(`${col}_end`, '');
                        }}
                        className="text-slate-400 hover:text-rose-500"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input 
                      type="date"
                      value={filters[`${col}_start`] || ''}
                      onChange={(e) => onFilterChange(`${col}_start`, e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-[10px] focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                    />
                    <input 
                      type="date"
                      value={filters[`${col}_end`] || ''}
                      onChange={(e) => onFilterChange(`${col}_end`, e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-[10px] focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                    />
                  </div>
                </div>
              );
            }

            return (
              <div key={col} className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                    <Tag className="w-3 h-3 text-emerald-500" />
                    {col}
                  </label>
                  {filters[col] && (
                    <button 
                      onClick={() => onFilterChange(col, '')}
                      className="text-slate-400 hover:text-rose-500"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
                <select 
                  value={filters[col] || ''}
                  onChange={(e) => onFilterChange(col, e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all appearance-none cursor-pointer"
                >
                  <option value="">All {col}s</option>
                  {options.map(opt => (
                    <option key={String(opt)} value={String(opt)}>{String(opt)}</option>
                  ))}
                </select>
              </div>
            );
          })
        }
      </div>
      
      {!hasActiveFilters && categoricalColumns.length === 0 && dateColumns.length === 0 && (
        <div className="text-center py-6 border-2 border-dashed border-slate-100 rounded-2xl">
          <p className="text-sm text-slate-400">Click "Add Filter" to start filtering your dashboard</p>
        </div>
      )}
    </div>
  );
}
