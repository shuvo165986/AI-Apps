import React, { useState, useMemo } from 'react';
import { 
  Wand2, 
  Table, 
  Calendar, 
  BarChart, 
  Download, 
  ChevronRight, 
  Check,
  AlertCircle,
  ArrowRightLeft,
  PieChart,
  Calculator,
  Plus
} from 'lucide-react';
import { DatasetInfo, DataRow, ColumnTypeInfo } from '../types';
import { DataTransformer } from '../lib/dataTransformer';
import { DataAnalysisEngine } from '../lib/dataAnalysis';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface DataActionsProps {
  dataset: DatasetInfo;
  onDataUpdated: (newData: DatasetInfo) => void;
}

export default function DataActions({ dataset, onDataUpdated }: DataActionsProps) {
  const [activeTab, setActiveTab] = useState<'summarize' | 'enrich' | 'advanced' | 'export'>('summarize');
  const [groupBy, setGroupBy] = useState('');
  const [pivotCol, setPivotCol] = useState('');
  const [aggregateBy, setAggregateBy] = useState('');
  const [aggType, setAggType] = useState<'sum' | 'avg' | 'count'>('sum');
  const [isProcessing, setIsProcessing] = useState(false);

  // Advanced states
  const [calcColA, setCalcColA] = useState('');
  const [calcColB, setCalcColB] = useState('');
  const [calcOp, setCalcOp] = useState<'+' | '-' | '*' | '/'>('+');
  const [calcName, setCalcName] = useState('');
  const [corrColA, setCorrColA] = useState('');
  const [corrColB, setCorrColB] = useState('');
  const [correlation, setCorrelation] = useState<number | null>(null);

  const { numericCols, categoricalCols, dateCols } = useMemo(() => {
    const numeric = dataset.columnTypes.filter(t => t.type === 'numeric').map(t => t.name);
    const categorical = dataset.columnTypes.filter(t => t.type === 'categorical').map(t => t.name);
    const date = dataset.columnTypes.filter(t => t.type === 'date').map(t => t.name);
    return { numericCols: numeric, categoricalCols: categorical, dateCols: date };
  }, [dataset]);

  const handleAggregate = () => {
    if (!groupBy || !aggregateBy) return;
    setIsProcessing(true);
    
    // Small delay to show loading state
    setTimeout(() => {
      let result;
      if (pivotCol) {
        result = DataTransformer.pivot(dataset.data, groupBy, pivotCol, aggregateBy, aggType);
      } else {
        result = DataTransformer.aggregate(dataset.data, groupBy, aggregateBy, aggType);
      }
      
      const newColumnTypes = DataAnalysisEngine.detectColumnTypes(result.columns, result.data);
      
      onDataUpdated({
        name: `${dataset.name} (${pivotCol ? 'Pivot' : 'Summary'} by ${groupBy})`,
        columns: result.columns,
        columnTypes: newColumnTypes,
        data: result.data,
        preview: result.data.slice(0, 20),
        rowCount: result.data.length
      });
      setIsProcessing(false);
    }, 500);
  };

  const handleCalculate = () => {
    if (!calcColA || !calcColB || !calcName) return;
    setIsProcessing(true);
    setTimeout(() => {
      const newData = DataTransformer.calculateField(dataset.data, calcColA, calcColB, calcOp, calcName);
      const newCols = [...dataset.columns, calcName];
      const newColumnTypes = DataAnalysisEngine.detectColumnTypes(newCols, newData);
      
      onDataUpdated({
        ...dataset,
        name: `${dataset.name} (Calculated)`,
        columns: newCols,
        columnTypes: newColumnTypes,
        data: newData,
        preview: newData.slice(0, 20)
      });
      setIsProcessing(false);
      setCalcName('');
    }, 500);
  };

  const handleCorrelation = () => {
    if (!corrColA || !corrColB) return;
    const corr = DataTransformer.calculateCorrelation(dataset.data, corrColA, corrColB);
    setCorrelation(corr);
  };

  const handleEnrich = (dateCol: string) => {
    setIsProcessing(true);
    setTimeout(() => {
      const enrichedData = DataTransformer.extractTimeFeatures(dataset.data, dateCol);
      const newCols = Array.from(new Set([...dataset.columns, ...Object.keys(enrichedData[0])]));
      const newColumnTypes = DataAnalysisEngine.detectColumnTypes(newCols, enrichedData);
      
      onDataUpdated({
        ...dataset,
        name: `${dataset.name} (Time Enriched)`,
        columns: newCols,
        columnTypes: newColumnTypes,
        data: enrichedData,
        preview: enrichedData.slice(0, 20)
      });
      setIsProcessing(false);
    }, 500);
  };

  const exportToCSV = () => {
    const headers = dataset.columns.join(',');
    const rows = dataset.data.map(row => 
      dataset.columns.map(col => {
        const val = row[col];
        return typeof val === 'string' && val.includes(',') ? `"${val}"` : val;
      }).join(',')
    );
    
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${dataset.name.replace(/\s+/g, '_')}_actionable.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
      <div className="bg-slate-900 p-6 text-white">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500 rounded-xl">
            <Wand2 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Actionable Data Studio</h3>
            <p className="text-xs text-slate-400 mt-0.5">Convert raw rows into business intelligence</p>
          </div>
        </div>
      </div>

      <div className="flex border-b border-slate-100">
        {[
          { id: 'summarize', label: 'Summarize', icon: Table },
          { id: 'enrich', label: 'Enrich', icon: Calculator },
          { id: 'advanced', label: 'Advanced', icon: BarChart },
          { id: 'export', label: 'Export', icon: Download },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-4 text-xs font-bold uppercase tracking-wider transition-all border-b-2",
              activeTab === tab.id 
                ? "border-indigo-600 text-indigo-600 bg-indigo-50/30" 
                : "border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-50"
            )}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="p-8">
        <AnimatePresence mode="wait">
          {activeTab === 'summarize' && (
            <motion.div
              key="summarize"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Group By (Category)</label>
                  <select 
                    value={groupBy}
                    onChange={(e) => setGroupBy(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none"
                  >
                    <option value="">Select Column...</option>
                    {categoricalCols.map(col => <option key={col} value={col}>{col}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Aggregate (Value)</label>
                  <select 
                    value={aggregateBy}
                    onChange={(e) => setAggregateBy(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none"
                  >
                    <option value="">Select Column...</option>
                    {numericCols.map(col => <option key={col} value={col}>{col}</option>)}
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Pivot By (Optional Column Grouping)</label>
                <select 
                  value={pivotCol}
                  onChange={(e) => setPivotCol(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none"
                >
                  <option value="">None (Simple Summary)</option>
                  {categoricalCols.filter(c => c !== groupBy).map(col => <option key={col} value={col}>{col}</option>)}
                </select>
                <p className="text-[10px] text-slate-400 italic">Creating a pivot table will turn unique values of this column into new columns.</p>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex bg-slate-100 p-1 rounded-xl">
                  {['sum', 'avg', 'count'].map((type) => (
                    <button
                      key={type}
                      onClick={() => setAggType(type as any)}
                      className={cn(
                        "px-4 py-1.5 rounded-lg text-xs font-bold capitalize transition-all",
                        aggType === type ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                      )}
                    >
                      {type}
                    </button>
                  ))}
                </div>
                <button
                  onClick={handleAggregate}
                  disabled={!groupBy || !aggregateBy || isProcessing}
                  className="flex-1 bg-indigo-600 text-white py-2.5 rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isProcessing ? <Wand2 className="w-4 h-4 animate-spin" /> : <PieChart className="w-4 h-4" />}
                  Generate Summary Dataset
                </button>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl flex gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
                <p className="text-xs text-amber-700 leading-relaxed">
                  Summarizing creates a new dataset view. You can always switch back to the original raw data from the sidebar.
                </p>
              </div>
            </motion.div>
          )}

          {activeTab === 'enrich' && (
            <motion.div
              key="enrich"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="space-y-6"
            >
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-slate-900">Time-Series Enrichment</h4>
                <p className="text-xs text-slate-500">Select a date column to automatically extract Year, Month, Day of Week, and Quarter features.</p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {dateCols.map(col => (
                    <button
                      key={col}
                      onClick={() => handleEnrich(col)}
                      disabled={isProcessing}
                      className="flex items-center justify-between p-4 rounded-2xl border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/30 transition-all text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-100 rounded-lg group-hover:bg-white transition-colors">
                          <Calendar className="w-4 h-4 text-slate-500 group-hover:text-indigo-600" />
                        </div>
                        <span className="text-sm font-bold text-slate-700">{col}</span>
                      </div>
                      <ArrowRightLeft className="w-4 h-4 text-slate-300 group-hover:text-indigo-400" />
                    </button>
                  ))}
                  {dateCols.length === 0 && (
                    <div className="col-span-2 p-8 text-center border-2 border-dashed border-slate-100 rounded-3xl">
                      <p className="text-sm text-slate-400">No valid date columns detected in this dataset.</p>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'advanced' && (
            <motion.div
              key="advanced"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="space-y-10"
            >
              {/* Calculated Fields */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-indigo-600" />
                  <h4 className="text-sm font-bold text-slate-900">Calculated Columns (Power Query Style)</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Column A</label>
                    <select 
                      value={calcColA}
                      onChange={(e) => setCalcColA(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none"
                    >
                      <option value="">Select...</option>
                      {numericCols.map(col => <option key={col} value={col}>{col}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Op</label>
                    <select 
                      value={calcOp}
                      onChange={(e) => setCalcOp(e.target.value as any)}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none"
                    >
                      <option value="+">+</option>
                      <option value="-">-</option>
                      <option value="*">×</option>
                      <option value="/">÷</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Column B</label>
                    <select 
                      value={calcColB}
                      onChange={(e) => setCalcColB(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none"
                    >
                      <option value="">Select...</option>
                      {numericCols.map(col => <option key={col} value={col}>{col}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">New Name</label>
                    <input 
                      type="text"
                      placeholder="e.g. Profit"
                      value={calcName}
                      onChange={(e) => setCalcName(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none"
                    />
                  </div>
                </div>
                <button
                  onClick={handleCalculate}
                  disabled={!calcColA || !calcColB || !calcName || isProcessing}
                  className="w-full py-2 bg-indigo-50 text-indigo-600 rounded-xl text-xs font-bold hover:bg-indigo-100 transition-all flex items-center justify-center gap-2"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Create Calculated Column
                </button>
              </div>

              {/* Correlation Analysis */}
              <div className="space-y-4 pt-6 border-t border-slate-100">
                <div className="flex items-center gap-2">
                  <BarChart className="w-4 h-4 text-emerald-600" />
                  <h4 className="text-sm font-bold text-slate-900">Statistical Correlation</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Variable 1</label>
                    <select 
                      value={corrColA}
                      onChange={(e) => setCorrColA(e.target.value)}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none"
                    >
                      <option value="">Select...</option>
                      {numericCols.map(col => <option key={col} value={col}>{col}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Variable 2</label>
                    <select 
                      value={corrColB}
                      onChange={(e) => setCorrColB(e.target.value)}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none"
                    >
                      <option value="">Select...</option>
                      {numericCols.map(col => <option key={col} value={col}>{col}</option>)}
                    </select>
                  </div>
                </div>
                <button
                  onClick={handleCorrelation}
                  disabled={!corrColA || !corrColB}
                  className="w-full py-3 bg-emerald-50 text-emerald-600 rounded-xl text-xs font-bold hover:bg-emerald-100 transition-all"
                >
                  Calculate Pearson Correlation
                </button>

                {correlation !== null && (
                  <motion.div 
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 bg-slate-900 rounded-2xl text-white flex items-center justify-between"
                  >
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Correlation Coefficient</p>
                      <p className="text-2xl font-bold">{correlation.toFixed(4)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Strength</p>
                      <p className={cn(
                        "text-sm font-bold",
                        Math.abs(correlation) > 0.7 ? "text-emerald-400" : 
                        Math.abs(correlation) > 0.3 ? "text-amber-400" : "text-slate-400"
                      )}>
                        {Math.abs(correlation) > 0.7 ? "Strong" : 
                         Math.abs(correlation) > 0.3 ? "Moderate" : "Weak"}
                        {correlation > 0 ? " Positive" : " Negative"}
                      </p>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === 'export' && (
            <motion.div
              key="export"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="flex flex-col items-center justify-center py-10 space-y-6"
            >
              <div className="p-6 bg-emerald-50 text-emerald-600 rounded-full">
                <Download className="w-12 h-12" />
              </div>
              <div className="text-center space-y-2">
                <h4 className="text-xl font-bold text-slate-900">Ready for Action</h4>
                <p className="text-sm text-slate-500">Download your cleaned and transformed dataset as a CSV file.</p>
              </div>
              <button
                onClick={exportToCSV}
                className="px-10 py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all flex items-center gap-3"
              >
                <Download className="w-5 h-5" />
                Download Actionable CSV
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
