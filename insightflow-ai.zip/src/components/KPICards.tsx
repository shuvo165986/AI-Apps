import React, { useMemo } from 'react';
import { 
  Users, 
  TrendingUp, 
  Activity, 
  Database,
  Layers,
  FileSpreadsheet
} from 'lucide-react';
import { DatasetInfo } from '../types';
import { DataAnalysisEngine } from '../lib/dataAnalysis';
import { motion } from 'motion/react';

interface KPICardsProps {
  dataset: DatasetInfo;
}

export default function KPICards({ dataset }: KPICardsProps) {
  const stats = useMemo(() => 
    DataAnalysisEngine.calculateStats(dataset.columns, dataset.data, dataset.columnTypes),
    [dataset]
  );

  const kpis = useMemo(() => {
    const numericStats = stats.filter(s => s.type === 'numeric');
    const categoricalStats = stats.filter(s => s.type === 'categorical');
    
    return [
      { 
        label: 'Total Rows', 
        value: dataset.rowCount.toLocaleString(), 
        icon: Database, 
        color: 'text-blue-600', 
        bg: 'bg-blue-50' 
      },
      { 
        label: 'Dimensions', 
        value: dataset.columns.length, 
        icon: Layers, 
        color: 'text-indigo-600', 
        bg: 'bg-indigo-50' 
      },
      { 
        label: 'Numeric Columns', 
        value: numericStats.length, 
        icon: Activity, 
        color: 'text-emerald-600', 
        bg: 'bg-emerald-50' 
      },
      { 
        label: 'Categories', 
        value: categoricalStats.length, 
        icon: FileSpreadsheet, 
        color: 'text-purple-600', 
        bg: 'bg-purple-50' 
      }
    ];
  }, [dataset, stats]);

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
      {kpis.map((kpi, i) => (
        <motion.div
          key={kpi.label}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: i * 0.1 }}
          className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm flex flex-col gap-3"
        >
          <div className={cn("p-2.5 rounded-2xl w-fit", kpi.bg, kpi.color)}>
            <kpi.icon className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{kpi.label}</p>
            <h3 className="text-2xl font-black text-slate-900 mt-1">{kpi.value}</h3>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

// Helper for class names
function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}
