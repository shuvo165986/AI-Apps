import React, { useRef } from 'react';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  ScatterChart, Scatter, AreaChart, Area, RadarChart, PolarGrid, 
  PolarAngleAxis, PolarRadiusAxis, Radar, FunnelChart, Funnel, Trapezoid, LabelList
} from 'recharts';
import { Download, Info, Sparkles } from 'lucide-react';
import { toPng } from 'html-to-image';
import { AnalysisResult, DataRow } from '../types';
import { cn } from '../lib/utils';

interface DashboardChartsProps {
  analysis: AnalysisResult;
  data: DataRow[];
}

const DEFAULT_COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f59e0b', '#10b981', '#06b6d4'];

// Custom 3D Bar Shape
const Custom3DBar = (props: any) => {
  const { fill, x, y, width, height } = props;
  if (width <= 0 || height <= 0) return null;

  const depth = 8;
  return (
    <g>
      {/* Front Face */}
      <rect x={x} y={y} width={width} height={height} fill={fill} rx={2} />
      {/* Right Side Face (Depth) */}
      <path
        d={`M ${x + width} ${y} L ${x + width + depth} ${y - depth} L ${x + width + depth} ${y + height - depth} L ${x + width} ${y + height} Z`}
        fill={fill}
        filter="brightness(0.6)"
      />
      {/* Top Face (Depth) */}
      <path
        d={`M ${x} ${y} L ${x + depth} ${y - depth} L ${x + width + depth} ${y - depth} L ${x + width} ${y} Z`}
        fill={fill}
        filter="brightness(0.85)"
      />
      {/* Subtle highlight line */}
      <line x1={x} y1={y} x2={x + width} y2={y} stroke="rgba(255,255,255,0.3)" strokeWidth={1} />
    </g>
  );
};

export default function DashboardCharts({ analysis, data }: DashboardChartsProps) {
  const chartRefs = useRef<(HTMLDivElement | null)[]>([]);

  const downloadChart = async (index: number, title: string) => {
    const element = chartRefs.current[index];
    if (!element) return;

    try {
      const dataUrl = await toPng(element, {
        backgroundColor: '#ffffff',
        cacheBust: true,
        style: {
          padding: '20px',
        }
      });
      
      const link = document.createElement('a');
      link.download = `${title.toLowerCase().replace(/\s+/g, '-')}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Failed to export chart:', err);
    }
  };

  if (!data || data.length === 0) {
    return (
      <div className="bg-white p-12 rounded-3xl border border-dashed border-slate-200 text-center mt-8">
        <p className="text-slate-500 font-medium">No data matches the selected filters.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-12">
      {analysis?.visualizations?.map((viz, index) => {
        const colors = viz.colorPalette && viz.colorPalette.length > 0 ? viz.colorPalette : DEFAULT_COLORS;
        
        return (
          <div 
            key={index} 
            ref={el => chartRefs.current[index] = el}
            className={cn(
              "bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col gap-6 group transition-all hover:scale-[1.01] hover:shadow-2xl hover:shadow-indigo-100/50 relative overflow-hidden",
              viz.type === 'radar' && "xl:col-span-1"
            )}
          >
            {/* Glossy overlay for 3D feel */}
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-black text-slate-900 tracking-tight leading-none">{viz?.title || 'Untitled Chart'}</h3>
                  {viz.is3D && (
                    <span className="text-[10px] bg-indigo-600 text-white px-2 py-0.5 rounded-full font-black uppercase tracking-widest flex items-center gap-1 shadow-sm">
                      <Sparkles className="w-2 h-2" /> 3D
                    </span>
                  )}
                </div>
                <p className="text-sm text-slate-500 font-medium leading-relaxed">{viz?.description || 'No description available'}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => downloadChart(index, viz?.title || 'chart')}
                  className="p-2.5 rounded-xl bg-slate-50 text-slate-400 hover:bg-indigo-600 hover:text-white transition-all shadow-sm active:scale-95"
                  title="Download as PNG"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            <div className={cn(
              "h-[350px] w-full mt-2 relative",
              viz.is3D && "perspective-1000"
            )}>
              <ResponsiveContainer width="100%" height="100%">
                {viz?.type === 'bar' ? (
                  <BarChart data={data?.slice(0, 15)} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id={`barGradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={colors[0]} stopOpacity={0.8}/>
                        <stop offset="95%" stopColor={colors[0]} stopOpacity={0.2}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey={viz?.xAxis} 
                      fontSize={11} 
                      tickLine={false} 
                      axisLine={false} 
                      tick={{fill: '#64748b', fontWeight: 600}} 
                    />
                    <YAxis 
                      fontSize={11} 
                      tickLine={false} 
                      axisLine={false} 
                      tick={{fill: '#64748b', fontWeight: 600}}
                    />
                    <Tooltip 
                      cursor={{fill: '#f8fafc'}}
                      contentStyle={{ 
                        backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                        borderRadius: '16px', 
                        border: '1px solid #e2e8f0', 
                        boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)',
                        backdropFilter: 'blur(8px)'
                      }}
                    />
                    <Bar 
                      dataKey={viz?.yAxis} 
                      fill={viz.is3D ? colors[0] : `url(#barGradient-${index})`} 
                      shape={viz.is3D ? <Custom3DBar /> : undefined}
                      radius={viz.is3D ? 0 : [8, 8, 0, 0]} 
                      animationDuration={1500}
                    />
                  </BarChart>
                ) : viz?.type === 'line' ? (
                  <LineChart data={data?.slice(0, 20)} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey={viz?.xAxis} 
                      fontSize={11} 
                      tickLine={false} 
                      axisLine={false} 
                      tick={{fill: '#64748b', fontWeight: 600}}
                    />
                    <YAxis 
                      fontSize={11} 
                      tickLine={false} 
                      axisLine={false} 
                      tick={{fill: '#64748b', fontWeight: 600}}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                        borderRadius: '16px', 
                        border: '1px solid #e2e8f0', 
                        boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)',
                        backdropFilter: 'blur(8px)'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey={viz?.yAxis} 
                      stroke={colors[0]} 
                      strokeWidth={4} 
                      dot={{ r: 6, fill: colors[0], strokeWidth: 2, stroke: '#fff' }} 
                      activeDot={{ r: 10, strokeWidth: 0 }} 
                      animationDuration={2000}
                    />
                  </LineChart>
                ) : viz?.type === 'area' ? (
                  <AreaChart data={data?.slice(0, 20)} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id={`areaGradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={colors[0]} stopOpacity={0.4}/>
                        <stop offset="95%" stopColor={colors[0]} stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey={viz?.xAxis} fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis fontSize={11} tickLine={false} axisLine={false} />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey={viz?.yAxis} 
                      stroke={colors[0]} 
                      strokeWidth={3}
                      fillOpacity={1} 
                      fill={`url(#areaGradient-${index})`} 
                    />
                  </AreaChart>
                ) : viz?.type === 'pie' ? (
                  <PieChart>
                    <Pie
                      data={data?.slice(0, 8)}
                      dataKey={viz?.yAxis}
                      nameKey={viz?.xAxis}
                      cx="50%"
                      cy="50%"
                      innerRadius={viz.is3D ? 40 : 70}
                      outerRadius={viz.is3D ? 100 : 100}
                      paddingAngle={5}
                      stroke="none"
                    >
                      {data?.slice(0, 8).map((_, i) => (
                        <Cell key={`cell-${i}`} fill={colors[i % colors.length]} className="filter drop-shadow-md" />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    />
                    <Legend verticalAlign="bottom" height={36}/>
                  </PieChart>
                ) : viz?.type === 'radar' ? (
                  <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data?.slice(0, 8)}>
                    <PolarGrid stroke="#e2e8f0" />
                    <PolarAngleAxis dataKey={viz?.xAxis} fontSize={10} tick={{fill: '#64748b'}} />
                    <PolarRadiusAxis fontSize={10} />
                    <Radar
                      name={viz?.yAxis}
                      dataKey={viz?.yAxis}
                      stroke={colors[0]}
                      fill={colors[0]}
                      fillOpacity={0.6}
                    />
                    <Tooltip />
                  </RadarChart>
                ) : viz?.type === 'scatter' ? (
                  <ScatterChart margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey={viz?.xAxis} name={viz?.xAxis} fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis dataKey={viz?.yAxis} name={viz?.yAxis} fontSize={11} tickLine={false} axisLine={false} />
                    <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                    <Scatter name="Data Points" data={data?.slice(0, 50)} fill={colors[0]}>
                      {data?.slice(0, 50).map((_, i) => (
                        <Cell key={`cell-${i}`} fill={colors[i % colors.length]} />
                      ))}
                    </Scatter>
                  </ScatterChart>
                ) : viz?.type === 'funnel' ? (
                  <FunnelChart>
                    <Tooltip />
                    <Funnel
                      dataKey={viz?.yAxis}
                      data={data?.slice(0, 5)}
                      isAnimationActive
                    >
                      <LabelList position="right" fill="#64748b" stroke="none" dataKey={viz?.xAxis} fontSize={10} />
                      {data?.slice(0, 5).map((_, i) => (
                        <Cell key={`cell-${i}`} fill={colors[i % colors.length]} />
                      ))}
                    </Funnel>
                  </FunnelChart>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-slate-400 gap-3">
                    <div className="p-4 bg-slate-50 rounded-full">
                      <Info className="w-8 h-8 opacity-20" />
                    </div>
                    <p className="text-sm font-bold uppercase tracking-widest opacity-40">
                      {viz?.type} Visualization Incoming
                    </p>
                  </div>
                )}
              </ResponsiveContainer>
            </div>
          </div>
        );
      })}
    </div>
  );
}
