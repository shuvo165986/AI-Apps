import React, { useState } from 'react';
import { 
  GitCompare, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle,
  BarChart3,
  TrendingUp,
  ShieldAlert,
  Lightbulb,
  ChevronDown,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { DatasetInfo, ComparisonResult } from '../types';
import { compareDatasets } from '../lib/gemini';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface DataComparisonProps {
  datasets: { id: string; info: DatasetInfo }[];
  onClose: () => void;
}

export default function DataComparison({ datasets, onClose }: DataComparisonProps) {
  const [datasetAId, setDatasetAId] = useState<string>(datasets[0]?.id || '');
  const [datasetBId, setDatasetBId] = useState<string>(datasets[1]?.id || '');
  const [matchingKey, setMatchingKey] = useState<string>('');
  const [isComparing, setIsComparing] = useState(false);
  const [result, setResult] = useState<ComparisonResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const datasetA = datasets.find(d => d.id === datasetAId)?.info;
  const datasetB = datasets.find(d => d.id === datasetBId)?.info;

  const commonColumns = datasetA && datasetB 
    ? datasetA.columns.filter(col => datasetB.columns.includes(col))
    : [];

  const handleCompare = async () => {
    if (!datasetA || !datasetB) return;
    
    setIsComparing(true);
    setError(null);
    try {
      const comparison = await compareDatasets(datasetA, datasetB, matchingKey);
      setResult(comparison);
    } catch (err: any) {
      setError(err.message || 'Comparison failed');
    } finally {
      setIsComparing(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
      <div className="bg-slate-900 p-6 text-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500 rounded-lg">
            <GitCompare className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Dataset Comparison</h3>
            <p className="text-xs text-slate-400">Analyze differences between two datasets</p>
          </div>
        </div>
        <button 
          onClick={onClose}
          className="p-2 hover:bg-white/10 rounded-lg transition-colors"
        >
          <ChevronDown className="w-5 h-5" />
        </button>
      </div>

      <div className="p-8 space-y-8">
        {/* Selection Area */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Dataset A</label>
            <select 
              value={datasetAId}
              onChange={(e) => setDatasetAId(e.target.value)}
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none"
            >
              {datasets.map(d => (
                <option key={d.id} value={d.id}>{d.info.name}</option>
              ))}
            </select>
          </div>

          <div className="flex justify-center pb-3">
            <div className="p-2 bg-slate-100 rounded-full text-slate-400">
              <ArrowRight className="w-5 h-5" />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Dataset B</label>
            <select 
              value={datasetBId}
              onChange={(e) => setDatasetBId(e.target.value)}
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none"
            >
              {datasets.map(d => (
                <option key={d.id} value={d.id}>{d.info.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="bg-indigo-50/50 p-6 rounded-2xl border border-indigo-100 space-y-4">
          <div className="flex items-center gap-2 text-indigo-700">
            <Sparkles className="w-4 h-4" />
            <h4 className="text-sm font-bold">Advanced Comparison Settings</h4>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-slate-600">Matching Key (Optional)</label>
            <select 
              value={matchingKey}
              onChange={(e) => setMatchingKey(e.target.value)}
              className="w-full p-3 bg-white border border-indigo-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none"
            >
              <option value="">No matching key (Aggregate comparison)</option>
              {commonColumns.map(col => (
                <option key={col} value={col}>{col}</option>
              ))}
            </select>
            <p className="text-[10px] text-slate-400 italic">Select a column present in both datasets to perform row-level matching.</p>
          </div>
        </div>

        <button
          onClick={handleCompare}
          disabled={isComparing || datasetAId === datasetBId}
          className={cn(
            "w-full py-4 rounded-2xl font-bold text-white shadow-lg transition-all flex items-center justify-center gap-2",
            isComparing ? "bg-slate-400 cursor-not-allowed" : "bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200"
          )}
        >
          {isComparing ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              Processing Comparison...
            </>
          ) : (
            <>
              <GitCompare className="w-5 h-5" />
              Run Side-by-Side Comparison
            </>
          )}
        </button>

        {error && (
          <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-start gap-3 text-rose-600">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="text-sm font-medium">{error}</p>
          </div>
        )}

        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8 pt-8 border-t border-slate-100"
            >
              {/* Summary Section */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-slate-900">Executive Summary</h4>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-wrap">{result.summary}</p>
              </div>

              {/* Comparison Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                      <BarChart3 className="w-5 h-5" />
                    </div>
                    <h4 className="font-bold text-slate-900">Statistical Differences</h4>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-wrap">{result.statisticalDifferences}</p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                      <TrendingUp className="w-5 h-5" />
                    </div>
                    <h4 className="font-bold text-slate-900">Trend Comparison</h4>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-wrap">{result.trendComparison}</p>
                </div>
              </div>

              {/* Key Differences List */}
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-rose-50 text-rose-600 rounded-lg">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-slate-900">Key Differences Identified</h4>
                </div>
                <ul className="space-y-3">
                  {result.keyDifferences.map((diff, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-slate-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-2 shrink-0" />
                      <span>{diff}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Recommendations */}
              <div className="bg-indigo-600 p-8 rounded-3xl text-white shadow-xl shadow-indigo-100">
                <div className="flex items-center gap-3 mb-6">
                  <Lightbulb className="w-6 h-6" />
                  <h4 className="text-xl font-bold">Strategic Recommendations</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {result.recommendations.map((rec, i) => (
                    <div key={i} className="bg-white/10 backdrop-blur-sm p-4 rounded-xl border border-white/20">
                      <p className="text-sm font-medium">{rec}</p>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
