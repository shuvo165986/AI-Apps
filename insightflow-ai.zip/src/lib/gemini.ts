import { GoogleGenAI, Type } from "@google/genai";
import { DatasetInfo, AnalysisResult, ComparisonResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

async function retryWithBackoff<T>(fn: () => Promise<T>, maxRetries = 5, initialDelay = 2000): Promise<T> {
  let lastError: any;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error: any) {
      lastError = error;
      const errorMsg = error?.message || '';
      const errorStatus = error?.status || '';
      const isRateLimit = errorMsg.includes('429') || 
                          errorStatus === 'RESOURCE_EXHAUSTED' || 
                          errorMsg.includes('quota') ||
                          JSON.stringify(error).includes('429');
      
      if (isRateLimit && i < maxRetries - 1) {
        const delay = initialDelay * Math.pow(2, i) + Math.random() * 1000;
        console.warn(`Gemini API rate limit hit. Retrying in ${Math.round(delay)}ms... (Attempt ${i + 1}/${maxRetries})`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      throw error;
    }
  }
  throw lastError;
}

export async function analyzeDataset(dataset: DatasetInfo, userQuery?: string): Promise<AnalysisResult> {
  if (!dataset.data || dataset.data.length === 0) {
    if (dataset.columns && dataset.columns.length > 0) {
      throw new Error("We found your column headers, but the sheet appears to have no data rows. Please ensure your file contains records below the header row.");
    }
    throw new Error("No data or headers found in the dataset. Please check if the file is empty or has an unsupported structure.");
  }

  try {
    const prompt = `
      You are an advanced AI Data Analyst and Business Intelligence Expert.
      Analyze the following dataset and provide professional, actionable insights.
      
      Dataset Name: ${dataset.name}
      Columns: ${dataset.columns.join(", ")}
      Column Types: ${JSON.stringify(dataset.columnTypes)}
      Total Rows: ${dataset.rowCount}
      Data Preview (First 10 rows):
      ${JSON.stringify(dataset.preview, null, 2)}
      
      ${userQuery ? `
      CRITICAL: The user has a specific request/question: "${userQuery}"
      You MUST prioritize answering this request. Tailor the entire analysis, including visualizations and recommendations, to address this specific query while still providing a comprehensive overview.
      ` : "Provide a comprehensive general analysis of the dataset."}
      
      Analysis Requirements:
      1. **Overview**: Executive summary of the data.
      2. **Quality Audit**:
         - Date consistency and formats.
         - Type integrity (e.g., text in numeric columns).
         - Categorical normalization (e.g., "NY" vs "New York").
         - Missing values and outliers.
      3. **Statistics & Trends**: Key performance indicators and temporal patterns.
      4. **Visualizations**: Suggest 3-5 specific charts. Ensure xAxis and yAxis match the provided column names EXACTLY. 
         - Mix chart types (bar, line, pie, scatter, area, radar, funnel).
         - Use 'is3D': true for charts that would look great with depth (simulated 3D).
         - Provide a custom 'colorPalette' for each chart to make it ultra-colorful and vibrant.
      5. **Actionable Recommendations**: Strategic steps based on the data findings.
      
      Follow the structured JSON output format strictly.
    `;

    const response = await retryWithBackoff(() => ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overview: { type: Type.STRING },
            qualityIssues: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            statistics: { type: Type.STRING },
            trends: { type: Type.STRING },
            outliers: { type: Type.STRING },
            insights: { type: Type.STRING },
            visualizations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  type: { type: Type.STRING, enum: ['bar', 'line', 'pie', 'scatter', 'heatmap', 'area', 'radar', 'composed', 'funnel'] },
                  xAxis: { type: Type.STRING },
                  yAxis: { type: Type.STRING },
                  description: { type: Type.STRING },
                  is3D: { type: Type.BOOLEAN },
                  colorPalette: { 
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  }
                },
                required: ['title', 'type', 'xAxis', 'yAxis', 'description']
              }
            },
            dashboardStructure: { type: Type.STRING },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            cleaningRecommendations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  issue: { type: Type.STRING },
                  recommendation: { type: Type.STRING }
                },
                required: ['issue', 'recommendation']
              }
            },
            suggestedActions: {
              type: Type.ARRAY,
              items: { type: Type.STRING, enum: ['trim', 'lowercase', 'uppercase', 'titlecase', 'numeric', 'remove_nulls', 'normalize_dates'] }
            }
          },
          required: [
            'overview', 'qualityIssues', 'statistics', 'trends', 
            'outliers', 'insights', 'visualizations', 
            'dashboardStructure', 'recommendations', 'cleaningRecommendations', 'suggestedActions'
          ]
        }
      }
    }));

    return JSON.parse(response.text);
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    
    const errorStr = JSON.stringify(error);
    if (errorStr.includes('429') || errorStr.includes('RESOURCE_EXHAUSTED')) {
      throw new Error("The AI is currently receiving too many requests. We've tried retrying, but the limit is still active. Please wait a few seconds and try clicking 'Run AI Analysis' again.");
    }

    if (error?.message?.includes('404') || error?.message?.includes('not found')) {
      throw new Error("The AI model is currently unavailable or the model name is incorrect. Please contact support.");
    }
    
    if (error?.message?.includes('API key')) {
      throw new Error("Invalid API key. Please check your Gemini API key configuration.");
    }

    throw new Error(error?.message || "An unexpected error occurred during analysis.");
  }
}

export async function compareDatasets(
  datasetA: DatasetInfo, 
  datasetB: DatasetInfo, 
  matchingKey?: string
): Promise<ComparisonResult> {
  try {
    const prompt = `
      You are an advanced AI Data Analyst. Compare the following two datasets side-by-side.
      
      Dataset A: ${datasetA.name}
      Columns A: ${datasetA.columns.join(", ")}
      Rows A: ${datasetA.rowCount}
      Preview A: ${JSON.stringify(datasetA.preview, null, 2)}
      
      Dataset B: ${datasetB.name}
      Columns B: ${datasetB.columns.join(", ")}
      Rows B: ${datasetB.rowCount}
      Preview B: ${JSON.stringify(datasetB.preview, null, 2)}
      
      ${matchingKey ? `Matching Key for row-level comparison: ${matchingKey}` : "No matching key provided. Focus on aggregate differences."}
      
      Requirements:
      1. **Summary**: High-level comparison of both datasets.
      2. **Statistical Differences**: Compare means, ranges, and distributions.
      3. **Trend Comparison**: Contrast temporal or categorical patterns.
      4. **Quality Comparison**: Compare data integrity and missing values.
      5. **Key Differences**: List specific, notable differences found.
      6. **Recommendations**: Strategic advice based on the comparison.
      7. **Visualizations**: Suggest 2-3 charts to visualize the differences.
         - Mix chart types (bar, line, pie, scatter, area, radar).
         - Use 'is3D': true for depth.
         - Provide vibrant 'colorPalette'.
      
      Follow the structured JSON output format strictly.
    `;

    const response = await retryWithBackoff(() => ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            statisticalDifferences: { type: Type.STRING },
            trendComparison: { type: Type.STRING },
            qualityComparison: { type: Type.STRING },
            keyDifferences: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            visualizations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  type: { type: Type.STRING, enum: ['bar', 'line', 'pie', 'scatter', 'area', 'radar'] },
                  description: { type: Type.STRING },
                  is3D: { type: Type.BOOLEAN },
                  colorPalette: { 
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  }
                },
                required: ['title', 'type', 'description']
              }
            }
          },
          required: [
            'summary', 'statisticalDifferences', 'trendComparison', 
            'qualityComparison', 'keyDifferences', 'recommendations', 'visualizations'
          ]
        }
      }
    }));

    return JSON.parse(response.text);
  } catch (error: any) {
    console.error("Gemini Comparison Error:", error);
    throw new Error(error?.message || "An unexpected error occurred during comparison.");
  }
}
