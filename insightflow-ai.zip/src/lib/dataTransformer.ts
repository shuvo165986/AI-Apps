import { DataRow } from '../types';

export interface TransformationResult {
  data: DataRow[];
  columns: string[];
  summary: string;
}

export class DataTransformer {
  /**
   * Groups data by a categorical column and aggregates numeric columns
   */
  static aggregate(data: DataRow[], groupBy: string, aggregateBy: string, type: 'sum' | 'avg' | 'count' = 'sum'): TransformationResult {
    const groups: Record<string, { value: number; count: number }> = {};
    
    data.forEach(row => {
      const groupKey = String(row[groupBy] || 'Unknown');
      const val = Number(row[aggregateBy]);
      
      if (!groups[groupKey]) {
        groups[groupKey] = { value: 0, count: 0 };
      }
      
      if (!isNaN(val)) {
        groups[groupKey].value += val;
        groups[groupKey].count += 1;
      } else if (type === 'count') {
        groups[groupKey].count += 1;
      }
    });
    
    const resultData = Object.entries(groups).map(([key, stats]) => ({
      [groupBy]: key,
      [aggregateBy]: type === 'avg' ? (stats.value / stats.count) : (type === 'count' ? stats.count : stats.value)
    }));
    
    return {
      data: resultData,
      columns: [groupBy, aggregateBy],
      summary: `Aggregated ${data.length} rows into ${resultData.length} groups by ${groupBy}.`
    };
  }

  /**
   * Extracts time-based features from date columns
   */
  static extractTimeFeatures(data: DataRow[], dateColumn: string): DataRow[] {
    return data.map(row => {
      const date = new Date(row[dateColumn]);
      if (isNaN(date.getTime())) return row;
      
      return {
        ...row,
        [`${dateColumn}_Year`]: date.getFullYear(),
        [`${dateColumn}_Month`]: date.toLocaleString('default', { month: 'long' }),
        [`${dateColumn}_DayOfWeek`]: date.toLocaleString('default', { weekday: 'long' }),
        [`${dateColumn}_Quarter`]: `Q${Math.floor(date.getMonth() / 3) + 1}`
      };
    });
  }

  /**
   * Calculates Pearson correlation between two numeric columns
   */
  static calculateCorrelation(data: DataRow[], colA: string, colB: string): number {
    const valsA = data.map(r => Number(r[colA])).filter(v => !isNaN(v));
    const valsB = data.map(r => Number(r[colB])).filter(v => !isNaN(v));
    
    if (valsA.length !== valsB.length || valsA.length === 0) return 0;
    
    const n = valsA.length;
    const sumA = valsA.reduce((a, b) => a + b, 0);
    const sumB = valsB.reduce((a, b) => a + b, 0);
    const sumAB = valsA.reduce((sum, a, i) => sum + a * valsB[i], 0);
    const sumA2 = valsA.reduce((sum, a) => sum + a * a, 0);
    const sumB2 = valsB.reduce((sum, b) => sum + b * b, 0);
    
    const numerator = n * sumAB - sumA * sumB;
    const denominator = Math.sqrt((n * sumA2 - sumA * sumA) * (n * sumB2 - sumB * sumB));
    
    return denominator === 0 ? 0 : numerator / denominator;
  }

  /**
   * Creates a pivot-style summary grouping by two columns
   */
  static pivot(data: DataRow[], rowCol: string, colCol: string, valCol: string, type: 'sum' | 'avg' | 'count' = 'sum'): TransformationResult {
    const pivotData: Record<string, Record<string, { value: number; count: number }>> = {};
    const uniqueCols = new Set<string>();
    
    data.forEach(row => {
      const rowKey = String(row[rowCol] || 'Unknown');
      const colKey = String(row[colCol] || 'Unknown');
      const val = Number(row[valCol]);
      
      uniqueCols.add(colKey);
      
      if (!pivotData[rowKey]) pivotData[rowKey] = {};
      if (!pivotData[rowKey][colKey]) pivotData[rowKey][colKey] = { value: 0, count: 0 };
      
      if (!isNaN(val)) {
        pivotData[rowKey][colKey].value += val;
        pivotData[rowKey][colKey].count += 1;
      } else if (type === 'count') {
        pivotData[rowKey][colKey].count += 1;
      }
    });
    
    const sortedCols = Array.from(uniqueCols).sort();
    const resultData = Object.entries(pivotData).map(([rowKey, colData]) => {
      const row: DataRow = { [rowCol]: rowKey };
      sortedCols.forEach(colKey => {
        const stats = colData[colKey];
        if (stats) {
          row[colKey] = type === 'avg' ? (stats.value / stats.count) : (type === 'count' ? stats.count : stats.value);
        } else {
          row[colKey] = 0;
        }
      });
      return row;
    });
    
    return {
      data: resultData,
      columns: [rowCol, ...sortedCols],
      summary: `Pivoted ${data.length} rows by ${rowCol} and ${colCol}.`
    };
  }

  /**
   * Performs arithmetic between two columns
   */
  static calculateField(data: DataRow[], colA: string, colB: string, operator: '+' | '-' | '*' | '/', newName: string): DataRow[] {
    return data.map(row => {
      const valA = Number(row[colA]);
      const valB = Number(row[colB]);
      let result = 0;
      
      if (!isNaN(valA) && !isNaN(valB)) {
        switch (operator) {
          case '+': result = valA + valB; break;
          case '-': result = valA - valB; break;
          case '*': result = valA * valB; break;
          case '/': result = valB !== 0 ? valA / valB : 0; break;
        }
      }
      
      return { ...row, [newName]: result };
    });
  }

  /**
   * Automatically identifies potential actionable transformations
   */
  static suggestTransformations(columns: string[], data: DataRow[]) {
    const numericCols = columns.filter(col => 
      data.slice(0, 50).some(row => typeof row[col] === 'number' || (!isNaN(Number(row[col])) && row[col] !== ''))
    );
    
    const categoricalCols = columns.filter(col => {
      const values = new Set(data.slice(0, 100).map(row => String(row[col])));
      return values.size > 1 && values.size < data.length * 0.2; // Likely a category if few unique values
    });
    
    const dateCols = columns.filter(col => 
      data.slice(0, 20).some(row => !isNaN(new Date(row[col]).getTime()) && String(row[col]).length > 5)
    );

    return { numericCols, categoricalCols, dateCols };
  }
}
