/**
 * Utility for validating and sanitizing file data
 */

import { DataRow } from '../types';

export class FileValidator {
  /**
   * Validates if a file has a supported extension
   */
  static isSupported(fileName: string): boolean {
    const ext = fileName.split('.').pop()?.toLowerCase();
    return ['xlsx', 'xls', 'csv', 'xlsm', 'xlsb', 'ods'].includes(ext || '');
  }

  /**
   * Sanitizes a row of data to ensure it's a valid object with no undefined keys
   */
  static sanitizeRow(row: any, columns: string[]): DataRow {
    if (!row || typeof row !== 'object') return {};
    
    const sanitized: DataRow = {};
    columns.forEach(col => {
      const val = row[col];
      // Convert null/undefined to empty string or null, but never let it be undefined
      sanitized[col] = (val === undefined || val === null) ? null : val;
    });
    return sanitized;
  }

  /**
   * Validates a full dataset before it's passed to the application
   */
  static validateDataset(data: any): boolean {
    if (!data) return false;
    if (!Array.isArray(data.columns) || data.columns.length === 0) return false;
    if (!Array.isArray(data.data)) return false;
    return true;
  }
}
