import { DataRow } from '../types';

export type CleaningAction = 
  | 'trim' 
  | 'lowercase' 
  | 'uppercase' 
  | 'titlecase' 
  | 'numeric' 
  | 'remove_nulls'
  | 'normalize_dates';

export class DataCleaner {
  /**
   * Trims whitespace from all string values in a row
   */
  static trim(row: DataRow): DataRow {
    const newRow = { ...row };
    Object.keys(newRow).forEach(key => {
      if (typeof newRow[key] === 'string') {
        newRow[key] = newRow[key].trim();
      }
    });
    return newRow;
  }

  /**
   * Converts all string values to lowercase
   */
  static lowercase(row: DataRow): DataRow {
    const newRow = { ...row };
    Object.keys(newRow).forEach(key => {
      if (typeof newRow[key] === 'string') {
        newRow[key] = newRow[key].toLowerCase();
      }
    });
    return newRow;
  }

  /**
   * Converts all string values to uppercase
   */
  static uppercase(row: DataRow): DataRow {
    const newRow = { ...row };
    Object.keys(newRow).forEach(key => {
      if (typeof newRow[key] === 'string') {
        newRow[key] = newRow[key].toUpperCase();
      }
    });
    return newRow;
  }

  /**
   * Converts all string values to Title Case
   */
  static titlecase(row: DataRow): DataRow {
    const newRow = { ...row };
    Object.keys(newRow).forEach(key => {
      if (typeof newRow[key] === 'string') {
        newRow[key] = newRow[key].replace(/\w\S*/g, (txt) => {
          return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
      }
    });
    return newRow;
  }

  /**
   * Attempts to convert string values to numbers where possible
   * (Removes currency symbols, commas, etc.)
   */
  static numeric(row: DataRow): DataRow {
    const newRow = { ...row };
    Object.keys(newRow).forEach(key => {
      const val = newRow[key];
      if (typeof val === 'string') {
        // Remove common non-numeric characters but keep decimal point and minus sign
        const cleanVal = val.replace(/[^\d.-]/g, '');
        if (cleanVal !== '' && !isNaN(Number(cleanVal))) {
          newRow[key] = Number(cleanVal);
        }
      }
    });
    return newRow;
  }

  /**
   * Removes rows that have null or undefined values in all columns
   * (Or replaces nulls with empty strings if preferred, but here we just filter)
   */
  static removeNulls(row: DataRow): DataRow | null {
    const values = Object.values(row);
    const hasData = values.some(v => v !== null && v !== undefined && v !== '');
    return hasData ? row : null;
  }

  /**
   * Attempts to normalize date strings to ISO format
   */
  static normalizeDates(row: DataRow): DataRow {
    const newRow = { ...row };
    Object.keys(newRow).forEach(key => {
      const val = newRow[key];
      if (typeof val === 'string' && val.length > 5) {
        const date = new Date(val);
        if (!isNaN(date.getTime())) {
          newRow[key] = date.toISOString().split('T')[0];
        }
      }
    });
    return newRow;
  }

  /**
   * Applies a set of cleaning actions to a dataset
   */
  static clean(data: DataRow[], actions: CleaningAction[]): DataRow[] {
    const cleanedData: DataRow[] = [];
    
    data.forEach(row => {
      let cleanedRow: DataRow | null = { ...row };
      
      actions.forEach(action => {
        if (!cleanedRow) return;
        
        switch (action) {
          case 'trim':
            cleanedRow = this.trim(cleanedRow);
            break;
          case 'lowercase':
            cleanedRow = this.lowercase(cleanedRow);
            break;
          case 'uppercase':
            cleanedRow = this.uppercase(cleanedRow);
            break;
          case 'titlecase':
            cleanedRow = this.titlecase(cleanedRow);
            break;
          case 'numeric':
            cleanedRow = this.numeric(cleanedRow);
            break;
          case 'remove_nulls':
            cleanedRow = this.removeNulls(cleanedRow);
            break;
          case 'normalize_dates':
            cleanedRow = this.normalizeDates(cleanedRow);
            break;
        }
      });
      
      if (cleanedRow) {
        cleanedData.push(cleanedRow);
      }
    });
    
    return cleanedData;
  }
}
