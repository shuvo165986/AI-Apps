import { DataRow, ColumnTypeInfo } from '../types';

export interface LocalStats {
  columnName: string;
  min?: number;
  max?: number;
  avg?: number;
  median?: number;
  uniqueCount: number;
  missingCount: number;
  type: 'numeric' | 'categorical' | 'date' | 'text';
}

export class DataAnalysisEngine {
  /**
   * Detects the type of each column based on its values
   */
  static detectColumnTypes(columns: string[], data: DataRow[]): ColumnTypeInfo[] {
    return columns.map(col => {
      const sampleValues = data.slice(0, 100).map(row => row[col]).filter(v => v !== null && v !== undefined && v !== '');
      
      if (sampleValues.length === 0) return { name: col, type: 'text' };

      // Check for numeric
      const isNumeric = sampleValues.every(v => typeof v === 'number' || (!isNaN(Number(v)) && !isNaN(parseFloat(String(v)))));
      if (isNumeric) return { name: col, type: 'numeric' };

      // Check for date
      const isDate = sampleValues.every(v => {
        const d = new Date(v);
        return !isNaN(d.getTime()) && String(v).length > 5;
      });
      if (isDate) return { name: col, type: 'date' };

      // Check for categorical (few unique values relative to total)
      const uniqueValues = new Set(sampleValues);
      if (uniqueValues.size < sampleValues.length * 0.2 || uniqueValues.size < 10) {
        return { name: col, type: 'categorical' };
      }

      return { name: col, type: 'text' };
    });
  }

  /**
   * Calculates basic statistics for all columns
   */
  static calculateStats(columns: string[], data: DataRow[], columnTypes: ColumnTypeInfo[]): LocalStats[] {
    return columns.map(col => {
      const typeInfo = columnTypes.find(t => t.name === col);
      const values = data.map(row => row[col]).filter(v => v !== null && v !== undefined && v !== '');
      const missingCount = data.length - values.length;
      const uniqueValues = new Set(values);

      const stats: LocalStats = {
        columnName: col,
        uniqueCount: uniqueValues.size,
        missingCount,
        type: typeInfo?.type || 'text'
      };

      if (stats.type === 'numeric') {
        const numValues = values.map(v => Number(v)).filter(v => !isNaN(v));
        if (numValues.length > 0) {
          numValues.sort((a, b) => a - b);
          stats.min = numValues[0];
          stats.max = numValues[numValues.length - 1];
          stats.avg = numValues.reduce((a, b) => a + b, 0) / numValues.length;
          stats.median = numValues[Math.floor(numValues.length / 2)];
        }
      }

      return stats;
    });
  }

  /**
   * Identifies correlations between numeric columns
   */
  static findCorrelations(data: DataRow[], numericCols: string[]) {
    const correlations: Array<{ col1: string, col2: string, value: number }> = [];
    
    for (let i = 0; i < numericCols.length; i++) {
      for (let j = i + 1; j < numericCols.length; j++) {
        const col1 = numericCols[i];
        const col2 = numericCols[j];
        
        const pairs = data.map(row => [Number(row[col1]), Number(row[col2])])
          .filter(p => !isNaN(p[0]) && !isNaN(p[1]));
        
        if (pairs.length < 2) continue;

        const n = pairs.length;
        const sum1 = pairs.reduce((acc, p) => acc + p[0], 0);
        const sum2 = pairs.reduce((acc, p) => acc + p[1], 0);
        const sum1Sq = pairs.reduce((acc, p) => acc + p[0] * p[0], 0);
        const sum2Sq = pairs.reduce((acc, p) => acc + p[1] * p[1], 0);
        const pSum = pairs.reduce((acc, p) => acc + p[0] * p[1], 0);

        const num = pSum - (sum1 * sum2 / n);
        const den = Math.sqrt((sum1Sq - sum1 * sum1 / n) * (sum2Sq - sum2 * sum2 / n));

        if (den !== 0) {
          correlations.push({ col1, col2, value: num / den });
        }
      }
    }

    return correlations.sort((a, b) => Math.abs(b.value) - Math.abs(a.value));
  }
}
