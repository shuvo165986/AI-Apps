export interface DataRow {
  [key: string]: any;
}

export interface ColumnTypeInfo {
  name: string;
  type: 'numeric' | 'categorical' | 'date' | 'text';
}

export interface DatasetInfo {
  name: string;
  columns: string[];
  columnTypes: ColumnTypeInfo[];
  data: DataRow[];
  preview: DataRow[];
  rowCount: number;
}

export interface AnalysisResult {
  overview: string;
  qualityIssues: string[];
  statistics: string;
  trends: string;
  outliers: string;
  insights: string;
  visualizations: Array<{
    title: string;
    type: 'bar' | 'line' | 'pie' | 'scatter' | 'heatmap' | 'area' | 'radar' | 'composed' | 'funnel';
    xAxis: string;
    yAxis: string;
    description: string;
    is3D?: boolean;
    colorPalette?: string[];
  }>;
  dashboardStructure: string;
  recommendations: string[];
  cleaningRecommendations: Array<{
    issue: string;
    recommendation: string;
  }>;
  suggestedActions?: string[];
  queryUsed?: string;
}

export interface ComparisonResult {
  summary: string;
  statisticalDifferences: string;
  trendComparison: string;
  qualityComparison: string;
  keyDifferences: string[];
  recommendations: string[];
  visualizations: Array<{
    title: string;
    type: 'bar' | 'line' | 'pie' | 'scatter' | 'area' | 'radar';
    description: string;
    is3D?: boolean;
    colorPalette?: string[];
  }>;
}
